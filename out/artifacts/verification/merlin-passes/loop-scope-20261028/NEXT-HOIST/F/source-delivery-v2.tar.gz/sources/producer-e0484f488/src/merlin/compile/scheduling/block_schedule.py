"""Order the block moves and computes of a contraction over a target's on-chip stores.

``capacity.py`` answers which tile FITS. This module answers the question after it: in what ORDER the
blocks of that tile move on chip, which of them stays resident, and where each operand's region sits --
the part a weight-stationary backend otherwise hand-writes, and the part that decides cycles.

Measured on one such backend (the capsule head-to-head experiment, whose ``STATUS.md`` carries the
Verilator and FPGA tables), four choices inside this ordering moved 1-24% of cycles on identical
instruction packing:

* loading an operand block only when its index changes, instead of once per inner step (-28% on a
  4x4-block matmul);
* issuing loads a BOUNDED number of reduction steps ahead: one step ahead beat both interleaved
  (-6%) and hoisting every load up front (which cost 7% on the same shape, because the loads crowd
  the queues ahead of the first compute);
* which operand's load is issued first inside a step;
* where the non-streamed operand's region starts: sharing a bank with the streamed operand cost
  3-15%, and the position INSIDE the other bank moved several cycles either way.

None of the four has a value that wins everywhere. The best setting depends on the shape AND on the
substrate -- one capsule reverses between a fast-memory simulator and the FPGA, where real DRAM
latency makes an earlier load pay. So they are KNOBS here, with documented defaults, never constants
compiled into a backend: a target picks values by measurement (keyed by kernel digest, the way
``perf/calibration`` keys a measured cycle count) and this pass produces the schedule for them.

Everything about the device is derived. Block edge, store rows, bank depth and the accumulator's size
come from :func:`merlin.targetgen.address_space.derive_address_space`, i.e. from that target's own RTL
facts; a quantity the facts cannot answer is a refusal (:class:`BlockScheduleError`), never a default.

This module imports nothing from merlin, so a generated backend that may not depend on merlin at run time
can VENDOR it byte for byte and run the pass itself (``tests/infra`` pins that). Deriving a
:class:`Geometry` from a target's facts is :func:`merlin.compile.scheduling.derive.geometry_from_address_space`.

Every schedule is checked before it is returned (:func:`check_residency`): a load may not overwrite a
block some later compute still expects to read. That check is what makes an aggressive knob value SAFE
to offer -- when two regions overlap, one order can be correct (the overwrite lands after the last
read) while another silently computes on the wrong bytes, and an in-order executor cannot see the
difference.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any

#: Roles this pass schedules: the operand STREAMED through the array each compute, and the one made
#: RESIDENT in it. Named by role, never by a target's spelling of them.
LHS = "lhs"
WEIGHT = "weight"
ROLES = (LHS, WEIGHT)

# Conservative compiler verification policy, independent of hardware capacity.
# Adapters preflight dynamic operation counts before materializing a projection.
DEFAULT_PROJECTION_OPERATION_LIMIT = 4096

#: ``load_grouping`` values -- how the loads inside one emission group are ordered.
#: ``NEST``: exactly as the loop nest produces them (a weight load at its own position, each streamed
#: block immediately before the compute that reads it). ``ROLE``: all of one role's loads, then the
#: other's, in ``operand_order``, each role keeping its nest order.
NEST = "nest"
ROLE = "role"
GROUPINGS = (NEST, ROLE)

#: Loop axes, named by the ``Contraction`` dimension each iterates in blocks: ``K`` the reduction axis
#: (the width of the streamed operand, the depth of the resident one), ``N`` the resident operand's
#: output axis, ``M`` the streamed operand's rows. ``loop_order`` is a permutation of the three,
#: outermost first.
K = "k"
N = "n"
M = "m"
AXES = (K, N, M)

#: ``placement`` values for the resident operand's region. The streamed operand always starts at row 0.
#: ``OPPOSITE_END``: flush with the end of the store, growing back toward the streamed operand.
#: ``BANK_ALIGNED``: the first bank boundary at or after the streamed region (separating the two
#: operands into different banks), falling back to ``OPPOSITE_END`` when that does not fit.
#: ``CONTIGUOUS``: directly after the streamed region, sharing its bank.
OPPOSITE_END = "opposite_end"
BANK_ALIGNED = "bank_aligned"
CONTIGUOUS = "contiguous"
PLACEMENTS = (OPPOSITE_END, BANK_ALIGNED, CONTIGUOUS)


class BlockScheduleError(ValueError):
    """A schedule the target's derived facts, the program, or the knobs do not admit."""


def _ceil_div(a: int, b: int) -> int:
    return -(-a // b)


@dataclass(frozen=True)
class Geometry:
    """The on-chip geometry a block schedule addresses, derived from one target's facts.

    ``block`` is the square block edge (the array edge a store row spans). ``operand_bank_rows`` is the
    PER-BANK row count -- the granularity a placement policy can separate operands at -- and is ``None``
    when the facts could not resolve it, which makes :data:`BANK_ALIGNED` a refusal rather than a guess.
    """

    block: int
    operand_rows: int
    operand_bank_rows: int | None
    accumulator_rows: int
    separate_accumulator_space: bool
    sources: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class Knobs:
    """The scheduling choices, with their defaults.

    Defaults are the values that measured best over the corpus this pass was lifted from, stated so a
    reader knows what they are getting: load on index change, one reduction step of lookahead, the
    streamed operand's load first inside a step, and the resident operand at the far end of the store.
    They are a starting point for a target's own measurement, NOT a claim that they are optimal
    anywhere else -- on that corpus the best value differed per shape and per substrate.
    """

    #: Load an operand block only when a compute first needs it -- a block, once loaded into its own rows,
    #: stays resident -- instead of re-loading it in every emission group that reads it.
    load_on_index_change: bool = True
    #: Reduction steps of lookahead. ``0`` issues a load in its nest position; ``d`` issues step
    #: ``i + d``'s loads before step ``i``'s computes; ``None`` hoists every load ahead of every
    #: compute (measured as the worst of the three on a deep shape, and rejected outright by
    #: :func:`check_residency` whenever regions overlap).
    lookahead_steps: int | None = 1
    #: Order of the roles inside an emission group; only read when ``load_grouping`` is :data:`ROLE`.
    operand_order: tuple[str, ...] = (LHS, WEIGHT)
    #: How loads are ordered inside an emission group: :data:`NEST` or :data:`ROLE`.
    load_grouping: str = ROLE
    #: Where the resident operand's region starts; one of :data:`PLACEMENTS`.
    placement: str = OPPOSITE_END
    #: The block nest, outermost first -- a permutation of :data:`AXES`. The default is
    #: reduction-major, which keeps one resident block live across every streamed block that reads it.
    #: An emission group is one iteration of the two OUTER loops, and a lookahead "step" is one iteration
    #: of the outermost; so under the default a step is a reduction step, as the knobs above describe.
    loop_order: tuple[str, ...] = (K, N, M)

    def validate(self) -> None:
        if tuple(self.operand_order) not in ((LHS, WEIGHT), (WEIGHT, LHS)):
            raise BlockScheduleError(f"operand_order must order exactly {ROLES}, got {tuple(self.operand_order)!r}")
        if self.load_grouping not in GROUPINGS:
            raise BlockScheduleError(f"load_grouping must be one of {GROUPINGS}, got {self.load_grouping!r}")
        if self.placement not in PLACEMENTS:
            raise BlockScheduleError(f"placement must be one of {PLACEMENTS}, got {self.placement!r}")
        if sorted(self.loop_order) != sorted(AXES):
            raise BlockScheduleError(f"loop_order must be a permutation of {AXES}, got {tuple(self.loop_order)!r}")
        if self.lookahead_steps is not None and self.lookahead_steps < 0:
            raise BlockScheduleError(f"lookahead_steps must be None or >= 0, got {self.lookahead_steps!r}")


@dataclass(frozen=True)
class Contraction:
    """One contraction to schedule: ``[m, k] x [k, n] -> [m, n]``, with the operand names a backend
    resolves addresses against."""

    m: int
    k: int
    n: int
    lhs: str = LHS
    weight: str = WEIGHT
    out: str = "out"


@dataclass(frozen=True)
class ConvContraction:
    """One NHWC convolution scheduled as a contraction: each kernel tap x input-channel slice is a
    reduction block, each output-channel block a resident block, each block of output pixels a streamed
    block gathered tap by tap from the input feature map.

    Operands, in the element coordinates :func:`execute` and a renderer address: the input as a
    ``[batch*in_h*in_w, ci]`` matrix, the weight as ``[kh*kw*ci, co]`` (pre-im2col layout), the output as
    ``[batch*out_h*out_w, co]``.
    """

    batch: int
    in_h: int
    in_w: int
    ci: int
    kh: int
    kw: int
    co: int
    stride: tuple[int, int] = (1, 1)
    padding: tuple[int, int, int, int] = (0, 0, 0, 0)  # top, left, bottom, right
    dilation: tuple[int, int] = (1, 1)
    lhs: str = "ifm"
    weight: str = WEIGHT
    out: str = "out"

    @property
    def out_h(self) -> int:
        pt, _, pb, _ = self.padding
        return (self.in_h + pt + pb - (self.dilation[0] * (self.kh - 1) + 1)) // self.stride[0] + 1

    @property
    def out_w(self) -> int:
        _, pl, _, pr = self.padding
        return (self.in_w + pl + pr - (self.dilation[1] * (self.kw - 1) + 1)) // self.stride[1] + 1

    @property
    def pixels(self) -> int:
        return self.batch * self.out_h * self.out_w


@dataclass(frozen=True)
class InitializeAccumulator:
    """Synchronous overwrite from a contiguous signed accumulator-width bias.

    The single source row is broadcast over destination rows. This is an
    explicit DRAM read plus accumulator write, not an implicit unary readout.
    Target encoders must preserve the source words without scaling/narrowing.
    """

    block: tuple[Any, Any]
    dram_col: Any
    rows: Any
    cols: Any
    row: Any
    source_row_stride: Any = 0
    source_col_stride: Any = 1


@dataclass(frozen=True)
class Load:
    """Move one block of ``role`` from its DRAM position (in ELEMENTS) to on-chip row ``row``.

    A GATHERED block (``gather`` set) is not a contiguous DRAM rectangle: on-chip row ``row + i`` is filled
    from ``gather[i]``, a ``(row, col)`` element position in the operand's DRAM matrix, or from the
    target's zero path when the entry is ``None`` (a convolution tap that falls outside the image). Then
    ``dram_row``/``dram_col`` are ``-1``, and the gather is part of the block's identity: two loads of one
    block position with different gathers are different bytes.
    """

    role: str
    block: tuple[int, int]
    dram_row: int
    dram_col: int
    rows: int
    cols: int
    row: int
    step: int
    gather: tuple[tuple[int, int] | None, ...] | None = None


@dataclass(frozen=True)
class GatherRun:
    """A maximal stretch of a gather that one multi-row load can move.

    ``offset`` is the first gathered row, ``rows`` how many. ``source`` is the first DRAM ``(row, col)``,
    and the run reads rows ``source[0] + i * row_step`` for ``i < rows`` at that column -- or ``source`` is
    ``None`` and every row comes from the target's zero path (``row_step`` 0). A stride-``s`` convolution
    gathers every ``s``-th pixel of an image row, so its runs have ``row_step == s``.
    """

    offset: int
    rows: int
    source: tuple[int, int] | None
    row_step: int


def gather_runs(gather: tuple[tuple[int, int] | None, ...]) -> tuple[GatherRun, ...]:
    """Split a gather into the fewest runs of rows that are equally spaced in DRAM (or all zero).

    A run's spacing is fixed by its first two entries and must be positive; a single entry is a run of
    one. Joining the runs back, row by row, reproduces the gather exactly -- which is what lets a target
    that can load several DRAM rows at a configured stride move a gather in a handful of loads instead of
    one per row, without changing a single byte that reaches the chip.
    """
    runs: list[GatherRun] = []
    index = 0
    while index < len(gather):
        first = gather[index]
        length, step = 1, 0
        if first is None:
            while index + length < len(gather) and gather[index + length] is None:
                length += 1
        elif index + 1 < len(gather) and gather[index + 1] is not None:
            nxt = gather[index + 1]
            if nxt[1] == first[1] and nxt[0] > first[0]:
                step = nxt[0] - first[0]
                while (
                    index + length < len(gather)
                    and gather[index + length] is not None
                    and gather[index + length][1] == first[1]
                    and gather[index + length][0] == first[0] + length * step
                ):
                    length += 1
        runs.append(GatherRun(index, length, first, step if first is not None and length > 1 else 0))
        index += length
    return tuple(runs)


@dataclass(frozen=True)
class Preload:
    """Name the accumulator block the next :class:`Compute` writes, and (when ``weight_row`` is not
    ``None``) make that weight block resident first; ``None`` keeps the resident block."""

    weight_row: int | None
    weight_block: tuple[int, int] | None
    accumulator_row: int
    accumulate: bool
    rows: int
    cols: int
    #: Rows the weight block spans (the reduction depth of this step) -- set whether or not this preload
    #: makes a block resident, because a target's preload word carries the depth either way. The
    #: residency check reads it only when ``weight_row`` is set; ``rows`` is the streamed row count the
    #: accumulator block takes.
    weight_rows: int | None = None


@dataclass(frozen=True)
class Compute:
    """Stream ``rows`` rows from ``input_row`` through the resident weight block."""

    input_row: int
    input_block: tuple[int, int]
    rows: int
    cols: int
    fresh_weights: bool
    #: The gather the streamed block must have been loaded with (``None`` for a contiguous block).
    input_gather: tuple[tuple[int, int] | None, ...] | None = None


@dataclass(frozen=True)
class Store:
    """Drain one accumulator block to its DRAM position (in ELEMENTS)."""

    dram_row: int
    dram_col: int
    rows: int
    cols: int
    accumulator_row: int
    # An independently qualified output transformation, distinct from the
    # accumulator's element format. None preserves the original full store.
    readout: str | None = None


@dataclass(frozen=True)
class ColumnBias:
    """Explicit signed accumulator-width modular seed, broadcast across rows."""

    name: str
    columns: int
    bits: int = 32


Op = Load | Preload | Compute | Store | InitializeAccumulator


@dataclass(frozen=True)
class BlockSchedule:
    """An ordered block schedule plus what produced it."""

    ops: tuple[Op, ...]
    contraction: Contraction | ConvContraction
    geometry: Geometry
    knobs: Knobs
    regions: dict[str, tuple[int, int]]  # role -> (first row, row count)
    notes: tuple[str, ...] = ()
    column_bias: ColumnBias | None = None

    def count(self, kind: type) -> int:
        return sum(1 for op in self.ops if isinstance(op, kind))


def _regions(
    rows_needed: dict[str, int], geometry: Geometry, knobs: Knobs
) -> tuple[dict[str, tuple[int, int]], list[str]]:
    """``(role -> (base row, rows), notes)`` for the placement policy. The streamed operand starts at
    row 0; the resident operand's base is the policy's whole content."""
    notes: list[str] = []
    lhs_rows, weight_rows = rows_needed[LHS], rows_needed[WEIGHT]
    if lhs_rows > geometry.operand_rows or weight_rows > geometry.operand_rows:
        raise BlockScheduleError(
            f"one operand alone needs {max(lhs_rows, weight_rows)} rows of a {geometry.operand_rows}-row "
            "store: this contraction has to be tiled before it can be scheduled"
        )
    if knobs.placement == OPPOSITE_END:
        base = geometry.operand_rows - weight_rows
    else:
        if knobs.placement == BANK_ALIGNED and not geometry.operand_bank_rows:
            raise BlockScheduleError(
                "placement 'bank_aligned' needs the store's per-bank row count, which this target's "
                "facts do not give (operand_bank_rows is unknown)"
            )
        wanted = (
            lhs_rows
            if knobs.placement == CONTIGUOUS
            else _ceil_div(lhs_rows, geometry.operand_bank_rows) * geometry.operand_bank_rows
        )
        # A policy that does not fit degrades to the end of the store rather than failing: the two
        # regions then overlap, which is legal exactly when every overwrite lands after the
        # overlapping block's last read -- and check_residency, not this function, decides that.
        if wanted + weight_rows <= geometry.operand_rows:
            base = wanted
        else:
            base = geometry.operand_rows - weight_rows
            notes.append(
                f"placement {knobs.placement!r} wanted row {wanted} but {wanted} + "
                f"{weight_rows} rows exceeds the {geometry.operand_rows}-row store; fell back "
                "to the store's end"
            )
    if base + weight_rows > geometry.operand_rows or base < 0:
        raise BlockScheduleError(
            f"the resident operand's region [{base}, {base + weight_rows}) leaves the {geometry.operand_rows}-row store"
        )
    if base < lhs_rows:
        notes.append(
            f"the two operand regions OVERLAP by {lhs_rows - base} rows; the schedule is only "
            "correct where every overwrite lands after the overlapping block's last read, "
            "which check_residency verifies"
        )
    return {LHS: (0, lhs_rows), WEIGHT: (base, weight_rows)}, notes


def check_residency(schedule: BlockSchedule) -> None:
    """Check synchronous operand residency, accumulator ownership and output coverage.

    This is the class of fault an in-order executor cannot see: it recomputes the same arithmetic on
    whatever bytes are resident, so a schedule that overwrote a block too early produces numbers, not a
    crash. Every read here names the block identity it expects, so an overwrite is caught structurally.
    Reduction prefixes and physical accumulator rows must agree before a store.
    Unknown effects or shared backings without an alias model are refused.
    """
    geometry = schedule.geometry
    for value in (geometry.block, geometry.operand_rows, geometry.accumulator_rows):
        if type(value) is not int or value <= 0:
            raise BlockScheduleError("schedule geometry requires positive integer extents")
    if geometry.separate_accumulator_space is not True:
        raise BlockScheduleError("shared operand/accumulator backing needs an explicit alias model")
    if not isinstance(schedule.contraction, (Contraction, ConvContraction)):
        raise BlockScheduleError("unsupported contraction has no schedule effect contract")
    if schedule.contraction.out in (schedule.contraction.lhs, schedule.contraction.weight):
        raise BlockScheduleError("output alias with an operand needs an explicit lifetime model")
    bias = schedule.column_bias
    n = schedule.contraction.co if isinstance(schedule.contraction, ConvContraction) else schedule.contraction.n
    if bias is not None and (type(bias) is not ColumnBias or type(bias.name) is not str or not bias.name
        or bias.name in (schedule.contraction.lhs, schedule.contraction.weight, schedule.contraction.out)
        or type(bias.columns) is not int or bias.columns != n or type(bias.bits) is not int or bias.bits not in (8,16,32,64)):
        raise BlockScheduleError("column bias requires a distinct complete signed accumulator-width source")
    for op in schedule.ops:
        if not isinstance(op, (Load, Preload, Compute, Store, InitializeAccumulator)):
            raise BlockScheduleError("unknown operation has no schedule effect contract")
        if any(type(value) is not int or not 0 < value <= geometry.block for value in (op.rows, op.cols)):
            raise BlockScheduleError("schedule operation requires positive primitive-bounded extents")
        if isinstance(op, Load):
            addresses = (op.row,)
            if op.role not in ROLES:
                raise BlockScheduleError("unknown load role has no schedule effect contract")
            if op.gather is not None and (op.role != LHS or len(op.gather) != op.rows):
                raise BlockScheduleError("gather must describe exactly the declared input rows")
        elif isinstance(op, InitializeAccumulator):
            if bias is None:
                raise BlockScheduleError("accumulator initialization has no declared source bias")
            addresses = (op.row, op.dram_col)
            if op.row + op.rows > geometry.accumulator_rows:
                raise BlockScheduleError("bias initialization exceeds accumulator rows")
        elif isinstance(op, Preload):
            addresses = (op.accumulator_row,) + (() if op.weight_row is None else (op.weight_row,))
            if op.weight_rows is not None and (
                type(op.weight_rows) is not int or not 0 < op.weight_rows <= geometry.block
            ):
                raise BlockScheduleError("resident weight depth must be a positive primitive-bounded extent")
        elif isinstance(op, Compute):
            addresses = (op.input_row,)
        else:
            addresses = (op.accumulator_row, op.dram_row, op.dram_col)
        if any(type(value) is not int or value < 0 for value in addresses):
            raise BlockScheduleError("schedule addresses require nonnegative integer rows")
    resident: dict[int, tuple] = {}

    def _expect(row: int, rows: int, cols: int, identity: tuple, what: str) -> None:
        for offset in range(rows):
            have = resident.get(row + offset)
            if have is None or have[:3] != identity or have[3] != offset or have[4] < cols:
                if have is None:
                    holds = "nothing loaded"
                elif have[:2] != identity[:2]:
                    holds = str(have[:2])
                else:
                    holds = "that block with a DIFFERENT gather, row offset or width"
                gathered = " with its gather" if identity[2] is not None else ""
                raise BlockScheduleError(
                    f"{what} reads on-chip row {row + offset} expecting block {identity[:2]}{gathered}, "
                    f"but it holds {holds}: the schedule overwrites a block "
                    "that is still live (or never loads it)"
                )

    for op in schedule.ops:
        if isinstance(op, Load):
            if op.row < 0 or op.row + op.rows > geometry.operand_rows:
                raise BlockScheduleError(
                    f"a {op.role} load addresses rows [{op.row}, {op.row + op.rows}) of a "
                    f"{geometry.operand_rows}-row store"
                )
            for offset in range(op.rows):
                resident[op.row + offset] = (op.role, op.block, op.gather, offset, op.cols)
        elif isinstance(op, Preload):
            if op.accumulator_row < 0 or op.accumulator_row + op.rows > geometry.accumulator_rows:
                raise BlockScheduleError(
                    f"a preload addresses accumulator rows [{op.accumulator_row}, "
                    f"{op.accumulator_row + op.rows}) of {geometry.accumulator_rows}"
                )
            if op.weight_row is not None:
                _expect(op.weight_row, op.weight_rows or op.rows, op.cols, (WEIGHT, op.weight_block, None), "a preload")
        elif isinstance(op, Compute):
            _expect(op.input_row, op.rows, op.cols, (LHS, op.input_block, op.input_gather), "a compute")
        elif isinstance(op, Store):
            if op.accumulator_row < 0 or op.accumulator_row + op.rows > geometry.accumulator_rows:
                raise BlockScheduleError(
                    f"a store reads accumulator rows [{op.accumulator_row}, "
                    f"{op.accumulator_row + op.rows}) of {geometry.accumulator_rows}"
                )
    _check_reduction_lifetimes(schedule)


def _check_reduction_lifetimes(schedule: BlockSchedule) -> None:
    """Verify ordered, synchronous reductions and physical accumulator ownership.

    This is the execution model of BlockSchedule, not a hardware completion
    model. An asynchronous adapter must establish its dependencies separately.
    State is proportional to represented rows and output tiles, not elements.
    """
    c, d = schedule.contraction, schedule.geometry.block
    if isinstance(c, ConvContraction):
        m, n = c.pixels, c.co
        channel_blocks = _ceil_div(c.ci, d)
        reduction_blocks = c.kh * c.kw * channel_blocks

        def depth(k):
            return min(d, c.ci - (k % channel_blocks) * d)
    else:
        m, n = c.m, c.n
        reduction_blocks = _ceil_div(c.k, d)

        def depth(k):
            return min(d, c.k - k * d)

    mt, nt = _ceil_div(m, d), _ceil_div(n, d)
    if min(m, n, reduction_blocks) <= 0:
        raise BlockScheduleError("empty contraction has no complete reduction schedule")
    progress: dict[tuple[int, int], int] = {}
    accumulator: dict[int, tuple] = {}
    stored: set[tuple[int, int]] = set()
    initialized: set[tuple[int, int]] = set()
    pending = None
    weight = None
    for op in schedule.ops:
        if isinstance(op, InitializeAccumulator):
            if pending is not None or schedule.column_bias is None:
                raise BlockScheduleError("bias initialization interrupts a preload or lacks source semantics")
            if type(op.block) is not tuple or len(op.block) != 2 or any(type(x) is not int for x in op.block):
                raise BlockScheduleError("bias initialization requires exact output tile identity")
            mi, nj = output = op.block
            if (not (0 <= mi < mt and 0 <= nj < nt) or output in initialized or output in progress or output in stored
                or op.dram_col != nj*d or type(op.source_row_stride) is not int or type(op.source_col_stride) is not int
                or op.source_row_stride != 0 or op.source_col_stride != 1
                or (op.rows,op.cols) != (min(d,m-mi*d),min(d,n-nj*d))):
                raise BlockScheduleError("bias initialization differs from source columns/extent/order")
            for offset in range(op.rows):
                previous = accumulator.get(op.row + offset)
                if previous is not None and previous[0] not in stored:
                    raise BlockScheduleError("bias initialization overwrites a live accumulator")
                accumulator[op.row + offset] = (output, offset, 0, op.cols)
            initialized.add(output)
        elif isinstance(op, Preload):
            if pending is not None:
                raise BlockScheduleError("a preload replaces an unconsumed preload")
            if type(op.accumulate) is not bool:
                raise BlockScheduleError("accumulation policy must be explicit Boolean")
            if op.weight_row is not None:
                weight = (op.weight_block, op.weight_rows if op.weight_rows is not None else op.rows, op.cols)
            elif op.weight_block is not None:
                raise BlockScheduleError("retained weights cannot declare a different weight block")
            pending = op
        elif isinstance(op, Compute):
            if pending is None or weight is None:
                raise BlockScheduleError("a compute needs a preload and resident weight block")
            mi, k = op.input_block
            block, weight_rows, cols = weight
            if block is None or len(block) != 2:
                raise BlockScheduleError("resident weight identity is missing")
            wk, nj = block
            if not (0 <= mi < mt and 0 <= nj < nt and 0 <= k < reduction_blocks) or wk != k:
                raise BlockScheduleError("compute operand identities disagree on the reduction")
            rows = min(d, m - mi * d)
            if (op.rows, op.cols, pending.rows, pending.cols, weight_rows, cols) != (
                rows,
                depth(k),
                rows,
                min(d, n - nj * d),
                depth(k),
                min(d, n - nj * d),
            ):
                raise BlockScheduleError("compute/preload extents differ from the contraction edges")
            if type(op.fresh_weights) is not bool or op.fresh_weights != (pending.weight_row is not None):
                raise BlockScheduleError("compute fresh-weight policy differs from its preload")
            output = (mi, nj)
            if output in stored or progress.get(output, 0) != k:
                raise BlockScheduleError("output reduction is repeated or not in source order")
            if pending.accumulate != (k != 0 or schedule.column_bias is not None):
                raise BlockScheduleError("accumulator initialization/accumulation boundary differs")
            for offset in range(rows):
                row = pending.accumulator_row + offset
                previous = accumulator.get(row)
                if k or schedule.column_bias is not None:
                    if previous != (output, offset, k, cols):
                        raise BlockScheduleError("accumulating compute reads a stale or uninitialized accumulator")
                elif previous is not None and previous[0] not in stored:
                    raise BlockScheduleError("compute overwrites an accumulator whose output is still live")
                accumulator[row] = (output, offset, k + 1, cols)
            progress[output] = k + 1
            pending = None
        elif isinstance(op, Store):
            if pending is not None:
                raise BlockScheduleError("store interrupts an unconsumed preload")
            if op.dram_row < 0 or op.dram_col < 0 or op.dram_row % d or op.dram_col % d:
                raise BlockScheduleError("store output coordinates must identify an aligned output tile")
            output = (op.dram_row // d, op.dram_col // d)
            mi, nj = output
            if output in stored:
                raise BlockScheduleError("output store is duplicated")
            if not (0 <= mi < mt and 0 <= nj < nt) or (op.rows, op.cols) != (min(d, m - mi * d), min(d, n - nj * d)):
                raise BlockScheduleError("store output extent differs from the contraction edges")
            if progress.get(output) != reduction_blocks:
                raise BlockScheduleError("store reads an output before its reduction is complete")
            for offset in range(op.rows):
                if accumulator.get(op.accumulator_row + offset) != (output, offset, reduction_blocks, op.cols):
                    raise BlockScheduleError("store reads the wrong or incomplete accumulator")
            stored.add(output)
    if pending is not None:
        raise BlockScheduleError("schedule leaves an unconsumed preload")
    if len(stored) != mt * nt:
        raise BlockScheduleError("schedule does not store every output tile exactly once")
    if schedule.column_bias is not None and initialized != stored:
        raise BlockScheduleError("bias initialization must cover every output exactly once")


def with_column_bias(schedule: BlockSchedule, source_name: str, *, bits: int = 32, max_operations: int = 65536) -> BlockSchedule:
    """Add an explicit modular column seed before each first reduction preload.

    The already checked zero-seed schedule retains all operand movement, source
    reduction order and stores. Actual effect checks prove seed ownership and
    lifetime after insertion. No hardware load/completion semantics are inferred.
    """
    check_residency(schedule)
    if schedule.column_bias is not None:
        raise BlockScheduleError("schedule already has an explicit accumulator seed")
    n = schedule.contraction.co if isinstance(schedule.contraction,ConvContraction) else schedule.contraction.n
    result=[]; pending=None; weight=None
    for op in schedule.ops:
        if isinstance(op,Preload):
            if op.weight_row is not None:weight=op.weight_block
            pending=(len(result),op,weight)
            result.append(replace(op,accumulate=True))
        else:
            if isinstance(op,Compute) and op.input_block[1]==0:
                index,preload,weight=pending
                output=(op.input_block[0],weight[1])
                result.insert(index,InitializeAccumulator(output,output[1]*schedule.geometry.block,
                    preload.rows,preload.cols,preload.accumulator_row))
            result.append(op)
            if isinstance(op,Compute):pending=None
    if type(max_operations) is not int or max_operations<=0 or len(result)>max_operations:
        raise BlockScheduleError(f"bias schedule exceeds explicit finite operation budget: {len(result)} > {max_operations}")
    changed=replace(schedule,ops=tuple(result),column_bias=ColumnBias(source_name,n,bits))
    check_residency(changed)
    return changed


def schedule_contraction(contraction: Contraction, geometry: Geometry, knobs: Knobs | None = None) -> BlockSchedule:
    """Schedule ``contraction`` on ``geometry`` under ``knobs``, or refuse.

    The nest is ``knobs.loop_order`` -- reduction-major by default (step, then resident-operand block,
    then streamed-operand block), which is what keeps one weight block resident across the streamed
    blocks that read it. ``knobs`` decides the nest, WHERE each load is emitted relative to the computes,
    and where the resident region sits; every order computes the same products, and
    :func:`check_residency` refuses any that would read an overwritten block.
    """
    knobs = knobs or Knobs()
    knobs.validate()
    c = contraction
    if min(c.m, c.k, c.n) <= 0:
        raise BlockScheduleError(f"a {c.m}x{c.k}x{c.n} contraction is empty")
    d = geometry.block
    i_blocks, j_blocks, k_blocks = _ceil_div(c.m, d), _ceil_div(c.n, d), _ceil_div(c.k, d)

    def _lhs_load(mi: int, kk: int, base: int) -> Load:
        return Load(
            LHS,
            (mi, kk),
            mi * d,
            kk * d,
            min(d, c.m - mi * d),
            min(d, c.k - kk * d),
            base + (mi * k_blocks + kk) * d,
            kk,
        )

    def _weight_load(kk: int, nj: int, base: int) -> Load:
        return Load(
            WEIGHT,
            (kk, nj),
            kk * d,
            nj * d,
            min(d, c.k - kk * d),
            min(d, c.n - nj * d),
            base + (kk * j_blocks + nj) * d,
            kk,
        )

    return _schedule_nest(
        c,
        geometry,
        knobs,
        blocks=(k_blocks, j_blocks, i_blocks),
        rows_needed={LHS: i_blocks * k_blocks * d, WEIGHT: k_blocks * j_blocks * d},
        lhs_load=_lhs_load,
        weight_load=_weight_load,
        k_depth=lambda kk: min(d, c.k - kk * d),
        m_rows=lambda mi: min(d, c.m - mi * d),
        n_cols=lambda nj: min(d, c.n - nj * d),
    )


def schedule_convolution(conv: ConvContraction, geometry: Geometry, knobs: Knobs | None = None) -> BlockSchedule:
    """Schedule an NHWC convolution as a gathered contraction, or refuse.

    Reduction blocks are ``(tap row, tap col, channel slice)`` in kernel order, each ``min(block,
    ci - c0)`` channels deep; a streamed block is a block of output pixels whose rows are GATHERED, one
    per pixel, from the input position that tap reads -- or from the target's zero path where the tap
    falls in the padding. The gather depends on the tap and the pixel block only, never on the output
    channel block, which is why ``load_on_index_change`` can load it once per ``(tap, pixel block)``
    instead of once per output-channel block: the same bytes into the same rows, which
    :func:`check_residency` verifies rather than assumes.
    """
    knobs = knobs or Knobs()
    knobs.validate()
    cv = conv
    if min(cv.batch, cv.in_h, cv.in_w, cv.ci, cv.kh, cv.kw, cv.co) <= 0 or cv.out_h <= 0 or cv.out_w <= 0:
        raise BlockScheduleError(f"an empty convolution: {cv}")
    d = geometry.block
    taps = [(kr, kc, c0, min(d, cv.ci - c0)) for kr in range(cv.kh) for kc in range(cv.kw) for c0 in range(0, cv.ci, d)]
    m = cv.pixels
    i_blocks, j_blocks, k_blocks = _ceil_div(m, d), _ceil_div(cv.co, d), len(taps)
    sh, sw = cv.stride
    pt, pl, _, _ = cv.padding
    dh, dw = cv.dilation
    plane = cv.out_h * cv.out_w

    def _gather(mi: int, gi: int) -> tuple[tuple[int, int] | None, ...]:
        kr, kc, c0, _ = taps[gi]
        entries: list[tuple[int, int] | None] = []
        for pixel in range(mi * d, min(m, mi * d + d)):
            batch_index, spatial = divmod(pixel, plane)
            oh, ow = divmod(spatial, cv.out_w)
            ih, iw = oh * sh - pt + kr * dh, ow * sw - pl + kc * dw
            inside = 0 <= ih < cv.in_h and 0 <= iw < cv.in_w
            entries.append(((batch_index * cv.in_h + ih) * cv.in_w + iw, c0) if inside else None)
        return tuple(entries)

    def _lhs_load(mi: int, gi: int, base: int) -> Load:
        gather = _gather(mi, gi)
        return Load(LHS, (mi, gi), -1, -1, len(gather), taps[gi][3], base + (gi * i_blocks + mi) * d, gi, gather)

    def _weight_load(gi: int, nj: int, base: int) -> Load:
        kr, kc, c0, depth = taps[gi]
        return Load(
            WEIGHT,
            (gi, nj),
            (kr * cv.kw + kc) * cv.ci + c0,
            nj * d,
            depth,
            min(d, cv.co - nj * d),
            base + (gi * j_blocks + nj) * d,
            gi,
        )

    return _schedule_nest(
        cv,
        geometry,
        knobs,
        blocks=(k_blocks, j_blocks, i_blocks),
        rows_needed={LHS: k_blocks * i_blocks * d, WEIGHT: k_blocks * j_blocks * d},
        lhs_load=_lhs_load,
        weight_load=_weight_load,
        k_depth=lambda gi: taps[gi][3],
        m_rows=lambda mi: min(d, m - mi * d),
        n_cols=lambda nj: min(d, cv.co - nj * d),
    )


def _schedule_nest(
    contraction: Contraction | ConvContraction,
    geometry: Geometry,
    knobs: Knobs,
    *,
    blocks: tuple[int, int, int],
    rows_needed: dict[str, int],
    lhs_load: Any,
    weight_load: Any,
    k_depth: Any,
    m_rows: Any,
    n_cols: Any,
) -> BlockSchedule:
    """The one block nest both contractions share: regions, the load-due rule, the computes, the drains.

    ``lhs_load(mi, kk, base)`` / ``weight_load(kk, nj, base)`` build the block moves; the three extents
    are ``(K, N, M)`` block counts; ``k_depth`` / ``m_rows`` / ``n_cols`` give a block's edge along each
    axis, so partial edge blocks need no special case here.
    """
    d = geometry.block
    k_blocks, j_blocks, i_blocks = blocks
    regions, notes = _regions(rows_needed, geometry, knobs)
    lhs_base, weight_base = regions[LHS][0], regions[WEIGHT][0]
    ops = _schedule_ops(
        knobs,
        d,
        {K: range(k_blocks), N: range(j_blocks), M: range(i_blocks)},
        lambda mi, kk: lhs_load(mi, kk, lhs_base),
        lambda kk, nj: weight_load(kk, nj, weight_base),
        k_depth,
        m_rows,
        n_cols,
        0,
        0,
        j_blocks,
        k_blocks,
    )
    schedule = BlockSchedule(tuple(ops), contraction, geometry, knobs, regions, tuple(notes))
    check_residency(schedule)
    return schedule


def _schedule_ops(
    knobs, d, indices, lhs_load, weight_load, k_depth, m_rows, n_cols, m_start, n_start, n_span, k_blocks
):
    """Build one panel, continuing global K and storing only at the final reduction."""

    # One emission group per iteration of the two OUTER loops. Each compute carries the loads that
    # become due for it: a block is due the first time a compute needs it -- per group without
    # load_on_index_change, per nest with it. Nothing here names a particular loop as the one whose index
    # change triggers a load; under the default order this is exactly "a streamed block is loaded when its
    # (mi, kk) index first appears", i.e. at nj == 0.
    outer, middle, inner = knobs.loop_order
    groups: list[tuple[int, list[tuple[list[Load], list[Op]]]]] = []
    loaded_in_nest: set[tuple] = set()
    resident_weight: tuple[int, int] | None = None
    for a in indices[outer]:
        for b in indices[middle]:
            loaded_in_group: set[tuple] = set()
            computes: list[tuple[list[Load], list[Op]]] = []
            for c in indices[inner]:
                index = {outer: a, middle: b, inner: c}
                kk, nj, mi = index[K], index[N], index[M]
                weight, streamed = weight_load(kk, nj), lhs_load(mi, kk)
                due: list[Load] = []
                for load in (weight, streamed):
                    identity = (load.role, load.block)
                    seen = loaded_in_nest if knobs.load_on_index_change else loaded_in_group
                    if identity not in seen:
                        seen.add(identity)
                        due.append(load)
                rows, cols = m_rows(mi), n_cols(nj)
                acc_row = ((mi - m_start) * n_span + nj - n_start) * d
                fresh = resident_weight != (kk, nj)
                resident_weight = (kk, nj)
                ops_here: list[Op] = [
                    Preload(
                        weight.row if fresh else None,
                        (kk, nj) if fresh else None,
                        acc_row,
                        kk > 0,
                        rows,
                        cols,
                        k_depth(kk),
                    ),
                    Compute(streamed.row, (mi, kk), rows, k_depth(kk), fresh, streamed.gather),
                ]
                if kk == k_blocks - 1:
                    ops_here.append(Store(mi * d, nj * d, rows, cols, acc_row))
                computes.append((due, ops_here))
            groups.append((a, computes))

    return _emit(groups, knobs)


@dataclass(frozen=True)
class ConvolutionPanel:
    """Operation range after which operand rows may be reused.

    Accumulators stay live across K panels until the final K panel stores them.
    This logical boundary supplies no target fence or asynchronous completion.
    """

    m_start: int
    n_start: int
    k_start: int
    m_blocks: int
    n_blocks: int
    k_blocks: int
    first_operation: int
    end_operation: int


@dataclass(frozen=True)
class TiledConvolutionSchedule:
    schedule: BlockSchedule
    panels: tuple[ConvolutionPanel, ...]
    m_blocks: int
    n_blocks: int
    k_blocks: int
    candidates_considered: int
    requested_operand_elements: int


def schedule_tiled_convolution(
    conv: ConvContraction,
    geometry: Geometry,
    knobs: Knobs | None = None,
    *,
    candidate_budget: int = 4096,
    max_operations: int = 1_000_000,
) -> TiledConvolutionSchedule:
    """Keep output panels live while streaming bounded, reusable reduction panels.

    This target-independent family preserves NHWC gathers, tails and original
    tap/channel reduction order. Operand rows are reused between K panels; live
    output rows are reused only after stores. Candidates minimize requested
    operand ELEMENTS (including padding zeros), not bytes, traffic or cycles.
    For each M/N candidate, the largest fitting K panel minimizes panel count.
    Bias, output conversion and physical completion stay with the caller. A
    target must establish exact continuation and completion before consumption.
    This finite schedule is bounded before expansion; it emits no hardware loop.
    """
    knobs = knobs or Knobs()
    knobs.validate()
    cv, d = conv, geometry.block
    sizes = (
        candidate_budget,
        max_operations,
        d,
        geometry.operand_rows,
        geometry.accumulator_rows,
        cv.batch,
        cv.in_h,
        cv.in_w,
        cv.ci,
        cv.kh,
        cv.kw,
        cv.co,
    )
    if any(type(x) is not int or x <= 0 for x in sizes):
        raise BlockScheduleError("tiled convolution requires positive integer geometry and budgets")
    if (
        len(cv.stride) != 2
        or len(cv.dilation) != 2
        or len(cv.padding) != 4
        or any(type(x) is not int or x <= 0 for x in (*cv.stride, *cv.dilation))
        or any(type(x) is not int or x < 0 for x in cv.padding)
    ):
        raise BlockScheduleError("tiled convolution needs positive stride/dilation and nonnegative padding")
    if cv.out_h <= 0 or cv.out_w <= 0:
        raise BlockScheduleError("tiled convolution has no output pixels")
    if geometry.separate_accumulator_space is not True:
        raise BlockScheduleError("tiled convolution requires separate operand and accumulator stores")
    if knobs.placement == BANK_ALIGNED and (
        type(geometry.operand_bank_rows) is not int or geometry.operand_bank_rows <= 0
    ):
        raise BlockScheduleError("bank_aligned placement requires positive known operand_bank_rows")
    kt = cv.kh * cv.kw * _ceil_div(cv.ci, d)
    mt, nt = _ceil_div(cv.pixels, d), _ceil_div(cv.co, d)
    # Reject oversized proposals before materializing taps, gathers or operations.
    if 2 * mt * nt * kt + mt * nt > max_operations:
        raise BlockScheduleError("tiled convolution exceeds its finite operation budget")
    max_m = min(mt, geometry.accumulator_rows // d, geometry.operand_rows // d - 1)
    max_n = min(nt, geometry.accumulator_rows // d, geometry.operand_rows // d - 1)
    if max_m <= 0 or max_n <= 0:
        raise BlockScheduleError("one primitive block per operand and output does not fit")
    if max_m * max_n > candidate_budget:
        raise BlockScheduleError("tiled convolution search exceeds its explicit candidate budget")
    best, considered = None, 0
    source_k = cv.kh * cv.kw * cv.ci
    for bm in range(1, max_m + 1):
        for bn in range(1, max_n + 1):
            considered += 1
            bk = min(kt, geometry.operand_rows // ((bm + bn) * d))
            if bm * bn * d > geometry.accumulator_rows or bk == 0:
                continue
            regions, notes = _regions({LHS: bm * bk * d, WEIGHT: bn * bk * d}, geometry, knobs)
            lhs_repeats = _ceil_div(nt, bn) if knobs.load_on_index_change or knobs.loop_order[-1] == N else nt
            rhs_repeats = _ceil_div(mt, bm) if knobs.load_on_index_change or knobs.loop_order[-1] == M else mt
            loads = mt * kt * lhs_repeats + nt * kt * rhs_repeats
            commands = 2 * mt * nt * kt + mt * nt + loads
            if commands > max_operations:
                continue
            requested = cv.pixels * source_k * lhs_repeats + source_k * cv.co * rhs_repeats
            key = (requested, loads, _ceil_div(kt, bk), bm + bn, bm, bn)
            if best is None or key < best[0]:
                best = key, bm, bn, bk, regions, notes
    if best is None:
        raise BlockScheduleError("no output panel satisfies storage and finite operation budgets")
    key, bm, bn, bk, regions, notes = best
    taps = [(ky, kx, ci, min(d, cv.ci - ci)) for ky in range(cv.kh) for kx in range(cv.kw) for ci in range(0, cv.ci, d)]
    operations, panels = [], []
    for m0 in range(0, mt, bm):
        for n0 in range(0, nt, bn):
            for k0 in range(0, kt, bk):
                mr, nr, kr = min(bm, mt - m0), min(bn, nt - n0), min(bk, kt - k0)

                def lhs(mi, kk, m_base=m0, k_base=k0):
                    ky, kx, ci, depth = taps[kk]
                    gather = []
                    for pixel in range(mi * d, min(cv.pixels, (mi + 1) * d)):
                        image, spatial = divmod(pixel, cv.out_h * cv.out_w)
                        y, x = divmod(spatial, cv.out_w)
                        iy = y * cv.stride[0] - cv.padding[0] + ky * cv.dilation[0]
                        ix = x * cv.stride[1] - cv.padding[1] + kx * cv.dilation[1]
                        gather.append(
                            ((image * cv.in_h + iy) * cv.in_w + ix, ci)
                            if 0 <= iy < cv.in_h and 0 <= ix < cv.in_w
                            else None
                        )
                    return Load(
                        LHS,
                        (mi, kk),
                        -1,
                        -1,
                        len(gather),
                        depth,
                        regions[LHS][0] + ((kk - k_base) * bm + mi - m_base) * d,
                        kk,
                        tuple(gather),
                    )

                def rhs(kk, nj, n_base=n0, k_base=k0):
                    ky, kx, ci, depth = taps[kk]
                    return Load(
                        WEIGHT,
                        (kk, nj),
                        (ky * cv.kw + kx) * cv.ci + ci,
                        nj * d,
                        depth,
                        min(d, cv.co - nj * d),
                        regions[WEIGHT][0] + ((kk - k_base) * bn + nj - n_base) * d,
                        kk,
                    )

                start = len(operations)
                operations.extend(
                    _schedule_ops(
                        knobs,
                        d,
                        {K: range(k0, k0 + kr), M: range(m0, m0 + mr), N: range(n0, n0 + nr)},
                        lhs,
                        rhs,
                        lambda kk: taps[kk][3],
                        lambda mi: min(d, cv.pixels - mi * d),
                        lambda nj: min(d, cv.co - nj * d),
                        m0,
                        n0,
                        bn,
                        kt,
                    )
                )
                panels.append(ConvolutionPanel(m0, n0, k0, mr, nr, kr, start, len(operations)))
    if len(operations) > max_operations:
        raise BlockScheduleError("actual emitted schedule exceeds its finite operation budget")
    schedule = BlockSchedule(tuple(operations), cv, geometry, knobs, regions, tuple(notes))
    check_residency(schedule)
    return TiledConvolutionSchedule(schedule, tuple(panels), bm, bn, bk, considered, key[0])


@dataclass(frozen=True)
class SpatialMaxReadout:
    """Source spatial max after an explicitly bound signed scalar readout.

    Padding is in the post-readout integer domain. This declaration supplies no
    physical pooling implementation or completion semantics.
    """
    input_hw: tuple[int, int]
    window: tuple[int, int]
    stride: tuple[int, int]
    padding: tuple[int, int, int, int] = (0, 0, 0, 0)  # top,left,bottom,right
    pad_value: int | None = None
    accumulator_bits: int = 32
    output_bits: int = 8

    def __post_init__(self):
        for values, length, minimum in ((self.input_hw,2,1),(self.window,2,1),
                                        (self.stride,2,1),(self.padding,4,0)):
            if (type(values) is not tuple or len(values)!=length
                or any(type(v) is not int or not minimum<=v<2**31 for v in values)):
                raise BlockScheduleError("spatial readout requires explicit bounded integer geometry")
        if any(type(v) is not int or v not in (8,16,32,64) for v in (self.accumulator_bits,self.output_bits)):
            raise BlockScheduleError("spatial readout requires explicit signed integer widths")
        if self.pad_value is not None and (type(self.pad_value) is not int
            or not -(1<<(self.output_bits-1))<=self.pad_value<(1<<(self.output_bits-1))):
            raise BlockScheduleError("padding must be in the post-readout signed domain")
        if any(self.padding) and self.pad_value is None:
            raise BlockScheduleError("padded spatial readout requires an explicit numerical padding value")
        if min(self.output_hw)<=0:
            raise BlockScheduleError("spatial readout has no output positions")

    @property
    def output_hw(self):
        h,w=self.input_hw;kh,kw=self.window;sh,sw=self.stride;pt,pl,pb,pr=self.padding
        return ((h+pt+pb-kh)//sh+1,(w+pl+pr-kw)//sw+1)


@dataclass(frozen=True)
class SpatialStore:
    batch: int
    first_column: int
    columns: int
    accumulator_base: int
    output_row: int
    # Each output pixel names its complete ordered input-window rows. None is
    # the explicit source padding value; all columns share this spatial map.
    window_rows: tuple[tuple[int | None, ...], ...]
    readout: str


@dataclass(frozen=True)
class SpatialReadoutSchedule:
    retained: BlockSchedule
    prefix: tuple[Op, ...]
    stores: tuple[SpatialStore, ...]
    source: SpatialMaxReadout
    readout: str
    first_row: int
    max_window_reads: int


def retain_accumulator_outputs(schedule: BlockSchedule, *, first_row: int = 0) -> BlockSchedule:
    """Preserve every output until the final drain, in column-block-major rows.

    This finite relayout consumes the checked original schedule, preserves every
    movement/product and rechecks actual accumulator ownership after moving the
    stores. It refuses when the complete retained output does not fit.
    """
    check_residency(schedule)
    if type(first_row) is not int or first_row<0:
        raise BlockScheduleError("retained accumulator base must be nonnegative")
    c=schedule.contraction;d=schedule.geometry.block
    m=c.batch*c.out_h*c.out_w if isinstance(c,ConvContraction) else c.m
    n=c.co if isinstance(c,ConvContraction) else c.n
    padded_m=((m+d-1)//d)*d;nt=(n+d-1)//d
    if first_row+padded_m*nt>schedule.geometry.accumulator_rows:
        raise BlockScheduleError("complete spatial source exceeds retained accumulator capacity")
    def row(tile):return first_row+tile[1]*padded_m+tile[0]*d
    prefix=[];stores=[];pending=None;weight=None
    for op in schedule.ops:
        if isinstance(op,InitializeAccumulator):prefix.append(replace(op,row=row(op.block)))
        elif isinstance(op,Preload):
            if op.weight_row is not None:weight=op.weight_block
            pending=(len(prefix),op,weight);prefix.append(op)
        elif isinstance(op,Compute):
            index,preload,current_weight=pending
            prefix[index]=replace(preload,accumulator_row=row((op.input_block[0],current_weight[1])))
            prefix.append(op);pending=None
        elif isinstance(op,Store):stores.append(replace(op,accumulator_row=row((op.dram_row//d,op.dram_col//d))))
        else:prefix.append(op)
    changed=replace(schedule,ops=tuple(prefix+stores))
    check_residency(changed)
    return changed


def _spatial_stores(schedule, source, readout, first_row, max_window_reads):
    if type(source) is not SpatialMaxReadout or type(readout) is not str or not readout:
        raise BlockScheduleError("spatial readout requires its exact typed source and scalar identity")
    if type(max_window_reads) is not int or max_window_reads<=0:
        raise BlockScheduleError("spatial readout needs an explicit finite window budget")
    c=schedule.contraction;d=schedule.geometry.block
    m=c.batch*c.out_h*c.out_w if isinstance(c,ConvContraction) else c.m
    n=c.co if isinstance(c,ConvContraction) else c.n
    h,w=source.input_hw;oh,ow=source.output_hw;kh,kw=source.window;sh,sw=source.stride;pt,pl,_,_=source.padding
    if m%(h*w):raise BlockScheduleError("spatial planes must cover all contraction rows exactly")
    batches=m//(h*w);padded_m=((m+d-1)//d)*d;nt=(n+d-1)//d
    reads=batches*oh*ow*kh*kw*nt
    if reads>max_window_reads:
        raise BlockScheduleError(f"spatial readout exceeds explicit finite window budget: {reads} > {max_window_reads}")
    result=[]
    for b in range(batches):
        for j in range(nt):
            base=first_row+j*padded_m+b*h*w
            windows=tuple(tuple(base+(y*sh+ky-pt)*w+(x*sw+kx-pl)
                if 0<=y*sh+ky-pt<h and 0<=x*sw+kx-pl<w else None
                for ky in range(kh) for kx in range(kw))for y in range(oh)for x in range(ow))
            result.append(SpatialStore(b,j*d,min(d,n-j*d),base,b*oh*ow,windows,readout))
    return tuple(result)


def plan_spatial_max_readout(schedule: BlockSchedule, source: SpatialMaxReadout, readout: str,
                             *, first_row: int = 0, max_window_reads: int = 65536) -> SpatialReadoutSchedule:
    retained=retain_accumulator_outputs(schedule,first_row=first_row)
    prefix=tuple(op for op in retained.ops if not isinstance(op,Store))
    stores=_spatial_stores(retained,source,readout,first_row,max_window_reads)
    result=SpatialReadoutSchedule(retained,prefix,stores,source,readout,first_row,max_window_reads)
    check_spatial_max_readout(result,source=source,readout=readout)
    return result


def check_spatial_max_readout(result: SpatialReadoutSchedule, *, source: SpatialMaxReadout, readout: str) -> None:
    """Check all retained source products, final lifetimes and spatial reads/writes.

    These are compiler-side conditional checks. Scalar numerical equivalence,
    target readout semantics and actual emitted effects remain separate checks.
    """
    if type(result) is not SpatialReadoutSchedule or result.source!=source or result.readout!=readout:
        raise BlockScheduleError("spatial readout source or scalar contract changed")
    check_residency(result.retained)
    expected=retain_accumulator_outputs(result.retained,first_row=result.first_row)
    if result.retained!=expected or result.prefix!=tuple(op for op in expected.ops if not isinstance(op,Store)):
        raise BlockScheduleError("spatial readout must consume the complete retained contraction before draining")
    if any(op.readout is not None for op in expected.ops if isinstance(op,Store)):
        raise BlockScheduleError("spatial source must retain raw accumulators; scalar readout belongs to its drain")
    if result.stores!=_spatial_stores(expected,source,readout,result.first_row,result.max_window_reads):
        raise BlockScheduleError("spatial readout coverage, layout, padding or scalar identity changed")
    if expected.column_bias is not None and expected.column_bias.bits!=source.accumulator_bits:
        raise BlockScheduleError("spatial accumulator width differs from its modular bias seed")


def execute_spatial_max_readout(result: SpatialReadoutSchedule, lhs: Any, weight: Any,
                                scalar_readout: Any, *, bias: Any = None) -> Any:
    """Neutral numerical execution; it is not a target readout implementation."""
    import numpy as np
    check_spatial_max_readout(result,source=result.source,readout=result.readout)
    source=result.source;raw=execute(result.retained,lhs,weight,bias=bias).astype(f"int{source.accumulator_bits}")
    h,w=source.input_hw;oh,ow=source.output_hw;m,n=raw.shape;d=result.retained.geometry.block;padded_m=((m+d-1)//d)*d
    output=np.zeros((m//(h*w)*oh*ow,n),dtype=f"int{source.output_bits}")
    low,high=-(1<<(source.output_bits-1)),(1<<(source.output_bits-1))-1
    for store in result.stores:
        for pixel,window in enumerate(store.window_rows):
            for column in range(store.columns):
                values=[]
                for address in window:
                    if address is None:value=source.pad_value
                    else:
                        row=address-result.first_row-(store.first_column//d)*padded_m
                        value=scalar_readout(int(raw[row,store.first_column+column]))
                    if type(value) is not int or not low<=value<=high:
                        raise BlockScheduleError("scalar readout result differs from declared signed output domain")
                    values.append(value)
                output[store.output_row+pixel,store.first_column+column]=max(values)
    return output


def execute(schedule: BlockSchedule, lhs: Any, weight: Any, *, bias: Any = None) -> Any:
    """Run ``schedule`` on host arrays exactly as an in-order device would, and return the output.

    The schedule's own oracle: every row a load writes, every block a preload makes resident, every
    accumulate and every drain is simulated at the addresses the schedule names -- nothing is recomputed
    from the contraction. So a schedule that addresses the wrong rows, drains the wrong accumulator block
    or reuses a stale resident block produces a wrong ``out``, which a direct ``lhs @ weight`` exposes in
    milliseconds, before any backend or simulator is involved.
    """
    import numpy as np

    c = schedule.contraction
    lhs, weight = np.asarray(lhs), np.asarray(weight)
    if isinstance(c, ConvContraction):
        want_lhs, want_weight, out_shape = (
            (c.batch * c.in_h * c.in_w, c.ci),
            (c.kh * c.kw * c.ci, c.co),
            (c.pixels, c.co),
        )
    else:
        want_lhs, want_weight, out_shape = (c.m, c.k), (c.k, c.n), (c.m, c.n)
    if lhs.shape != want_lhs or weight.shape != want_weight:
        raise BlockScheduleError(
            f"operands {lhs.shape} x {weight.shape} are not the scheduled {want_lhs} x {want_weight}"
        )
    if schedule.column_bias is None:
        if bias is not None:raise BlockScheduleError("undeclared bias operand")
    else:
        check_residency(schedule)
        bias = np.asarray(bias)
        if bias.shape != (out_shape[1],) or bias.dtype != np.dtype(f'int{schedule.column_bias.bits}'):
            raise BlockScheduleError("bias values differ from exact source columns/accumulator width")
        if not all(np.issubdtype(x.dtype,np.signedinteger) for x in (lhs,weight)):
            raise BlockScheduleError("modular bias execution requires signed integer operands")
    dram = {LHS: lhs, WEIGHT: weight}
    rows_on_chip: dict[int, Any] = {}
    accumulator: dict[int, Any] = {}
    out = np.zeros(out_shape, dtype=np.result_type(lhs, weight, np.int64) if schedule.column_bias is None else bias.dtype)
    resident = None
    target_row, accumulate = None, False

    def _row(row: int, what: str) -> Any:
        if row not in rows_on_chip:
            raise BlockScheduleError(f"{what} reads on-chip row {row}, which no load ever wrote")
        return rows_on_chip[row]

    def _accumulated(row: int, what: str) -> Any:
        if row not in accumulator:
            raise BlockScheduleError(f"{what} reads accumulator block {row}, which no compute ever wrote")
        return accumulator[row]

    for op in schedule.ops:
        if isinstance(op, InitializeAccumulator):
            accumulator[op.row] = np.broadcast_to(bias[op.dram_col:op.dram_col+op.cols],(op.rows,op.cols)).copy()
        elif isinstance(op, Load):
            source = dram[op.role]
            if op.gather is not None:
                for offset, entry in enumerate(op.gather):
                    rows_on_chip[op.row + offset] = (
                        np.zeros(op.cols, dtype=source.dtype)
                        if entry is None
                        else source[entry[0], entry[1] : entry[1] + op.cols].copy()
                    )
                continue
            block = source[op.dram_row : op.dram_row + op.rows, op.dram_col : op.dram_col + op.cols]
            for offset in range(op.rows):
                rows_on_chip[op.row + offset] = block[offset].copy()
        elif isinstance(op, Preload):
            if op.weight_row is not None:
                resident = np.stack(
                    [_row(op.weight_row + r, "a preload")[: op.cols] for r in range(op.weight_rows or op.rows)]
                )
            target_row, accumulate = op.accumulator_row, op.accumulate
        elif isinstance(op, Compute):
            if resident is None:
                raise BlockScheduleError("a compute ran with no resident block")
            streamed = np.stack([_row(op.input_row + r, "a compute")[: op.cols] for r in range(op.rows)])
            product = streamed.astype(out.dtype) @ resident.astype(out.dtype)
            if accumulate:
                accumulator[target_row] = _accumulated(target_row, "an accumulating compute") + product
            else:
                accumulator[target_row] = product
        elif isinstance(op, Store):
            if op.readout is not None:
                raise BlockScheduleError("block execution has no qualified implementation of the selected readout")
            out[op.dram_row : op.dram_row + op.rows, op.dram_col : op.dram_col + op.cols] = _accumulated(
                op.accumulator_row, "a store"
            )[: op.rows, : op.cols]
    return out


def _ordered(loads: list[Load], knobs: Knobs) -> list[Load]:
    """The loads of one emission group, ordered by ``load_grouping`` (stable within a role)."""
    if knobs.load_grouping == NEST:
        return list(loads)
    ordered: list[Load] = []
    for role in knobs.operand_order:
        ordered.extend(load for load in loads if load.role == role)
    return ordered


def _emit(groups: list[tuple[int, list[tuple[list[Load], list[Op]]]]], knobs: Knobs) -> list[Op]:
    """Place each group's loads relative to the computes, per ``lookahead_steps``.

    At depth 0 the emission group is one iteration of the two outer loops, and a load sits in its nest
    position -- immediately before the compute that first needs it -- or, under ``ROLE`` grouping, with
    the group's other loads ahead of its computes. At depth ``d`` the group is a whole outer step, issued
    ``d`` steps early. At ``None`` every load is hoisted ahead of every compute, and the whole prologue is
    one group.
    """
    if knobs.lookahead_steps == 0:
        ops: list[Op] = []
        for _, computes in groups:
            if knobs.load_grouping == NEST:
                for due, body in computes:
                    ops.extend(due)
                    ops.extend(body)
            else:
                ops.extend(_ordered([load for due, _ in computes for load in due], knobs))
                ops.extend(op for _, body in computes for op in body)
        return ops

    by_step: dict[int, list[Load]] = {}
    bodies: dict[int, list[Op]] = {}
    for step, computes in groups:
        by_step.setdefault(step, []).extend(load for due, _ in computes for load in due)
        bodies.setdefault(step, []).extend(op for _, body in computes for op in body)
    steps = sorted(bodies)
    if knobs.lookahead_steps is None:
        prologue: list[Load] = []
        for step in steps:
            prologue.extend(by_step.get(step, ()))
        ops = list(_ordered(prologue, knobs))
        for step in steps:
            ops.extend(bodies[step])
        return ops

    depth = knobs.lookahead_steps
    ops = []
    for step in steps[:depth]:
        ops.extend(_ordered(by_step.get(step, []), knobs))
    for index, step in enumerate(steps):
        ahead = index + depth
        if ahead < len(steps):
            ops.extend(_ordered(by_step.get(steps[ahead], []), knobs))
        ops.extend(bodies[step])
    return ops


def schedule_interface_program(
    tensors: dict[str, Any], commands: list[dict[str, Any]], geometry: Geometry, knobs: Knobs | None = None
) -> list[BlockSchedule]:
    """Schedule every resident matmul an interface program commits, and every convolution, in program
    order.

    ``tensors`` maps a name to that tensor's spec (anything with ``shape``, or a mapping carrying
    ``"shape"``); ``commands`` is the program's command list. Any other command -- a convolution, a
    movement, an epilogue this pass does not model -- is a refusal, so a caller never receives a
    schedule that silently dropped work.
    """
    resident_of: dict[str, str] = {}
    pending: dict[str, tuple[str, str]] = {}
    schedules: list[BlockSchedule] = []
    for command in commands:
        opcode = command.get("opcode")
        operands = command.get("operands", {})
        if opcode == "RES_PACK":
            resident_of[operands["dst"]] = operands["src"]
        elif opcode == "MATMUL_RESIDENT":
            rhs = operands["rhs"]
            if rhs not in resident_of:
                raise BlockScheduleError(f"{rhs!r} is used as a resident operand before it is packed")
            pending[operands["dst"]] = (operands["lhs"], resident_of[rhs])
        elif opcode == "COMMIT":
            src = operands["src"]
            if src not in pending:
                raise BlockScheduleError(f"commit of {src!r}, which no matmul produced")
            lhs_name, weight_name = pending.pop(src)
            attributes = command.get("attributes", {}) or {}
            epilogue = tuple(attributes.get("epilogue", ()) or ())
            unsupported = [e for e in epilogue if e not in ("relu", "acc_scale")]
            if unsupported:
                raise BlockScheduleError(
                    f"epilogue {unsupported} changes which accumulator block a store drains; this pass "
                    "schedules block moves only and will not guess that mapping"
                )
            m, k = _shape(tensors, lhs_name)
            wk, n = _shape(tensors, weight_name)
            if wk != k:
                raise BlockScheduleError(f"contraction mismatch: {lhs_name} is {m}x{k}, {weight_name} is {wk}x{n}")
            schedules.append(
                schedule_contraction(Contraction(m, k, n, lhs_name, weight_name, operands["dst"]), geometry, knobs)
            )
        elif opcode == "CONV2D":
            schedules.append(_conv_command(tensors, command, resident_of, geometry, knobs))
        elif opcode != "EVICT":
            raise BlockScheduleError(
                f"{opcode!r} is neither a resident matmul nor a convolution; this pass "
                "schedules those only, and refuses rather than dropping the command"
            )
    return schedules


def _conv_command(
    tensors: dict[str, Any],
    command: dict[str, Any],
    resident_of: dict[str, str],
    geometry: Geometry,
    knobs: Knobs | None,
) -> BlockSchedule:
    """One ``CONV2D`` command as a :class:`ConvContraction`, refusing what the nest cannot express."""
    operands, attributes = command.get("operands", {}) or {}, command.get("attributes", {}) or {}
    missing = [key for key in ("ifm", "weight", "dst") if key not in operands]
    missing += [key for key in ("kernel",) if key not in attributes]
    if missing:
        raise BlockScheduleError(f"a CONV2D command missing {missing}; refusing rather than guessing them")
    epilogue = tuple(attributes.get("epilogue", ()) or ())
    unsupported = [e for e in epilogue if e not in ("relu", "acc_scale")]
    if unsupported:
        # Pooling drains the accumulator N-major and defers every drain past the nest: a different
        # accumulator LAYOUT, not an ordering choice, so it is refused rather than approximated.
        raise BlockScheduleError(
            f"epilogue {unsupported} changes which accumulator block a store drains; "
            "this pass schedules block moves only and will not guess that mapping"
        )
    if attributes.get("layout", "nhwc") != "nhwc":
        raise BlockScheduleError(f"conv layout {attributes.get('layout')!r}; this pass schedules NHWC")
    weight = operands["weight"]
    if weight not in resident_of:
        raise BlockScheduleError(f"{weight!r} is used as a resident operand before it is packed")
    ifm = _shape_nd(tensors, operands["ifm"], 4)
    kh, kw, kci, co = (int(v) for v in attributes["kernel"])
    batch, in_h, in_w, ci = ifm
    if kci != ci:
        raise BlockScheduleError(f"kernel expects {kci} input channels, the input has {ci}")
    packed = _shape_nd(tensors, resident_of[weight], 2)
    if packed != (kh * kw * ci, co):
        raise BlockScheduleError(
            f"conv weight {resident_of[weight]!r} is {packed}, not the pre-im2col {(kh * kw * ci, co)}"
        )
    conv = ConvContraction(
        batch,
        in_h,
        in_w,
        ci,
        kh,
        kw,
        co,
        tuple(int(v) for v in attributes.get("stride", (1, 1))),
        tuple(int(v) for v in attributes.get("padding", (0, 0, 0, 0))),
        tuple(int(v) for v in attributes.get("dilation", (1, 1))),
        operands["ifm"],
        resident_of[weight],
        operands["dst"],
    )
    return schedule_convolution(conv, geometry, knobs)


def _shape_nd(tensors: dict[str, Any], name: str, rank: int) -> tuple[int, ...]:
    spec = tensors.get(name)
    if spec is None:
        raise BlockScheduleError(f"the program names no tensor {name!r}")
    shape = spec["shape"] if isinstance(spec, dict) else getattr(spec, "shape", None)
    if shape is None or len(shape) != rank:
        raise BlockScheduleError(f"{name!r} has shape {shape!r}; expected rank {rank}")
    return tuple(int(v) for v in shape)


def _shape(tensors: dict[str, Any], name: str) -> tuple[int, int]:
    spec = tensors.get(name)
    if spec is None:
        raise BlockScheduleError(f"the program names no tensor {name!r}")
    shape = spec["shape"] if isinstance(spec, dict) else getattr(spec, "shape", None)
    if shape is None or len(shape) != 2:
        raise BlockScheduleError(f"{name!r} has shape {shape!r}; this pass schedules 2-D operands")
    return int(shape[0]), int(shape[1])
