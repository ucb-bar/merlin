# Scoped configuration hoisting — qualification preparation

F native qualification is HELD for root review of the coherent Q host cut. This
page proposes a conditional claim; phase1 captures/tests are not qualification.
The previous configuration-elision result is separately sealed/published and is
not reused as a hoist correctness theorem.

## Intended theorem and actual source

`ActualConfigurationHoist.complete_kernel` instantiates the new partial-hoist
checker on the complete actual before/after Kernel. It preserves successful
complete state or the same first error and terminal state, under one indexed
partial retained-call interpretation and exact total pure setup overwrite.
The loop has a positive constant extent, exactly one invariant setter prefix,
nonempty flat body and unchanged surrounding calls. All body writes/clobbers are
disjoint from setup fields. No source-success or whole-run-equivalence premise.
Successful body-frame steps, not total-body assumptions, justify removing the
later setters. Existing total hoist_nonempty alone is insufficient.

The actual producer is e0484f4886ae0780d0325cdfa998842b61bb647c in read-only
merlin-dce-cse-integration. Root bb3545... manifest binds2009original Python files;
F retained loaded refs match it. Python parsing/import delivery, original codec/
effect decoding, field-to-state identity and primitive meaning are explicit review
boundaries. Pure setup has no failure/token/pulse/memory/observer effect. Other
state includes all caller/return/memory/observations. Actual ISA/hardware/numerical
agreement and human effect-policy approval remain unestablished.

## Worked before/after awaiting fresh gate output

F/actual-producer-v1/baseline_extent3/{source.mk,final.mk} are complete actual
Kernel programs with input/output buffers, metadata, an earlier unknown call,
three loop iterations and a later work observer. The producer moves pair(3,5)
from the start of the loop to immediately before it, retaining both work calls
in each iteration. Exact Kernel/mk parser roundtrips and structural validation
cover both outputs. These are not MLIR buffers or LLVM execution evidence.

| Actual data | Checker terms / explicit boundary |
| --- | --- |
| Kernel name, every tensor shape/dtype/access and attrs | Complete frame string equality |
| Every Call and argument expression, annotations and value bits | Full typed dataclass token, dense original static IDs, identical atom table |
| Loop variable, extent, body and all completion metadata | Explicit Loop fields; source/target templates force iter_args/yields/results empty |
| Actual integer operands, schema fields/values, reads/writes/clobbers | Finite injective field registry and Elision.Effect; original decoder/model agreement remains trusted |
| Earlier/setup/body/later complete ordered roster | Exact checked move and complete source/target command patterns |
| Indexed calls, arbitrary errors and observations | New partial execution theorem and surrounding-context/observer roots |
| Gate/consumer/replay | Pending canonical-only fresh object/root/std3 audit and exact source/artifact/live-authority checks |

## Fixed corpus and preserved counterexamples

Seven actual changed cases cover extents1/3/7, surrounding observations, disjoint
body write/clobber and unsigned64other-field values. Extent1 has a static move
but no saved dynamic setup execution. Nine unsupported boundaries include the
new producer's same-value overlap, multiple prefixes and nested-loop cases;
physical non-hoists are separate, not counted as changed positives.

Fifteen complete wrong outputs are Kernel-parse/structure valid. A separate valid
token-counterpair changes only the incoming loop token; the existing producer
rewrite verifier accepts it, so independent host/Lean empty-token checks are
required. This is not a refutation of the optimizer's generated result. Five
malformed controls are refused separately; zero-trip and hidden-setter-pulse
finite-model counterexamples explain material premises.192finite state/error
comparisons and16SDK-free source/diagnostic controls are tests, not proofs.

Once root releases the coherent canonical host cut, the prepared F controller
checks all seven positives, valid mutants and boundary refusals, every15final/
support root type/std3/import, exact final consumer, fresh separate-process replay
and genuine live-artifact/token guards. Any first infrastructure failure stops
further native work with original raw/source/cleanup retained. No previous profile
is promoted. No compiler-wide enforcement, async/token interpretation, pipeline,
numerical/native/hardware proof or adjacent-model composition claim is proposed.
