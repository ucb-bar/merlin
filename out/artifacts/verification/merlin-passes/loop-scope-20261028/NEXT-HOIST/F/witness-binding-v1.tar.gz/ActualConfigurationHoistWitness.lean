/- Constructive source-bound model for the ACTUAL e048 hoist fixture. It records
iteration/call order and success or first failure. This is not native numeric,
ISA, memory-ABI or completion-token fidelity. -/
import ActualConfigurationHoist

namespace ActualConfigurationHoistWitness
open Merlin.StateEffects Merlin.GraphState
open Merlin.GraphState.Configuration
set_option autoImplicit false
set_option maxHeartbeats 2000000

def pairEffect : Elision.Effect := ⟨[],[(0,3),(1,5)],[],true,true⟩
def workEffect : Elision.Effect := ⟨[(0,3),(1,5)],[],[],true,false⟩
def workID (id : Nat) : Prop := id = 2 ∨ id = 3 ∨ id = 4
instance (id : Nat) : Decidable (workID id) := inferInstanceAs (Decidable (id = 2 ∨ id = 3 ∨ id = 4))
def Supported (id : Nat) (atom : Elision.Atom) : Prop :=
  (id = 0 ∧ atom.effect = none) ∨ (id = 1 ∧ atom.effect = some pairEffect) ∨
    (workID id ∧ atom.effect = some workEffect)

theorem actual_bindings (id : Nat) (atom : Elision.Atom)
    (found : ActualConfigurationHoist.before.atoms[id]? = some atom) : Supported id atom := by
  cases id with
  | zero =>
    simp [ActualConfigurationHoist.before] at found
    subst atom
    simp [Supported]
  | succ id =>
    cases id with
    | zero =>
      simp [ActualConfigurationHoist.before] at found
      subst atom
      simp [Supported,pairEffect]
    | succ id =>
      cases id with
      | zero =>
        simp [ActualConfigurationHoist.before] at found
        subst atom
        simp [Supported,workID,workEffect]
      | succ id =>
        cases id with
        | zero =>
          simp [ActualConfigurationHoist.before] at found
          subst atom
          simp [Supported,workID,workEffect]
        | succ id =>
          cases id with
          | zero =>
            simp [ActualConfigurationHoist.before] at found
            subst atom
            simp [Supported,workID,workEffect]
          | succ id => simp [ActualConfigurationHoist.before] at found

def set (key : Nat) (value : Int) (state : State Int) : State Int :=
  fun index => if index = key then value else state index

def observed (id index : Nat) (state : State Int) : State Int :=
  let digit : Int := if id = 2 then 2 * Int.ofNat index + 1 else if id = 3 then 2 * Int.ofNat index + 2 else 7
  set 101 (10 * state 101 + digit) (set 100 (state 100 + state 0 + state 1) state)

def run (failPrefix failBody : Bool) (id index : Nat) (state : State Int) : PartialHoist.Outcome Int Nat :=
  if id = 0 then if failPrefix then .error (91,state) else .ok (set 102 11 state)
  else if id = 1 then .ok (Elision.assign (fun x => x) pairEffect.writes state)
  else if workID id then
    if state 0 = 3 ∧ state 1 = 5 then
      if failBody && id == 3 && index == 1 then .error (73,observed id index state)
      else .ok (observed id index state)
    else .error (12,state)
  else .error (404,state)

def otherLoop (_descriptor : PartialHoist.Loop) (state : State Int) : PartialHoist.Outcome Int Nat := .error (405,state)

theorem pair_model {atom : Elision.Atom} (effect : atom.effect = some pairEffect)
    (failPrefix failBody : Bool) (index : Nat) :
    Elision.Admitted [0,1] (fun x => x) (fun _ state => run failPrefix failBody 1 index state) atom := by
  simp only [Elision.Admitted,effect]
  constructor
  · intro _ initial final success
    have equal : final = Elision.assign (fun x => x) pairEffect.writes initial := by
      simpa [run] using success.symm
    subst final
    refine ⟨?_,?_,?_⟩
    · intro key value found; simp only [Elision.assign,found]
    · intro key _ absent _; simp only [Elision.assign,absent]
    · intro pair impossible; cases impossible
  · intro _ initial; simp [run]

theorem work_model {atom : Elision.Atom} {id : Nat} (effect : atom.effect = some workEffect)
    (work : workID id) (failPrefix failBody : Bool) (index : Nat) :
    Elision.Admitted [0,1] (fun x => x) (fun _ state => run failPrefix failBody id index state) atom := by
  have nonzero : id ≠ 0 := by rcases work with rfl | rfl | rfl <;> decide
  have notSetter : id ≠ 1 := by rcases work with rfl | rfl | rfl <;> decide
  simp only [Elision.Admitted,effect]
  constructor
  · intro _ initial final success
    have installed : initial 0 = 3 ∧ initial 1 = 5 := by
      by_cases h : initial 0 = 3 ∧ initial 1 = 5
      · exact h
      · simp [run,nonzero,notSetter,work,h] at success
    have equal : final = observed id index initial := by
      by_cases failure : (failBody && id == 3 && index == 1) = true
      · simp [run,nonzero,notSetter,work,installed,failure] at success
      · simpa [run,nonzero,notSetter,work,installed,failure] using success.symm
    subst final
    refine ⟨?_,?_,?_⟩
    · intro key value impossible; cases impossible
    · intro key member _ _
      have alternatives : key = 0 ∨ key = 1 := by simpa using member
      rcases alternatives with rfl | rfl <;> simp [observed,set]
    · intro pair member
      have alternatives : pair = (0,3) ∨ pair = (1,5) := by simpa [workEffect] using member
      rcases alternatives with rfl | rfl
      · exact installed.1
      · exact installed.2
  · intro impossible; simp [Elision.pure,workEffect] at impossible

theorem models (failPrefix failBody : Bool) : PartialHoist.Models ActualConfigurationHoist.fields
    (fun x => x) ActualConfigurationHoist.before.atoms (run failPrefix failBody) := by
  intro index id atom found
  rcases actual_bindings id atom found with unknown | setter | work
  · simp only [Elision.Admitted,unknown.2]
  · rcases setter with ⟨rfl,effect⟩
    exact pair_model effect failPrefix failBody index
  · exact work_model work.2 work.1 failPrefix failBody index

def initial : State Int := fun key => if key = 0 then 19 else if key = 1 then -8 else if key = 100 then 5 else 0

def finalState : State Int := set 101 1234567 (set 100 61 (Elision.assign (fun x => x) pairEffect.writes (set 102 11 initial)))
def failedState : State Int := set 101 1234 (set 100 37 (Elision.assign (fun x => x) pairEffect.writes (set 102 11 initial)))

theorem all_outcomes (failPrefix failBody : Bool) (state : State Int) :
    PartialHoist.program (run failPrefix failBody) otherLoop ActualConfigurationHoist.before state =
      PartialHoist.program (run failPrefix failBody) otherLoop ActualConfigurationHoist.after state :=
  ActualConfigurationHoist.complete_kernel (fun x => x) (run failPrefix failBody) otherLoop
    (models failPrefix failBody) state

theorem source_success : PartialHoist.program (run false false) otherLoop ActualConfigurationHoist.before initial =
    .ok finalState := by
  simp [PartialHoist.program,PartialHoist.execute,PartialHoist.command,PartialHoist.repeatBody,PartialHoist.calls,
    ActualConfigurationHoist.before,run,workID,observed,set,Elision.assign,pairEffect,initial,finalState,
    Except.bind,List.lookup_cons]
  funext key
  by_cases zero : key = 0 <;> by_cases one : key = 1 <;> by_cases a : key = 100 <;>
    by_cases b : key = 101 <;> by_cases c : key = 102 <;>
    simp [set,Elision.assign,List.lookup_cons,initial,zero,one,a,b,c]
  all_goals cases (key == 0) <;> cases (key == 1) <;> rfl

theorem final_success : PartialHoist.program (run false false) otherLoop ActualConfigurationHoist.after initial =
    .ok finalState := by rw [←all_outcomes false false initial]; exact source_success

theorem source_first_body_error : PartialHoist.program (run false true) otherLoop ActualConfigurationHoist.before initial =
    .error (73,failedState) := by
  simp [PartialHoist.program,PartialHoist.execute,PartialHoist.command,PartialHoist.repeatBody,PartialHoist.calls,
    ActualConfigurationHoist.before,run,workID,observed,set,Elision.assign,pairEffect,initial,failedState,
    Except.bind,List.lookup_cons]
  funext key
  by_cases zero : key = 0 <;> by_cases one : key = 1 <;> by_cases a : key = 100 <;>
    by_cases b : key = 101 <;> by_cases c : key = 102 <;>
    simp [set,Elision.assign,List.lookup_cons,initial,zero,one,a,b,c]
  all_goals cases (key == 0) <;> cases (key == 1) <;> rfl

theorem final_first_body_error : PartialHoist.program (run false true) otherLoop ActualConfigurationHoist.after initial =
    .error (73,failedState) := by rw [←all_outcomes false true initial]; exact source_first_body_error

theorem source_prefix_error : PartialHoist.program (run true false) otherLoop ActualConfigurationHoist.before initial =
    .error (91,initial) := by
  simp [PartialHoist.program,PartialHoist.execute,PartialHoist.command,ActualConfigurationHoist.before,run,Except.bind]

theorem final_prefix_error : PartialHoist.program (run true false) otherLoop ActualConfigurationHoist.after initial =
    .error (91,initial) := by rw [←all_outcomes true false initial]; exact source_prefix_error

theorem nonzero_success : finalState 100 = 61 ∧ finalState 101 = 1234567 := by decide
theorem error_observations : failedState 100 = 37 ∧ failedState 101 = 1234 := by decide

end ActualConfigurationHoistWitness
