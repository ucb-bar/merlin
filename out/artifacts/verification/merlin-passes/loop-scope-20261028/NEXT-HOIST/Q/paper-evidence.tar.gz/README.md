# Scoped configuration-hoist paper evidence

Proposed conditional claim: acceptance for the supported complete Kernel boundary
establishes equality of modeled success, or the same first error and complete
terminal state, for every initial state. This moves one invariant total pure
constant setter out of a positive counted loop, under a common indexed partial
retained-call interpretation obeying declared effects and frame laws.

The exact checked theorem is `ActualConfigurationHoist.complete_kernel`, using
`Merlin.GraphState.Configuration.PartialHoist.check_sound`; observation and
surrounding-context roots are checked too. No source-success, body-agreement or
whole-run-equality premise is introduced.

The supported source is the actual `hoist_loop_configuration` implementation at
`e0484f4886ae0780d0325cdfa998842b61bb647c`. Q cut5 freezes all source, original/final
buffers, complete projections, queries, roots and import maps. There is no middle
buffer. Kernel arguments/attributes, call operands/metadata, every static call,
loop controls/completion fields and surrounding observers are bound. Completion
fields must be empty, one leading setter is admitted, and every body write or
clobber must be disjoint from setup fields. Zero/nested/async/multiple-prefix and
same-value-overlap variants are outside this domain.

The retained actual worked example and precise IR-field map are in
[the independent paper packet](../../F/paper-evidence/README.md), with raw before/
after, exact Lean query, checked report/type output and a valid wrong-value
negative. The baseline moves `pair(a=3,b=5)` before a three-iteration loop while
preserving the earlier call, both ordered body calls and later observer. Its
15 root types and 315 transitive std3 theorems were checked. Independent actual-
syntax witnesses check 124 roots/345 std3 theorems: success observer61/trace1234567,
first body error73 with observer37/trace1234, and prefix error91 before setup.

[Terminal evidence join](../delivery-v5/TERMINAL-JOIN.json) links Q's seven exact
source/query/root joins to F's terminal campaign and seal. F passed seven actual
changed pairs, nine unsupported boundaries, fifteen Lean mutation refusals plus
one token-domain refusal, sixteen forged candidates, twelve live-artifact
controls, and a separate fresh-process replay. These are engineering qualification
observations for this frozen cut; all old failed/provisional cuts stay preserved.

Python parser/projection/import delivery, codec and primitive/effect fidelity,
nonaliasing state identities, complete caller/observer representation and human
model approval remain explicit. No hardware/numerical fidelity, full-model
coverage, production enforcement or adjacent-pass composition is established.
Linux receipts are historical; copying them does not qualify another machine.
