# Final canonical hoist cut — native qualification pending

Root reviewed/intook the six new host modules and three new proof modules into
canonical worker sources. This cut binds the actual canonical Python imports,
eight owned installable host/test files, the9-project Lean closure, all7supported
actual before/after pairs and9explicit domain refusals. No candidate artifact
fallback can authorize native execution. Source-cut-v2 remains immutable;
source-cut-v3 is the initial test-relocation snapshot before import-order cleanup.
All7closed query/root bytes match cut2, but relocated host source identities are
new and inherit no native qualification.31canonical SDK tests and Ruff pass.

Actual source is exactly the selected read-only new e0484f488 producer, not4499.
Root's bb35450b... manifest pins2009Python Git blobs; every used source/helper
origin is verified by SHA256,size,Gitblob. Alias helpers are derived from actual
file origins and module-valued globals. Each capture uses ordinary Python -I -B
-X pycache_prefix=NEW/unused-python-cache and checks prefix absence before/after.
Both actual complete Kernel trees must survive export/parse roundtrip. All7actual
producer final outputs were independently reproduced under these final controls
in Q/actual-reproduction-v2. Python/runtime/parser/import delivery remains trusted;
hashing does not itself prove host execution or hardware correctness. No Git/SDK/
Lean/native campaign was launched by Q.

Initial domain: one positive bounded counted top-level Loop, exactly one leading
constant invariant pure setup call, nonempty flat retained body, empty completion
fields in BOTH actual endpoints and Lean templates, no async/unit/staging calls.
Every body write/clobber overlapping setup fields is refused, even identical writes
supported by the broader producer. Unknown/unordered bodies, IV-dependent setup,
multiple prefixes, nested loops and zero-trip hoists are outside this domain.
Arbitrary retained surrounding calls, complete Call operands/metadata, Kernel
name/attrs/buffer descriptors and exact loop metadata/control stay bound.

ActualConfigurationHoist.complete_kernel derives complete modeled success/error/
terminal-state equality from indexed common local call meanings, exact pure TOTAL
setup and successful body frames derived from declared effects. Retained calls can
fail; no body-agreement/source-success/whole-run-equality premise is substituted.
Arbitrary otherLoop meaning is universally quantified, never used by the accepted
explicit-token-empty shapes. W separately compiled/audited the actual baseline
query (100types315std3), constructive success/error/order witness (124types345std3)
and countermodels. That is not qualification of this new gate source cut.

Gate API: canonical configuration_hoist_intake.prepare(source,final,reference=NEW,
facts=ORIGINAL,software=ORIGINAL,target=ORIGINAL,source_manifest=ROOT_MANIFEST).
check(candidate,lean=SELECTED_NORMAL_LEAN,destination=NEW) builds9project modules
plusactualquery in freshprivateobjects, audits all imports/std3 and15root types,
and revalidates source/query/control/objects/mapping/rawprocess evidence. Only
real success can issue same-object nonserializable Completion; copied/saved/JSON/
callback data cannot. deliver validates immediately and supplies exact final.mk;
replay reconstructs and checks in another fresh process. F owns independent fresh
qualification after root review, baseline first/stop first infrastructure failure.

No production registration, numerical/timing/native-ISA/hardware/adjacent-pipeline
claim. Exact ISA/effect/codec and complete state/caller/observer interpretation
remain review premises. Old elision/buffer/loop snapshots and all counterexamples
remain unchanged. Latest user: finish THIS hoist, write handoff, STOP after root
final checkpoint. No next pass or optional expansion is authorized.


Final source-selection correction: proof/auditor and core-host paths are anchored
to the actual installed merlin.verify package origin. MERLIN_REPO_ROOT controls
output storage only, never the trusted semantic source tree. The retained SDK
finding in Q/source-root-finding-v1 showed the old provisional path could follow
a foreign environment-selected source tree. Root approved the intake-only fix;
all7queries/root bundles and allLean/model sources remain unchanged.31SDK tests
include the environment-redirection regression. Earlier provisional cuts and F's
source-only preflight mismatch remain retained; no native failure or retry.
