"""Fresh private Lean objects for the explicit configuration source closure."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
ROOT=Path.cwd();BASE=ROOT/'out/artifacts/verification/merlin-passes/loop-scope-20261028/NEXT-HOIST/W'
record=BASE/sys.argv[1];record.mkdir(exist_ok=False)
(record/'build.py').write_bytes(Path(__file__).read_bytes())
objects=ROOT/'out/build/loop-scope-20261028/configuration-hoist-W'/sys.argv[1];objects.mkdir(parents=True,exist_ok=False)
lean='/home/jeremy/.elan/toolchains/leanprover--lean4---v4.35.0/bin/lean'
source=ROOT/'src/merlin/verify/lean';own=BASE/'sources'
visited=[];seen=set()
def visit(name):
 if name in seen:return
 seen.add(name);p=own/(name.replace('.','/')+'.lean')
 if not p.exists():p=source/(name.replace('.','/')+'.lean')
 for line in p.read_text().splitlines():
  if line.startswith('import '):
   for dependency in line.split()[1:]:
    if dependency.startswith('Merlin.') or (own/(dependency.replace('.','/')+'.lean')).exists():visit(dependency)
 visited.append((name,p))
for name in sys.argv[2:]:visit(name)
(record/'SOURCES.json').write_text(json.dumps([{'module':n,'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for n,p in visited],indent=2)+'\n')
for name,p in visited:
 target=record/'source-snapshot'/(name.replace('.','/')+'.lean');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
env=dict(os.environ,LEAN_PATH=str(objects));env.pop('LEAN_SRC_PATH',None)
for i,(name,p) in enumerate(visited):
 target=objects/(name.replace('.','/')+'.olean');target.parent.mkdir(parents=True,exist_ok=True)
 command=[lean,'-j1','-o',str(target),str(p)]
 start=time.monotonic()
 try:
  result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,timeout=120)
 except subprocess.TimeoutExpired as error:
  for stream in ('stdout','stderr'):
   data=getattr(error,stream) or b''
   (record/f'{i}-{name}.{stream}').write_bytes(data if isinstance(data,bytes) else data.encode())
  (record/f'{i}-{name}.process.json').write_text(json.dumps(dict(command=command,returncode=None,timeout=True,seconds=time.monotonic()-start),indent=2)+'\n');raise
 for stream in ('stdout','stderr'):(record/f'{i}-{name}.{stream}').write_text(getattr(result,stream))
 (record/f'{i}-{name}.process.json').write_text(json.dumps(dict(command=command,returncode=result.returncode,seconds=time.monotonic()-start),indent=2)+'\n')
 if result.returncode:print(result.stdout+result.stderr);raise SystemExit(result.returncode)
 print(name,'compiled',flush=True)
(record/'RESULT.json').write_text(json.dumps(dict(status='compiled',modules=len(visited),objects=str(objects)),indent=2)+'\n')
