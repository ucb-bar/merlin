"""Read-only exact scoped F qualification source/data/log review; no native/SDK/object reads."""
from pathlib import Path
import hashlib,json
ROOT=Path.cwd();B=ROOT/'out/artifacts/verification/merlin-passes/loop-scope-20261028/NEXT-HOIST';W=B/'W';F=B/'F/qualification-v1';Q=B/'Q/source-cut-v5'
def read(p):return json.loads(p.read_text())
def exact(row):
 p=Path(row['path']);assert p.suffix in {'.lean','.py','.json','.mk','.stdout','.stderr','.yaml','.yml','.txt'}
 data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes'];return data
def ref(p):
 data=p.read_bytes();return dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
result=read(F/'RESULT.json');assert result['failures']==[]
positives=read(F/'POSITIVES.json');assert len(positives)==7
review=[]
for case in positives:
 assert case['status']=='checked' and case['exact_consumer']
 r=json.loads(exact(case['report']));expected=Q/'cases'/case['name'];folder=Path(case['report']['path']).parent
 assert r['status']=='checked' and r['producer_revision']=='e0484f4886ae0780d0325cdfa998842b61bb647c'
 assert exact(r['query'])==(expected/'ActualConfigurationHoist.lean').read_bytes()
 assert set(r['statements'])==set(read(expected/'ROOTS.json')) and len(r['statements'])==15
 assert r['audit']['violations']==[] and set(r['audit']['axioms_used']) <= {'propext','Classical.choice','Quot.sound'}
 assert r['audit']['theorems_audited']==315
 for i,row in enumerate(r['buffers']):assert exact(row)==exact(case['originals'][i])
 mappings={Path(row['path']).stem:json.loads(exact(row)) for row in r['mapping_records']}
 assert set(mappings)=={'Projection','Resolution','SourceRequest'} and mappings['Projection']==read(expected/'PROJECTION.json')
 assert mappings['SourceRequest']==r['source_request']
 for row in r['sources']:exact(row)
 count=0
 for row in r['process_evidence']:
  raw=exact(row)
  if row['path'].endswith('.process.json'):assert json.loads(raw)['returncode']==0;count+=1
 assert count==12 and read(folder/'audit.stdout')==r['audit'] and read(folder/'types.stdout')['statements']==r['statements']
 imports=[row for row in r['audit']['imports'] if row['module'].startswith('Merlin.') or row['module']=='ActualConfigurationHoist']
 assert len(imports)==10
 for row in imports:assert Path(row['olean']).resolve()==(folder/'lib'/(row['module'].replace('.','/')+'.olean')).resolve()
 assert r['interpretation_is_conditional'] and not any(r[k] for k in ['independently_qualified','hardware_model_approved','production_enforcement'])
 review.append(dict(case=case['name'],report=case['report'],exact_raw_pair_query_projection_roots=True,sources=len(r['sources']),processes=12,private_project_import_paths=10,types=15,theorems=315,std3=True,exact_consumer=True))
boundaries=read(F/'BOUNDARIES.json');assert len(boundaries)==9 and all(r['status']=='EXPECTED_HOST_DOMAIN_REFUSAL' for r in boundaries)
negatives=read(F/'NEGATIVES.json');assert len(negatives)==16
native=[];host=[]
for case in negatives:
 if case['status']=='HOST_DOMAIN_REFUSAL':
  assert case['name']=='changed_completion_incoming';host.append(case);continue
 assert case['status']=='ACTUAL_EXPECTED_LEAN_OBLIGATION_REFUSAL' and case['gate_status']=='not_established'
 folder=ROOT/'out/build/loop-scope-20261028/qualification/hoist-v1/negatives'/case['name'];p=folder/'ActualConfigurationHoist.lean';source=p.read_bytes()
 assert hashlib.sha256(source).hexdigest()==case['classification']['source_sha256']
 assert read(folder/'query.process.json')['returncode']==1 and read(folder/'query.process.json')['command'][-1]==str(p)
 assert source.decode().splitlines()[14]=='theorem accepted : PartialHoist.check fields before after move = true := by decide'
 expected=str(p)+':15:76: error: Tactic `decide` proved that the proposition\n  PartialHoist.check fields before after move = true\nis false\n'
 assert (folder/'query.stdout').read_text()==expected and not (folder/'query.stderr').read_text()
 for index in range(9):assert read(folder/f'import-{index}.process.json')['returncode']==0
 native.append(dict(case=case['name'],source=ref(p),process=ref(folder/'query.process.json'),exact_false_obligation=True))
assert len(native)==15 and len(host)==1
protocol=read(F/'protocol/PROTOCOL.json');assert all(r['no_native_output'] and r['status']=='unavailable' for r in protocol['cases'])
artifacts=read(F/'artifact-controls/ARTIFACTS.json');assert len(artifacts['cases'])==12 and all(r['refused'] for r in artifacts['cases'])
assert artifacts['constructed_copied_saved_tokens_refused']==5 and artifacts['copied_candidate_refused'] and artifacts['no_mock_positive_proof']
replay=read(F/'fresh-replay/RESULT.json');assert replay['status']=='checked' and replay['incoming_ledger']==0
r=json.loads(exact(replay['report']));folder=Path(replay['report']['path']).parent
assert exact(r['query'])==(W/'sources/ActualConfigurationHoist.lean').read_bytes()
assert r['audit']['violations']==[] and set(r['audit']['axioms_used']) <= {'propext','Classical.choice','Quot.sound'} and len(r['statements'])==15
processes=0
for row in r['process_evidence']:
 raw=exact(row)
 if row['path'].endswith('.process.json'):assert json.loads(raw)['returncode']==0;processes+=1
assert processes==12
output=dict(status='independent_readonly_scoped_qualification_terminal_review_passed',campaign=ref(F/'RESULT.json'),positive_reports=review,boundaries=9,actual_Lean_refusals=native,host_completion_refusal=host,forged_requests=len(protocol['cases']),live_artifact_controls=12,fresh_empty_ledger_replay=True,replay_report=replay['report'],replay_types=15,replay_theorems=r['audit']['theorems_audited'],SDK_or_proof_object_contents_read=False,new_native_launch_by_W=False,hardware_native_human_review=False,finish_then_stop=True)
with (W/'F-TERMINAL-REVIEW-v1.json').open('x') as f:json.dump(output,f,indent=2);f.write('\n')
print(json.dumps(dict(status=output['status'],positives=7,native_refusals=15,host_completion_refusal=1,replay=True)))
