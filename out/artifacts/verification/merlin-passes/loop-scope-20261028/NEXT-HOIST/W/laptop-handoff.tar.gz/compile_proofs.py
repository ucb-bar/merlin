"""Explicit NEW local proof build. Historical receipts grant no live authority.

Requires NEW user authorization after the stop checkpoint. Select a genuine
available Lean4.35 executable explicitly; never downloads or repairs tools.
This compiles proof source only, not the Q/F actual-producer/consumer workflow.
"""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,time

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lean',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True,help='new private directory')
    args=parser.parse_args()
    base=Path(__file__).resolve().parent;source=base/'lean'
    refs=json.loads((base/'SOURCE-MANIFEST.json').read_text())
    for row in refs:
        data=(base/row['relative']).read_bytes()
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
            raise ValueError('source bytes differ from handoff: '+row['relative'])
    lean=args.lean.resolve(strict=True);out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    library=out/'lib';library.mkdir()
    modules=['Merlin.GraphStateConfigurationHoistCountermodels','ActualConfigurationHoist','ActualConfigurationHoistWitness']
    names={r['module']:r for r in refs};seen=set();order=[]
    def visit(name):
        if name in seen:return
        seen.add(name);path=base/names[name]['relative']
        for line in path.read_text().splitlines():
            if line.startswith('import '):
                for child in line.split()[1:]:
                    if child in names:visit(child)
                    elif child.startswith('Merlin.'):raise ValueError('missing source dependency '+child)
        order.append((name,path))
    for name in modules:visit(name)
    env=dict(os.environ,LEAN_PATH=str(library),PATH=str(lean.parent)+os.pathsep+os.environ.get('PATH',''))
    def run(label,command):
        start=time.monotonic();(out/(label+'.intent.json')).write_text(json.dumps(dict(command=list(map(str,command)),cwd=str(source),timeout=120),indent=2)+'\n')
        try:result=subprocess.run(list(map(str,command)),cwd=source,env=env,capture_output=True,text=True,timeout=120)
        except subprocess.TimeoutExpired as error:
            for field in ['stdout','stderr']:
                data=getattr(error,field) or b'';(out/(label+'.'+field)).write_bytes(data if isinstance(data,bytes) else data.encode())
            (out/(label+'.process.json')).write_text(json.dumps(dict(returncode=None,timeout=True),indent=2)+'\n');raise
        for field in ['stdout','stderr']:(out/(label+'.'+field)).write_text(getattr(result,field))
        (out/(label+'.process.json')).write_text(json.dumps(dict(returncode=result.returncode,seconds=time.monotonic()-start),indent=2)+'\n')
        if result.returncode:raise RuntimeError(label+' failed; first raw output retained, no retry')
        return result
    for index,(name,path) in enumerate(order):
        target=library/(name.replace('.','/')+'.olean');target.parent.mkdir(parents=True,exist_ok=True)
        run('compile-'+str(index),[lean,'-j1','-o',target,path])
    auditor=source/'Merlin/GraphStateAudit.lean'
    audit=json.loads(run('audit',[lean,'--run',auditor,*modules]).stdout)
    if audit['violations'] or not set(audit['axioms_used']) <= {'propext','Classical.choice','Quot.sound'}:
        raise RuntimeError('audit did not establish std3/no violations')
    (out/'RESULT.json').write_text(json.dumps(dict(status='new_local_proof_source_build_audited',project_modules=len(order),audit=audit,actual_producer_or_consumer_qualification=False,historical_receipt_reused=False),indent=2)+'\n')
    print(json.dumps(dict(status='new_local_proof_source_build_audited',project_modules=len(order),theorems=audit['theorems_audited'])))

if __name__=='__main__':main()
