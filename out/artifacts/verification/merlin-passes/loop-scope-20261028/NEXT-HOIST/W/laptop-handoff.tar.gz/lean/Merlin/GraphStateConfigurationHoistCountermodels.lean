/- Scoped finite controls and semantic countermodels. These are abstract model
examples, not an attribution to the new actual producer's output. -/
import Merlin.GraphStateConfigurationHoistChecker

namespace Merlin.GraphState.Configuration.PartialHoist.Countermodels
open StateEffects
set_option autoImplicit false

def setter : Elision.Atom := ⟨1,"pure invariant field0=7",some ⟨[],[(0,7)],[],true,true⟩,true⟩
def body : Elision.Atom := ⟨2,"retained read field0",some ⟨[(0,7)],[],[],true,false⟩,false⟩
def atoms : List Elision.Atom := [⟨0,"before",none,false⟩,setter,body,⟨3,"after",none,false⟩]
def move : Move := ⟨[0],1,[2],[3],"i",3,"all original metadata"⟩
def before : Program := ⟨"full kernel frame",atoms,source move⟩
def after : Program := ⟨before.frame,atoms,target move⟩

theorem accepts_scoped_shape : check [0] before after move = true := by decide

def changedBody (effect : Option Elision.Effect) : List Elision.Atom :=
  [⟨0,"before",none,false⟩,setter,{body with effect := effect},⟨3,"after",none,false⟩]

theorem refuses_zero :
    check [0] {before with commands := source {move with extent := 0}}
      {after with commands := target {move with extent := 0}} {move with extent := 0} = false := by decide

theorem refuses_write_overlap :
    check [0] {before with atoms := changedBody (some ⟨[],[(0,8)],[],true,false⟩)}
      {after with atoms := changedBody (some ⟨[],[(0,8)],[],true,false⟩)} move = false := by decide

/-- Initial mode refuses even the same value, although a larger actual producer
may support it. This is an explicit restriction, not a false counterexample. -/
theorem refuses_same_value_overlap :
    check [0] {before with atoms := changedBody (some ⟨[],[(0,7)],[],true,false⟩)}
      {after with atoms := changedBody (some ⟨[],[(0,7)],[],true,false⟩)} move = false := by decide

theorem refuses_clobber :
    check [0] {before with atoms := changedBody (some ⟨[],[],[0],true,false⟩)}
      {after with atoms := changedBody (some ⟨[],[],[0],true,false⟩)} move = false := by decide

theorem refuses_unknown_body :
    check [0] {before with atoms := changedBody none} {after with atoms := changedBody none} move = false := by decide

def tokenLoop (command : Command) : Command :=
  match command with
  | .call id => .call id
  | .loop descriptor => .loop {descriptor with iterArgs := [("carry","incoming")],yields := ["yield"],results := ["result"]}

theorem refuses_completion_tokens :
    check [0] {before with commands := before.commands.map tokenLoop}
      {after with commands := after.commands.map tokenLoop} move = false := by decide

def set (key : Nat) (value : Int) (state : State Int) : State Int := fun index => if index = key then value else state index
def initial : State Int := fun key => if key = 0 then 19 else 0
def setup : State Int → State Int := Elision.assign (fun x => x) [(0,7)]
def field (key : Nat) : Outcome Int Nat → Int
  | .ok state => state key
  | .error (_,state) => state key

/-- With zero iterations, adding setup changes state even if setup is pure. -/
theorem zero_trip_counterexample :
    field 0 (repeatSetup setup (fun _ state => .ok state) 0 0 initial) ≠
      field 0 (repeatBody (fun _ state => .ok state) 0 0 (setup initial)) := by decide

def clobberingBody (_index : Nat) (state : State Int) : Outcome Int Nat :=
  .ok (set 0 8 (set 100 (state 100 + state 0) state))

/-- Final configuration alone agrees, but retained observer history differs. -/
theorem clobber_observer_counterexample :
    field 100 (repeatSetup setup clobberingBody 3 0 initial) = 21 ∧
    field 100 (repeatBody clobberingBody 3 0 (setup initial)) = 23 := by decide

def varyingSetup (index : Nat) (state : State Int) : Outcome Int Nat := .ok (set 0 (Int.ofNat index) state)
theorem index_dependent_counterexample :
    field 0 (repeatBody varyingSetup 3 0 initial) = 2 ∧
    field 0 (repeatBody (fun _ state => .ok state) 3 0 (set 0 0 initial)) = 0 := by decide

def pulsingSetup (state : State Int) : State Int := set 100 (state 100 + 1) (setup state)
theorem hidden_pulse_counterexample :
    field 100 (repeatSetup pulsingSetup (fun _ state => .ok state) 3 0 initial) = 3 ∧
    field 100 (repeatBody (fun _ state => .ok state) 3 0 (pulsingSetup initial)) = 1 := by decide

end Merlin.GraphState.Configuration.PartialHoist.Countermodels
