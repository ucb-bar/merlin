import RawChainEntries

set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphCorpusWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation GraphMemoryAfterWhole GraphMemoryAfterExpansion
open Merlin.GraphLoopsMemorySCF.After

/-- A concrete inhabited ABSTRACT scalar relation, not a native i32 law. -/
def scalar : Epoch.BinaryMeaning Int := fun _ left right result => result = left + right
def literal : LiteralMeaning Int := fun _ value => value = 1

def inputs : List (Runtime Int) := [.scalar "i32" 3, .scalar "i32" 5, Epoch.view 2 [1] "i32"]
def initialHeap : GraphLoopsReuse.Heap Int := fun object index =>
  if object = 2 ∧ index = 0 then some 7 else none
def user : Nat := 99

theorem inputs_typed : ValuesHold kernel.function.parameters inputs := by
  exact .cons (Binding.holds_plain _ _ rfl rfl)
    (.cons (Binding.holds_plain _ _ rfl rfl)
      (.cons (Binding.holds_plain _ _ rfl rfl) .nil))

theorem callers_valid : Epoch.CallersValid plan.objects.length plan.callers
    (assign emptyEnv kernel.function.parameters inputs) := by
  intro caller member
  have same : caller = ⟨⟨2, .view (Epoch.type [1] "i32"), none⟩, "i32"⟩ :=
    List.mem_singleton.mp member
  subst caller
  exact ⟨2, by decide, rfl⟩

theorem inputs_external : ∀ value ∈ inputs, ExternalInput plan.objects.length value := by
  intro value member
  simp only [inputs, List.mem_cons, List.not_mem_nil, or_false] at member
  rcases member with rfl | rfl | rfl
  · trivial
  · trivial
  · change ¬ (2 : Nat) < 2
    decide

theorem domain : EntryDomain independentSource plan kernel GraphMemoryAfterEntries.entry0Row inputs :=
  ⟨inputs_external, inputs_typed, callers_valid⟩
theorem caller_initialized : initialHeap 2 0 = some 7 := rfl
theorem private_initially_uninitialized (object index : Nat) (privateObject : object < 2) :
    initialHeap object index = none := by
  have different : object ≠ 2 := by omega
  simp only [initialHeap, different, false_and, ↓reduceIte]

def initial : GraphLoopsReuse.Memory Int (Epoch.PublicState Int Nat) :=
  Epoch.entryMemory plan kernel.function inputs initialHeap user

theorem initial_seed0 : initial.observed.registers 0 = .scalar "i32" 3 := rfl
theorem initial_seed1 : initial.observed.registers 1 = .scalar "i32" 5 := rfl
theorem initial_caller : initial.observed.registers 2 = Epoch.view 2 [1] "i32" := rfl

end GraphCorpusWitness
