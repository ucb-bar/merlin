import CorpusWitnessBase
set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphCorpusWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation
abbrev State := GraphLoopsReuse.Memory Int (Epoch.PublicState Int Nat)
abbrev PrivateHeap := GraphLoopsReuse.Heap Int
def state0 (_h0 _h1 : PrivateHeap) : State := initial
def spec0 : Epoch.Spec := .constant ⟨3, .index, (some 0)⟩ 0
theorem spec0_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":0,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"0 : index\"]],\"regions\":[],\"results\":[[3,\"index\"]]}" = some spec0 := by decide
def instruction0 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":0,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"0 : index\"]],\"regions\":[],\"results\":[[3,\"index\"]]}"
def state1 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state0 h0 h1).observed 3 (.index 0), (state0 h0 h1).heap⟩
def spec1 : Epoch.Spec := .constant ⟨4, .index, (some 1)⟩ 1
theorem spec1_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[4,\"index\"]]}" = some spec1 := by decide
def instruction1 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[4,\"index\"]]}"
def state2 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state1 h0 h1).observed 4 (.index 1), (state1 h0 h1).heap⟩
def spec2 : Epoch.Spec := .constant ⟨5, .index, (some 1)⟩ 1
theorem spec2_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[5,\"index\"]]}" = some spec2 := by decide
def instruction2 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[5,\"index\"]]}"
def state3 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state2 h0 h1).observed 5 (.index 1), (state2 h0 h1).heap⟩
def spec3 : Epoch.Spec := .constant ⟨6, .index, (some 1)⟩ 1
theorem spec3_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[6,\"index\"]]}" = some spec3 := by decide
def instruction3 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[6,\"index\"]]}"
def state4 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state3 h0 h1).observed 6 (.index 1), (state3 h0 h1).heap⟩
def instruction4 : GraphLoopsReuse.Instruction := .allocate 0 true
def state5 (h0 h1 : PrivateHeap) : State := GraphLoopsReuse.clearMemory plan.objects false 0 true (state4 h0 h1)
def spec5 : Epoch.Spec := .constant ⟨10, .index, (some 1)⟩ 1
theorem spec5_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[8,\"index\"]]}" = some spec5 := by decide
def instruction5 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[8,\"index\"]]}"
def state6 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state5 h0 h1).observed 10 (.index 1), (state5 h0 h1).heap⟩
def spec6 : Epoch.Spec := .constant ⟨11, .index, (some 1)⟩ 1
theorem spec6_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[9,\"index\"]]}" = some spec6 := by decide
def instruction6 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[9,\"index\"]]}"
def state7 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state6 h0 h1).observed 11 (.index 1), (state6 h0 h1).heap⟩
def instruction7 : GraphLoopsReuse.Instruction := .initialize 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"scf.for\",\"operands\":[3,5,4],\"properties\":[],\"regions\":[[{\"arguments\":[[10,\"index\"]],\"operations\":[{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"scf.for\",\"operands\":[3,6,4],\"properties\":[],\"regions\":[[{\"arguments\":[[11,\"index\"]],\"operations\":[{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.store\",\"operands\":[0,7,10,11],\"properties\":[],\"regions\":[],\"results\":[]},{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"scf.yield\",\"operands\":[],\"properties\":[],\"regions\":[],\"results\":[]}]}]],\"results\":[]},{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"scf.yield\",\"operands\":[],\"properties\":[],\"regions\":[],\"results\":[]}]}]],\"results\":[]}"
def state8 (h0 h1 : PrivateHeap) : State := ⟨(state7 h0 h1).observed, h0⟩
def spec8 : Epoch.Spec := .load ⟨0, ⟨7, (.view ⟨[1, 1], 0, [1, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [1, 1], "i32"⟩ ⟨14, (.scalar "i32"), none⟩
theorem spec8_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[7,3,3],\"properties\":[],\"regions\":[],\"results\":[[12,\"i32\"]]}" = some spec8 := by decide
def instruction8 : GraphLoopsReuse.Instruction := .load 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[7,3,3],\"properties\":[],\"regions\":[],\"results\":[[12,\"i32\"]]}"
def state9 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state8 h0 h1).observed 14 (.scalar "i32" 3), (state8 h0 h1).heap⟩
def spec9 : Epoch.Spec := .binary "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operand_arity\":2,\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"result_types\":[\"i32\"]}" ⟨14, (.scalar "i32"), none⟩ ⟨0, (.scalar "i32"), none⟩ ⟨15, (.scalar "i32"), none⟩ "i32"
theorem spec9_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operands\":[12,0],\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"regions\":[],\"results\":[[13,\"i32\"]]}" = some spec9 := by decide
def instruction9 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operands\":[12,0],\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"regions\":[],\"results\":[[13,\"i32\"]]}"
def state10 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state9 h0 h1).observed 15 (.scalar "i32" 6), (state9 h0 h1).heap⟩
def spec10 : Epoch.Spec := .store ⟨0, ⟨7, (.view ⟨[1, 1], 0, [1, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [1, 1], "i32"⟩ ⟨15, (.scalar "i32"), none⟩
theorem spec10_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.store\",\"operands\":[13,7,3,3],\"properties\":[],\"regions\":[],\"results\":[]}" = some spec10 := by decide
def instruction10 : GraphLoopsReuse.Instruction := .store 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.store\",\"operands\":[13,7,3,3],\"properties\":[],\"regions\":[],\"results\":[]}"
def state11 (h0 h1 : PrivateHeap) : State := GraphLoopsReuse.storeMemory plan.objects false 0 0 6 (state10 h0 h1)
def spec11 : Epoch.Spec := .load ⟨0, ⟨7, (.view ⟨[1, 1], 0, [1, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [1, 1], "i32"⟩ ⟨16, (.scalar "i32"), none⟩
theorem spec11_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[7,3,3],\"properties\":[],\"regions\":[],\"results\":[[14,\"i32\"]]}" = some spec11 := by decide
def instruction11 : GraphLoopsReuse.Instruction := .load 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[7,3,3],\"properties\":[],\"regions\":[],\"results\":[[14,\"i32\"]]}"
def state12 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state11 h0 h1).observed 16 (.scalar "i32" 6), (state11 h0 h1).heap⟩
def spec12 : Epoch.Spec := .constant ⟨17, .index, (some 1)⟩ 1
theorem spec12_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[15,\"index\"]]}" = some spec12 := by decide
def instruction12 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[15,\"index\"]]}"
def state13 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state12 h0 h1).observed 17 (.index 1), (state12 h0 h1).heap⟩
def spec13 : Epoch.Spec := .observer "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operand_arity\":2,\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"result_types\":[\"i32\"]}" ⟨16, (.scalar "i32"), none⟩ ⟨2, (.view ⟨[1], 0, [1], "i32", 0⟩), none⟩ ⟨18, (.scalar "i32"), none⟩ "i32"
theorem spec13_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"func.call\",\"operands\":[14,2],\"properties\":[[\"callee\",\"@touch\"]],\"regions\":[],\"results\":[[16,\"i32\"]]}" = some spec13 := by decide
def instruction13 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"func.call\",\"operands\":[14,2],\"properties\":[[\"callee\",\"@touch\"]],\"regions\":[],\"results\":[[16,\"i32\"]]}"
def state14 (h0 h1 : PrivateHeap) : State := ⟨{ Epoch.writeRegister (state13 h0 h1).observed 18 (.scalar "i32" 13) with callerHeap := GraphLoopsReuse.replaceCell (state13 h0 h1).observed.callerHeap 2 0 13 }, (state13 h0 h1).heap⟩
def instruction14 : GraphLoopsReuse.Instruction := .release 0 false
def state15 (h0 h1 : PrivateHeap) : State := GraphLoopsReuse.clearMemory plan.objects false 0 false (state14 h0 h1)
def instruction15 : GraphLoopsReuse.Instruction := .allocate 1 false
def state16 (h0 h1 : PrivateHeap) : State := GraphLoopsReuse.clearMemory plan.objects false 1 false (state15 h0 h1)
def spec16 : Epoch.Spec := .constant ⟨22, .index, (some 1)⟩ 1
theorem spec16_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[18,\"index\"]]}" = some spec16 := by decide
def instruction16 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[18,\"index\"]]}"
def state17 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state16 h0 h1).observed 22 (.index 1), (state16 h0 h1).heap⟩
def spec17 : Epoch.Spec := .constant ⟨23, .index, (some 1)⟩ 1
theorem spec17_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[19,\"index\"]]}" = some spec17 := by decide
def instruction17 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[19,\"index\"]]}"
def state18 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state17 h0 h1).observed 23 (.index 1), (state17 h0 h1).heap⟩
def instruction18 : GraphLoopsReuse.Instruction := .initialize 1 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"scf.for\",\"operands\":[3,5,4],\"properties\":[],\"regions\":[[{\"arguments\":[[20,\"index\"]],\"operations\":[{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"scf.for\",\"operands\":[3,6,4],\"properties\":[],\"regions\":[[{\"arguments\":[[21,\"index\"]],\"operations\":[{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.store\",\"operands\":[1,17,20,21],\"properties\":[],\"regions\":[],\"results\":[]},{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"scf.yield\",\"operands\":[],\"properties\":[],\"regions\":[],\"results\":[]}]}]],\"results\":[]},{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"scf.yield\",\"operands\":[],\"properties\":[],\"regions\":[],\"results\":[]}]}]],\"results\":[]}"
def state19 (h0 h1 : PrivateHeap) : State := ⟨(state18 h0 h1).observed, h1⟩
def spec19 : Epoch.Spec := .load ⟨1, ⟨19, (.view ⟨[1, 1], 0, [1, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [1, 1], "i32"⟩ ⟨26, (.scalar "i32"), none⟩
theorem spec19_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[17,3,3],\"properties\":[],\"regions\":[],\"results\":[[22,\"i32\"]]}" = some spec19 := by decide
def instruction19 : GraphLoopsReuse.Instruction := .load 1 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[17,3,3],\"properties\":[],\"regions\":[],\"results\":[[22,\"i32\"]]}"
def state20 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state19 h0 h1).observed 26 (.scalar "i32" 5), (state19 h0 h1).heap⟩
def spec20 : Epoch.Spec := .binary "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operand_arity\":2,\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"result_types\":[\"i32\"]}" ⟨26, (.scalar "i32"), none⟩ ⟨1, (.scalar "i32"), none⟩ ⟨27, (.scalar "i32"), none⟩ "i32"
theorem spec20_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operands\":[22,1],\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"regions\":[],\"results\":[[23,\"i32\"]]}" = some spec20 := by decide
def instruction20 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operands\":[22,1],\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"regions\":[],\"results\":[[23,\"i32\"]]}"
def state21 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state20 h0 h1).observed 27 (.scalar "i32" 10), (state20 h0 h1).heap⟩
def spec21 : Epoch.Spec := .store ⟨1, ⟨19, (.view ⟨[1, 1], 0, [1, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [1, 1], "i32"⟩ ⟨27, (.scalar "i32"), none⟩
theorem spec21_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.store\",\"operands\":[23,17,3,3],\"properties\":[],\"regions\":[],\"results\":[]}" = some spec21 := by decide
def instruction21 : GraphLoopsReuse.Instruction := .store 1 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.store\",\"operands\":[23,17,3,3],\"properties\":[],\"regions\":[],\"results\":[]}"
def state22 (h0 h1 : PrivateHeap) : State := GraphLoopsReuse.storeMemory plan.objects false 1 0 10 (state21 h0 h1)
def spec22 : Epoch.Spec := .load ⟨1, ⟨19, (.view ⟨[1, 1], 0, [1, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [1, 1], "i32"⟩ ⟨28, (.scalar "i32"), none⟩
theorem spec22_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[17,3,3],\"properties\":[],\"regions\":[],\"results\":[[24,\"i32\"]]}" = some spec22 := by decide
def instruction22 : GraphLoopsReuse.Instruction := .load 1 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[17,3,3],\"properties\":[],\"regions\":[],\"results\":[[24,\"i32\"]]}"
def state23 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state22 h0 h1).observed 28 (.scalar "i32" 10), (state22 h0 h1).heap⟩
def spec23 : Epoch.Spec := .constant ⟨29, .index, (some 1)⟩ 1
theorem spec23_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[25,\"index\"]]}" = some spec23 := by decide
def instruction23 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":1,\"location\":\"loc(unknown)\",\"name\":\"arith.constant\",\"operands\":[],\"properties\":[[\"value\",\"1 : index\"]],\"regions\":[],\"results\":[[25,\"index\"]]}"
def state24 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state23 h0 h1).observed 29 (.index 1), (state23 h0 h1).heap⟩
def spec24 : Epoch.Spec := .observer "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operand_arity\":2,\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"result_types\":[\"i32\"]}" ⟨28, (.scalar "i32"), none⟩ ⟨2, (.view ⟨[1], 0, [1], "i32", 0⟩), none⟩ ⟨30, (.scalar "i32"), none⟩ "i32"
theorem spec24_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"func.call\",\"operands\":[24,2],\"properties\":[[\"callee\",\"@touch\"]],\"regions\":[],\"results\":[[26,\"i32\"]]}" = some spec24 := by decide
def instruction24 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"func.call\",\"operands\":[24,2],\"properties\":[[\"callee\",\"@touch\"]],\"regions\":[],\"results\":[[26,\"i32\"]]}"
def state25 (h0 h1 : PrivateHeap) : State := ⟨{ Epoch.writeRegister (state24 h0 h1).observed 30 (.scalar "i32" 23) with callerHeap := GraphLoopsReuse.replaceCell (state24 h0 h1).observed.callerHeap 2 0 23 }, (state24 h0 h1).heap⟩
def instruction25 : GraphLoopsReuse.Instruction := .release 1 true
def state26 (h0 h1 : PrivateHeap) : State := GraphLoopsReuse.clearMemory plan.objects false 1 true (state25 h0 h1)
def spec26 : Epoch.Spec := .binary "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operand_arity\":2,\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"result_types\":[\"i32\"]}" ⟨18, (.scalar "i32"), none⟩ ⟨30, (.scalar "i32"), none⟩ ⟨31, (.scalar "i32"), none⟩ "i32"
theorem spec26_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operands\":[16,26],\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"regions\":[],\"results\":[[27,\"i32\"]]}" = some spec26 := by decide
def instruction26 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"arith.addi\",\"operands\":[16,26],\"properties\":[[\"overflowFlags\",\"#arith.overflow<none>\"]],\"regions\":[],\"results\":[[27,\"i32\"]]}"
def state27 (h0 h1 : PrivateHeap) : State := ⟨Epoch.writeRegister (state26 h0 h1).observed 31 (.scalar "i32" 36), (state26 h0 h1).heap⟩
def spec27 : Epoch.Spec := .returned [⟨31, (.scalar "i32"), none⟩, ⟨29, .index, (some 1)⟩]
theorem spec27_selected : Epoch.specAt plan.specifications "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"func.return\",\"operands\":[27,25],\"properties\":[],\"regions\":[],\"results\":[]}" = some spec27 := by decide
def instruction27 : GraphLoopsReuse.Instruction := .retained "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"func.return\",\"operands\":[27,25],\"properties\":[],\"regions\":[],\"results\":[]}"
def state28 (h0 h1 : PrivateHeap) : State := ⟨{ (state27 h0 h1).observed with returned := [.scalar "i32" 36, .index 1] }, (state27 h0 h1).heap⟩
def instructions : List GraphLoopsReuse.Instruction := [instruction0,instruction1,instruction2,instruction3,instruction4,instruction5,instruction6,instruction7,instruction8,instruction9,instruction10,instruction11,instruction12,instruction13,instruction14,instruction15,instruction16,instruction17,instruction18,instruction19,instruction20,instruction21,instruction22,instruction23,instruction24,instruction25,instruction26,instruction27]
theorem instructions_exact : instructions = kernel.instructions := by decide
end GraphCorpusWitness
