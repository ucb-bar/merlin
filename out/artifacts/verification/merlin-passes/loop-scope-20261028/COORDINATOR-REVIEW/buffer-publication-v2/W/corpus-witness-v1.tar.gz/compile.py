"""Compile one candidate source; retain exact input and first output for each cut."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();base=Path(__file__).resolve().parent/sys.argv.pop(1)
module,version=sys.argv[1:3];source=base/'sources'/Path(*module.split('.')).with_suffix('.lean')
record=base/'builds'/version;record.mkdir(parents=True,exist_ok=False)
objects=root/'out/build/loop-scope-20261028/corpus-witness-v1'/base.name
deps=(root/'out/build/loop-scope-20261028/buffer-three-epoch-shape') if base.name=='three_disjoint_epochs' else root/'out/build/loop-scope-20261028/qualification/buffer-final-v1/positives'/base.name/'lib'
obj=objects/Path(*module.split('.')).with_suffix('.olean');obj.parent.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,LEAN_PATH=':'.join(map(str,[objects,deps,root/'out/build/loop-scope-20261028/kernel-witness',root/'out/build/loop-scope-20261028/buffer-whole-factored-v1',root/'out/build/loop-scope-20261028/buffer-candidates'])))
lean='/home/jeremy/.elan/toolchains/leanprover--lean4---v4.35.0/bin/lean'
cmd=[lean,'-R',str(base/'sources'),'-o',str(obj),str(source)]
(record/source.name).write_bytes(source.read_bytes());start=time.time()
with (record/'stdout').open('wb') as out,(record/'stderr').open('wb') as err:
 try: rc=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=err,timeout=120).returncode
 except subprocess.TimeoutExpired: rc='TIMEOUT'
result=dict(command=cmd,returncode=rc,seconds=time.time()-start,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
(record/'PROCESS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((record/'stdout').read_text()[:12000])
