import CorpusWitnessSteps
set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphCorpusWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation
open GraphMemoryAfterWhole GraphMemoryAfterExpansion
open Merlin.GraphLoopsMemorySCF.After
theorem source_epoch_run : ∃ h0 h1 : PrivateHeap,
    GraphLoopsMemorySCF.Execution plan.objects plan.configs meaning false false
      kernel.instructions initial (state28 h0 h1) ∧
    (∀ index, index < 6 → h0 0 index = some 3) ∧
    (∀ index, index < 6 → h1 1 index = some 5) := by
  obtain ⟨h0, run0, all0⟩ := initialization0_exists 
  obtain ⟨h1, run1, all1⟩ := initialization1_exists h0
  refine ⟨h0, h1, ?_, all0, all1⟩
  rw [← instructions_exact]
  exact GraphLoopsMemorySCF.Execution.more (step0 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step1 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step2 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step3 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step4 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step5 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step6 h0 h1) (
    GraphLoopsMemorySCF.Execution.more run0 (
    GraphLoopsMemorySCF.Execution.more (step8 h0 h1 (all0 0 (by decide))) (
    GraphLoopsMemorySCF.Execution.more (step9 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step10 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step11 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step12 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step13 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step14 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step15 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step16 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step17 h0 h1) (
    GraphLoopsMemorySCF.Execution.more run1 (
    GraphLoopsMemorySCF.Execution.more (step19 h0 h1 (all1 0 (by decide))) (
    GraphLoopsMemorySCF.Execution.more (step20 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step21 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step22 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step23 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step24 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step25 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step26 h0 h1) (
    GraphLoopsMemorySCF.Execution.more (step27 h0 h1) (
    GraphLoopsMemorySCF.Execution.done _))))))))))))))))))))))))))))
def publicHeap : GraphLoopsReuse.Heap Int := fun object index =>
  if object = 2 ∧ index = 0 then some 23 else none
def observation : Epoch.Observation Int Nat :=
  ⟨[.scalar "i32" 36, .index 2], publicHeap, 99⟩
theorem final_state_observation (h0 h1 : PrivateHeap) :
    Epoch.observePublic plan.objects.length (state28 h0 h1).observed = observation := by
  change Epoch.Observation.mk [.scalar "i32" 36, .index 2]
    (Epoch.visibleHeap 2 (GraphLoopsReuse.replaceCell (GraphLoopsReuse.replaceCell initialHeap 2 0 13) 2 0 23)) 99 = observation
  unfold observation
  congr 1
  funext object index
  by_cases same : object = 2 <;> by_cases cell : index = 0 <;>
    simp [Epoch.visibleHeap, GraphLoopsReuse.replaceCell, GraphLoopsReuse.replaceObject,
      initialHeap, publicHeap, same, cell]
theorem normalized_source_success : Epoch.graphOutcomes plan.objects.length
    (Epoch.graphMeaning plan.opcodes scalar) plan.module kernel.function.name
    inputs initialHeap user observation := by
  obtain ⟨h0, h1, run, _, _⟩ := source_epoch_run
  apply (kernel.observations plan (of_decide_eq_true plan_valid) (of_decide_eq_true kernel_facts)
    scalar inputs inputs_typed callers_valid initialHeap user observation).mpr
  exact ⟨(state28 h0 h1).observed, ⟨state28 h0 h1, run, rfl⟩, final_state_observation h0 h1⟩

theorem original_source_success : Epoch.graphOutcomes plan.objects.length
    (Epoch.graphMeaning plan.opcodes scalar) independentSource kernel.function.name
    inputs initialHeap user observation :=
  (Epoch.shape_outcomes independentSource 64 source_valid plan.module source_normalized
    plan.objects.length (Epoch.graphMeaning plan.opcodes scalar) kernel.function.name
    inputs initialHeap user observation).mpr normalized_source_success

theorem source_success : Epoch.graphOutcomes plan.objects.length
    (finalMeaning 64 indices plan.opcodes scalar) independentSource kernel.function.name
    inputs initialHeap user observation := by
  obtain ⟨returned, world, run, observed⟩ := original_source_success
  exact ⟨returned, world,
    (source_complete_extension 64 indices plan.opcodes scalar independentSource source_index_absent
      kernel.function.name inputs _ returned world).mp run, observed⟩

theorem actual_final_success : Epoch.graphOutcomes plan.objects.length
    (finalMeaning 64 indices plan.opcodes scalar) GraphMemoryAfterMaterialization.actualFinal
    kernel.function.name inputs initialHeap user observation :=
  (GraphMemoryAfterWhole.complete_actual_chain scalar inputs inputs_typed callers_valid
    initialHeap user observation).mp source_success


theorem actual_source_entry_success : Epoch.graphOutcomes plan.objects.length
    (entryMeaning 64 indices plan.opcodes scalar GraphMemoryAfterEntries.literals literal)
    independentSource kernel.function.name inputs initialHeap user observation :=
  (literal_outcomes_extension plan.objects.length (finalMeaning 64 indices plan.opcodes scalar)
    GraphMemoryAfterEntries.literals literal independentSource GraphMemoryAfterEntries.kernelReachable
    GraphMemoryAfterEntries.kernel_support.2.1 GraphMemoryAfterEntries.kernel_support.2.2.2.1
    kernel.function.name GraphMemoryAfterEntries.kernel_support.1 inputs initialHeap user observation).mp source_success

theorem actual_final_entry_success : Epoch.graphOutcomes plan.objects.length
    (entryMeaning 64 indices plan.opcodes scalar GraphMemoryAfterEntries.literals literal)
    GraphMemoryAfterMaterialization.actualFinal kernel.function.name inputs initialHeap user observation :=
  (GraphMemoryAfterEntries.complete_roster scalar literal GraphMemoryAfterEntries.entry0Row
    GraphMemoryAfterEntries.entry0_member inputs domain initialHeap user observation).mp actual_source_entry_success

theorem actual_kernel_nonvacuity :
    EntryDomain independentSource plan kernel GraphMemoryAfterEntries.entry0Row inputs ∧
    Epoch.graphOutcomes plan.objects.length
      (entryMeaning 64 indices plan.opcodes scalar GraphMemoryAfterEntries.literals literal)
      independentSource kernel.function.name inputs initialHeap user observation ∧
    Epoch.graphOutcomes plan.objects.length
      (entryMeaning 64 indices plan.opcodes scalar GraphMemoryAfterEntries.literals literal)
      GraphMemoryAfterMaterialization.actualFinal kernel.function.name inputs initialHeap user observation :=
  ⟨domain, actual_source_entry_success, actual_final_entry_success⟩

theorem ordered_touch0 (h0 h1 : PrivateHeap) : (state14 h0 h1).observed.callerHeap 2 0 = some 13 ∧ (state14 h0 h1).observed.registers 18 = .scalar "i32" 13 := ⟨rfl, rfl⟩
theorem ordered_touch1 (h0 h1 : PrivateHeap) : (state25 h0 h1).observed.callerHeap 2 0 = some 23 ∧ (state25 h0 h1).observed.registers 30 = .scalar "i32" 23 := ⟨rfl, rfl⟩
theorem returned_exact : observation.returned = [.scalar "i32" 36, .index 2] := rfl
theorem caller_exact : observation.heap 2 0 = some 23 := rfl
theorem user_exact : observation.user = 99 := rfl
theorem all_other_cells_unchanged (object index : Nat) (different : object ≠ 2 ∨ index ≠ 0) :
    observation.heap object index = initialHeap object index := by
  rcases different with outside | offset
  · simp only [observation, publicHeap, initialHeap, outside, false_and, ↓reduceIte]
  · simp only [observation, publicHeap, initialHeap, offset, and_false, ↓reduceIte]
end GraphCorpusWitness
