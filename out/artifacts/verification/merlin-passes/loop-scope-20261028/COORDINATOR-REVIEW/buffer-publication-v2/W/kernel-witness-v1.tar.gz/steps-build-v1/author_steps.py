"""Propose per-instruction constructor proofs; no execution premise is accepted."""
from pathlib import Path
import json
from merlin.verify.lean_graph_loops_shape_epoch_plan import access
from merlin.verify.lean_graph_loops_shape_model import binding
from merlin.verify.lean_graph_loops_unroll import _string
BASE=Path(__file__).resolve().parent
plan=json.loads((BASE/'ACTUAL-PLAN.json').read_text())['adapter']['step_binding']
steps=plan['steps']+[dict(instruction=plan['terminal'])]
specs=dict(plan['specifications']);registers={0:3,1:5};private={0:3,1:5};caller=7
text='''import KernelWitnessInitializers
set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphMemoryKernelWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation
'''
for i,step in enumerate(steps):
 inst=step['instruction'];tag=inst['kind']
 if tag=='initialize':continue
 before=f'(state{i} h0 h1)'
 text+=f'''theorem step{i} (h0 h1 : PrivateHeap) (read0 : h0 0 0 = some 3) (read1 : h1 1 0 = some 5) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction{i}
      {before} (state{i+1} h0 h1) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
'''
 if tag in ['allocate','release']:
  text+=f'  exact GraphLoopsReuse.Step.{tag} {inst["object"]} {str(inst["retained"]).lower()} {before}\n'
  continue
 key=_string(inst['key']);s=specs[inst['key']];kind=s['tag'];holds='(Binding.holds_plain _ _ rfl rfl)'
 if kind=='load':
  obj=s['access']['object'];v=private[obj];registers[s['result']['name']]=v
  text+=f'  apply GraphLoopsReuse.Step.load {obj} 0 {key} {before} {v} (state{i+1} h0 h1).observed\n'
  text+=f'  · exact ⟨{access(s["access"])}, {binding(s["result"])}, [0,0], spec{i}_selected, ⟨rfl, rfl, by decide⟩, rfl⟩\n'
  text+='  · decide\n'
  text+=f'  · exact read{obj}\n' if i in [8,19] else '  · rfl\n'
  text+=f'  · exact ⟨{access(s["access"])}, {binding(s["result"])}, spec{i}_selected, {holds}, rfl⟩\n'
 elif kind=='store':
  obj=s['access']['object'];v=registers[s['value']['name']];private[obj]=v
  text+=f'  apply GraphLoopsReuse.Step.store {obj} 0 {key} {before} {v}\n'
  text+=f'  · exact ⟨{access(s["access"])}, {binding(s["value"])}, [0,0], spec{i}_selected, ⟨rfl, rfl, by decide⟩, rfl, rfl⟩\n'
  text+='  · decide\n'
 else:
  text+='  apply GraphLoopsReuse.Step.retained\n'
  text+=f'  refine ⟨spec{i}, spec{i}_selected, ?_⟩\n'
  if kind=='binary':
   a=registers[s['left']['name']];b=registers[s['right']['name']];v=a+b;registers[s['result']['name']]=v
   text+=f'  exact ⟨{a}, {b}, {v}, rfl, rfl, rfl, {holds}, rfl⟩\n'
  elif kind=='observer':
   value=registers[s['input']['name']];old=caller;caller+=value;registers[s['result']['name']]=caller
   text+=f'  exact ⟨2, {value}, {old}, {caller}, by decide, rfl, rfl, rfl, rfl, {holds}, rfl⟩\n'
  elif kind=='constant':registers[s['result']['name']]=s['value'];text+='  rfl\n'
  elif kind=='returned':text+='  rfl\n'
  else:raise ValueError(kind)
text+='end GraphMemoryKernelWitness\n'
(BASE/'KernelWitnessSteps.lean').write_text(text)
