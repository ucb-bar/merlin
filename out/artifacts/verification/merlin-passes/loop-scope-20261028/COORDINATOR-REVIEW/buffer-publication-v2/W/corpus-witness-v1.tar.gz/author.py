"""Propose concrete constructor witnesses from independently decoded actual plans.

Python does not certify execution. Lean checks each instruction, initializer,
complete instruction list, typed domain, and endpoint transfer. No run premise.
Only the retained finite corpus grammar is accepted; this is not a new evaluator.
"""
from pathlib import Path
import json
import sys

from merlin.verify.lean_graph_loops_shape_epoch_plan import spec, access
from merlin.verify.lean_graph_loops_shape_model import binding
from merlin.verify.lean_graph_loops_unroll import _string

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parents[2] / 'W/kernel-witness-v1'
OPTIONS = 'set_option autoImplicit false\nset_option maxRecDepth 16384\nset_option maxHeartbeats 2000000\n'
OPEN = 'namespace GraphCorpusWitness\nopen Merlin Merlin.GraphLoopsShape\nopen GraphShapeEpochObligation\n'
END = 'end GraphCorpusWitness\n'


def author(case):
    base = ROOT / case
    sources = base / 'sources'
    sources.mkdir(exist_ok=True)
    adapter = json.loads((base / 'ACTUAL-PLAN.json').read_text())['adapter']
    plan = adapter['step_binding']
    links = adapter['initializer_links']
    count = len(links)
    assert count in (2, 3)
    heaps = ' '.join(f'h{i}' for i in range(count))
    params = f'({heaps} : PrivateHeap)'
    steps = plan['steps'] + [dict(instruction=plan['terminal'])]
    specs = dict(plan['specifications'])
    configs = [link['config'] for link in links]
    assert all(c['object'] == i for i, c in enumerate(configs))
    seeds = [3 if c['program']['leaf']['value'] == 0 else 5 for c in configs]
    assert all(c['program']['leaf']['value'] in (0, 1) for c in configs)
    volumes = [c['program']['shape'][0] * c['program']['shape'][1] for c in configs]
    initial_positions = {}

    # Use the already checked concrete-domain proof structure; change only the
    # explicit external object number (SSA formal name remains 2).
    text = (OLD / 'KernelWitnessBase.lean').read_text().replace('GraphMemoryKernelWitness', 'GraphCorpusWitness')
    text = text.replace('Epoch.view 2 [1]', f'Epoch.view {count} [1]')
    text = text.replace('object = 2', f'object = {count}').replace('object < 2', f'object < {count}')
    text = text.replace('object ≠ 2', f'object ≠ {count}').replace('initialHeap 2 0', f'initialHeap {count} 0')
    text = text.replace('exact ⟨2, by decide, rfl⟩', f'exact ⟨{count}, by decide, rfl⟩')
    text = text.replace('¬ (2 : Nat) < 2', f'¬ ({count} : Nat) < {count}')
    (sources / 'CorpusWitnessBase.lean').write_text(text)

    states = 'import CorpusWitnessBase\n' + OPTIONS + OPEN
    states += 'abbrev State := GraphLoopsReuse.Memory Int (Epoch.PublicState Int Nat)\nabbrev PrivateHeap := GraphLoopsReuse.Heap Int\n'
    states += f'def state0 ({" ".join("_h" + str(i) for i in range(count))} : PrivateHeap) : State := initial\n'
    proofs = 'import CorpusWitnessInitializers\n' + OPTIONS + OPEN
    registers = {0: 3, 1: 5}
    private = {}
    caller = 7
    touches = []
    records = []
    chain_proofs = []
    for i, step in enumerate(steps):
        instruction = step['instruction']
        tag = instruction['kind']
        before = f'(state{i} {heaps})'
        after = f'(state{i + 1} {heaps})'
        read = None
        if tag in ('allocate', 'release'):
            obj = instruction['object']
            retained = str(instruction['retained']).lower()
            term = f'.{tag} {obj} {retained}'
            value = f'GraphLoopsReuse.clearMemory plan.objects false {obj} {retained} {before}'
            proof = f'  exact GraphLoopsReuse.Step.{tag} {obj} {retained} {before}\n'
        else:
            key = _string(instruction['key'])
            term = f'.{tag} ' + ('' if tag == 'retained' else str(instruction['object']) + ' ') + key
            if tag == 'initialize':
                obj = instruction['object']
                private[obj] = seeds[obj]
                initial_positions[obj] = i
                value = f'⟨{before}.observed, h{obj}⟩'
                chain_proofs.append(f'run{obj}')
            else:
                chosen = specs[instruction['key']]
                kind = chosen['tag']
                states += f'def spec{i} : Epoch.Spec := {spec(chosen)}\n'
                states += f'theorem spec{i}_selected : Epoch.specAt plan.specifications {key} = some spec{i} := by decide\n'
                holds = '(Binding.holds_plain _ _ rfl rfl)'
                if kind == 'load':
                    obj = chosen['access']['object']
                    v = private[obj]
                    n = chosen['result']['name']
                    registers[n] = v
                    runtime = f'.scalar "i32" {v}'
                    value = f'⟨Epoch.writeRegister {before}.observed {n} ({runtime}), {before}.heap⟩'
                    read = obj if i == initial_positions[obj] + 1 else None
                    proof = f'  apply GraphLoopsReuse.Step.load {obj} 0 {key} {before} {v} {after}.observed\n'
                    proof += f'  · exact ⟨{access(chosen["access"])}, {binding(chosen["result"])}, [0,0], spec{i}_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl⟩\n  · decide\n'
                    proof += f'  · exact read{obj}\n' if read is not None else '  · rfl\n'
                    proof += f'  · exact ⟨{access(chosen["access"])}, {binding(chosen["result"])}, spec{i}_selected, {holds}, rfl⟩\n'
                elif kind == 'store':
                    obj = chosen['access']['object']
                    v = registers[chosen['value']['name']]
                    private[obj] = v
                    value = f'GraphLoopsReuse.storeMemory plan.objects false {obj} 0 {v} {before}'
                    proof = f'  apply GraphLoopsReuse.Step.store {obj} 0 {key} {before} {v}\n'
                    proof += f'  · exact ⟨{access(chosen["access"])}, {binding(chosen["value"])}, [0,0], spec{i}_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl, rfl⟩\n  · decide\n'
                else:
                    proof = f'  apply GraphLoopsReuse.Step.retained\n  refine ⟨spec{i}, spec{i}_selected, ?_⟩\n'
                    if kind == 'binary':
                        a, b = (registers[chosen[k]['name']] for k in ('left', 'right'))
                        v = a + b
                        proof += f'  exact ⟨{a}, {b}, {v}, rfl, rfl, rfl, {holds}, rfl⟩\n'
                    elif kind == 'observer':
                        a, old = registers[chosen['input']['name']], caller
                        caller += a
                        v = caller
                        proof += f'  exact ⟨{count}, {a}, {old}, {v}, by decide, rfl, rfl, rfl, rfl, {holds}, rfl⟩\n'
                        touches.append(dict(state=i + 1, register=chosen['result']['name'], value=v))
                    elif kind == 'constant':
                        v = chosen['value']
                        proof += '  rfl\n'
                    elif kind == 'returned':
                        returned = [registers[x['name']] for x in chosen['values']]
                        assert len(returned) == 2
                        proof += '  rfl\n'
                    else:
                        raise ValueError(kind)
                    if kind == 'returned':
                        value = f'⟨{{ {before}.observed with returned := [.scalar "i32" {returned[0]}, .index {returned[1]}] }}, {before}.heap⟩'
                    else:
                        n = chosen['result']['name']
                        registers[n] = v
                        runtime = f'.index {v}' if kind == 'constant' else f'.scalar "i32" {v}'
                        public = f'Epoch.writeRegister {before}.observed {n} ({runtime})'
                        if kind == 'observer':
                            public = f'{{ {public} with callerHeap := GraphLoopsReuse.replaceCell {before}.observed.callerHeap {count} 0 {v} }}'
                        value = f'⟨{public}, {before}.heap⟩'
        states += f'def instruction{i} : GraphLoopsReuse.Instruction := {term}\n'
        states += f'def state{i + 1} {params} : State := {value}\n'
        if tag != 'initialize':
            premise = f' (read{read} : h{read} {read} 0 = some {seeds[read]})' if read is not None else ''
            proofs += f'theorem step{i} {params}{premise} :\n    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction{i}\n      {before} {after} := by\n  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)\n' + proof
            chain_proofs.append(f'(step{i} {heaps}' + (f' (all{read} 0 (by decide))' if read is not None else '') + ')')
        records.append(dict(index=i, instruction=instruction, registers=dict(registers), caller=caller))
    states += 'def instructions : List GraphLoopsReuse.Instruction := [' + ','.join(f'instruction{i}' for i in range(len(steps))) + ']\n'
    states += 'theorem instructions_exact : instructions = kernel.instructions := by decide\n' + END
    (sources / 'CorpusWitnessStates.lean').write_text(states)
    (sources / 'CorpusWitnessSteps.lean').write_text(proofs + END)

    init = 'import CorpusWitnessStates\nimport Merlin.GraphLoopsMemorySCFWitness\n' + OPTIONS + OPEN
    init += 'abbrev OldMeaning := GraphLoopsMemorySCF.Interpretation Int (Epoch.PublicState Int Nat)\ndef meaning : OldMeaning := plan.oldMeaning scalar\n'
    for j, config in enumerate(configs):
        i = initial_positions[j]
        rows, cols = config['program']['shape']
        outer, inner = config['program']['ivs']
        seed = config['program']['leaf']['value']
        assert config['program']['outerPrefix'] == [] and config['program']['leaf']['ops'] == []
        previous = ' '.join(f'h{k}' for k in range(j))
        prevparams = f'({previous} : PrivateHeap)' if previous else ''
        pre = ' '.join([f'h{k}' if k < j else 'initialHeap' for k in range(count)])
        post = ' '.join([f'h{k}' if k <= j else 'initialHeap' for k in range(count)])
        init += f'''theorem initialization{j}_exists {prevparams} : ∃ h{j} : PrivateHeap,
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction{i}
      (state{i} {pre}) (state{i + 1} {post}) ∧
    (∀ index, index < {volumes[j]} → h{j} {j} index = some {seeds[j]}) := by
  obtain ⟨heap, run, values⟩ := GraphLoopsMemorySCF.Witness.uniform_heap meaning.pure
    {rows} {cols} {outer} {inner} {seed} {config['tile']} {j} (by decide) (by decide) (by decide) (by decide) (by decide)
    (meaning.captures (state{i} {pre}).observed) {seeds[j]} (by rfl)
    (state{i} {pre}).heap
  refine ⟨heap, ?_, values⟩
  exact GraphLoopsMemorySCF.Step.initialized (config := link{j}.config) (by decide)
    (state{i} {pre}) run
'''
    (sources / 'CorpusWitnessInitializers.lean').write_text(init + END)

    total = len(steps)
    all_values = [f'(∀ index, index < {volumes[j]} → h{j} {j} index = some {seeds[j]})' for j in range(count)]
    run_type = f'GraphLoopsMemorySCF.Execution plan.objects plan.configs meaning false false\n      kernel.instructions initial (state{total} {heaps})'
    execution = 'import CorpusWitnessSteps\n' + OPTIONS + OPEN + 'open GraphMemoryAfterWhole GraphMemoryAfterExpansion\nopen Merlin.GraphLoopsMemorySCF.After\n'
    execution += f'theorem source_epoch_run : ∃ {heaps} : PrivateHeap,\n    {run_type} ∧\n    ' + ' ∧\n    '.join(all_values) + ' := by\n'
    for j in range(count):
        execution += f'  obtain ⟨h{j}, run{j}, all{j}⟩ := initialization{j}_exists ' + ' '.join(f'h{k}' for k in range(j)) + '\n'
    execution += f'  refine ⟨{", ".join(f"h{k}" for k in range(count))}, ?_, {", ".join(f"all{k}" for k in range(count))}⟩\n  rw [← instructions_exact]\n  exact '
    execution += ''.join(f'GraphLoopsMemorySCF.Execution.more {p} (\n    ' for p in chain_proofs)
    execution += 'GraphLoopsMemorySCF.Execution.done _' + ')' * len(chain_proofs) + '\n'
    execution += f'def publicHeap : GraphLoopsReuse.Heap Int := fun object index =>\n  if object = {count} ∧ index = 0 then some {caller} else none\n'
    execution += f'def observation : Epoch.Observation Int Nat :=\n  ⟨[.scalar "i32" {returned[0]}, .index {returned[1]}], publicHeap, 99⟩\n'
    heapterm = 'initialHeap'
    for touch in touches:
        heapterm = f'(GraphLoopsReuse.replaceCell {heapterm} {count} 0 {touch["value"]})'
    execution += f'''theorem final_state_observation {params} :
    Epoch.observePublic plan.objects.length (state{total} {heaps}).observed = observation := by
  change Epoch.Observation.mk [.scalar "i32" {returned[0]}, .index {returned[1]}]
    (Epoch.visibleHeap {count} {heapterm}) 99 = observation
  unfold observation
  congr 1
  funext object index
  by_cases same : object = {count} <;> by_cases cell : index = 0 <;>
    simp [Epoch.visibleHeap, GraphLoopsReuse.replaceCell, GraphLoopsReuse.replaceObject,
      initialHeap, publicHeap, same, cell]
'''
    # Exact existing semantic bridges, instantiated against this case's actual
    # imported full query. No assumed run or cross-optimization world equality.
    old = (OLD / 'KernelWitnessExecution.lean').read_text()
    bridge = old[old.index('theorem normalized_source_success'):old.index('theorem ordered_observer_witness')]
    bridge = bridge.replace('⟨h0, h1, run, _, _⟩', '⟨' + ', '.join([*(f'h{k}' for k in range(count)), 'run', *('_' for _ in range(count))]) + '⟩')
    bridge = bridge.replace('state28 h0 h1', f'state{total} {heaps}').replace('final_state_observation h0 h1', f'final_state_observation {heaps}')
    execution += bridge
    for j, touch in enumerate(touches):
        execution += f'theorem ordered_touch{j} {params} : (state{touch["state"]} {heaps}).observed.callerHeap {count} 0 = some {touch["value"]} ∧ (state{touch["state"]} {heaps}).observed.registers {touch["register"]} = .scalar "i32" {touch["value"]} := ⟨rfl, rfl⟩\n'
    execution += f'theorem returned_exact : observation.returned = [.scalar "i32" {returned[0]}, .index {returned[1]}] := rfl\n'
    execution += f'theorem caller_exact : observation.heap {count} 0 = some {caller} := rfl\n'
    execution += 'theorem user_exact : observation.user = 99 := rfl\n'
    execution += f'''theorem all_other_cells_unchanged (object index : Nat) (different : object ≠ {count} ∨ index ≠ 0) :
    observation.heap object index = initialHeap object index := by
  rcases different with outside | offset
  · simp only [observation, publicHeap, initialHeap, outside, false_and, ↓reduceIte]
  · simp only [observation, publicHeap, initialHeap, offset, and_false, ↓reduceIte]
'''
    (sources / 'CorpusWitnessExecution.lean').write_text(execution + END)
    observations = 'import CorpusWitnessExecution\n' + OPTIONS + OPEN
    ordered = [f'(state{t["state"]} {heaps}).observed.callerHeap {count} 0 = some {t["value"]}' for t in touches]
    ordered += [f'(state{total} {heaps}).observed.returned = [.scalar "i32" {returned[0]}, .index {returned[1]}]']
    observations += f'theorem ordered_execution_witness : ∃ {heaps} : PrivateHeap,\n    {run_type} ∧\n    ' + ' ∧\n    '.join(ordered + all_values) + ' := by\n'
    observations += '  obtain ⟨' + ', '.join([*(f'h{k}' for k in range(count)), 'run', *(f'all{k}' for k in range(count))]) + '⟩ := source_epoch_run\n'
    observations += '  exact ⟨' + ', '.join([*(f'h{k}' for k in range(count)), 'run', *('rfl' for _ in ordered), *(f'all{k}' for k in range(count))]) + '⟩\n'
    observations += f'''theorem private_objects_hidden (object index : Nat) (inside : object < {count}) :
    observation.heap object index = none := by
  have different : object ≠ {count} := by omega
  simp only [observation, publicHeap, different, false_and, ↓reduceIte]
theorem caller_changed : initialHeap {count} 0 = some 7 ∧ observation.heap {count} 0 = some {caller} := ⟨rfl, rfl⟩
'''
    (sources / 'CorpusWitnessObservations.lean').write_text(observations + END)
    (base / 'PROPOSED-STATES.json').write_text(json.dumps(dict(trusted_execution=False, case=case, objects=count, initialized_volumes=volumes, returned=returned, caller=caller, touches=touches, states=records), indent=2) + '\n')


if __name__ == '__main__':
    for case in sys.argv[1:]:
        author(case)
