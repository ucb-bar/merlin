"""Bind unchanged copied source bytes to this local source tree before a fresh run."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
rows=json.loads((root/'SOURCE-RELATIVE.json').read_text())
for row in rows:
 p=(root/row['relative']).resolve()
 assert p.is_relative_to(root) and p.suffix in ['.py','.lean']
 data=p.read_bytes()
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
 row['path']=str(p)
(root/'SOURCE-MANIFEST.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Bound',len(rows),'unchanged source files; no proof or qualification performed')
