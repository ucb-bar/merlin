from pathlib import Path
import json,subprocess,sys
b=Path(__file__).resolve().parent
for case in ['alignment32_tile3','rows1_columns1_tile3','rows3_columns2_tile2_short']:
 for suffix in ['States','Initializers','Steps','Execution']:
  version=suffix.lower()+'-v1'
  subprocess.run([sys.executable,str(b/'compile.py'),case,'CorpusWitness'+suffix,version],check=True)
  result=json.loads((b/case/'builds'/version/'PROCESS.json').read_text())
  if result['returncode'] != 0:
   print('STOPPED',case,suffix,flush=True);sys.exit(1)
