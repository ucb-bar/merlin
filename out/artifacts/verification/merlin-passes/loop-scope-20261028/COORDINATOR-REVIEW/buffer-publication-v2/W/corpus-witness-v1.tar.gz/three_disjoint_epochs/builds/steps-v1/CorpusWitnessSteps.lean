import CorpusWitnessInitializers
set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphCorpusWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation
theorem step0 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction0
      (state0 h0 h1 h2) (state1 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec0, spec0_selected, ?_⟩
  rfl
theorem step1 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction1
      (state1 h0 h1 h2) (state2 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec1, spec1_selected, ?_⟩
  rfl
theorem step2 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction2
      (state2 h0 h1 h2) (state3 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec2, spec2_selected, ?_⟩
  rfl
theorem step3 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction3
      (state3 h0 h1 h2) (state4 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec3, spec3_selected, ?_⟩
  rfl
theorem step4 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction4
      (state4 h0 h1 h2) (state5 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  exact GraphLoopsReuse.Step.allocate 0 true (state4 h0 h1 h2)
theorem step5 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction5
      (state5 h0 h1 h2) (state6 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec5, spec5_selected, ?_⟩
  rfl
theorem step6 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction6
      (state6 h0 h1 h2) (state7 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec6, spec6_selected, ?_⟩
  rfl
theorem step8 (h0 h1 h2 : PrivateHeap) (read0 : h0 0 0 = some 3) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction8
      (state8 h0 h1 h2) (state9 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.load 0 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[7,3,3],\"properties\":[],\"regions\":[],\"results\":[[12,\"i32\"]]}" (state8 h0 h1 h2) 3 (state9 h0 h1 h2).observed
  · exact ⟨⟨0, ⟨7, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨14, (.scalar "i32"), none⟩, [0,0], spec8_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl⟩
  · decide
  · exact read0
  · exact ⟨⟨0, ⟨7, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨14, (.scalar "i32"), none⟩, spec8_selected, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step9 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction9
      (state9 h0 h1 h2) (state10 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec9, spec9_selected, ?_⟩
  exact ⟨3, 3, 6, rfl, rfl, rfl, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step10 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction10
      (state10 h0 h1 h2) (state11 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.store 0 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.store\",\"operands\":[13,7,3,3],\"properties\":[],\"regions\":[],\"results\":[]}" (state10 h0 h1 h2) 6
  · exact ⟨⟨0, ⟨7, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨15, (.scalar "i32"), none⟩, [0,0], spec10_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl, rfl⟩
  · decide
theorem step11 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction11
      (state11 h0 h1 h2) (state12 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.load 0 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[7,3,3],\"properties\":[],\"regions\":[],\"results\":[[14,\"i32\"]]}" (state11 h0 h1 h2) 6 (state12 h0 h1 h2).observed
  · exact ⟨⟨0, ⟨7, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨16, (.scalar "i32"), none⟩, [0,0], spec11_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl⟩
  · decide
  · rfl
  · exact ⟨⟨0, ⟨7, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨16, (.scalar "i32"), none⟩, spec11_selected, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step12 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction12
      (state12 h0 h1 h2) (state13 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec12, spec12_selected, ?_⟩
  rfl
theorem step13 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction13
      (state13 h0 h1 h2) (state14 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec13, spec13_selected, ?_⟩
  exact ⟨3, 6, 7, 13, by decide, rfl, rfl, rfl, rfl, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step14 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction14
      (state14 h0 h1 h2) (state15 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  exact GraphLoopsReuse.Step.release 0 false (state14 h0 h1 h2)
theorem step15 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction15
      (state15 h0 h1 h2) (state16 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  exact GraphLoopsReuse.Step.allocate 1 false (state15 h0 h1 h2)
theorem step16 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction16
      (state16 h0 h1 h2) (state17 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec16, spec16_selected, ?_⟩
  rfl
theorem step17 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction17
      (state17 h0 h1 h2) (state18 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec17, spec17_selected, ?_⟩
  rfl
theorem step19 (h0 h1 h2 : PrivateHeap) (read1 : h1 1 0 = some 5) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction19
      (state19 h0 h1 h2) (state20 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.load 1 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[17,3,3],\"properties\":[],\"regions\":[],\"results\":[[22,\"i32\"]]}" (state19 h0 h1 h2) 5 (state20 h0 h1 h2).observed
  · exact ⟨⟨1, ⟨19, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨26, (.scalar "i32"), none⟩, [0,0], spec19_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl⟩
  · decide
  · exact read1
  · exact ⟨⟨1, ⟨19, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨26, (.scalar "i32"), none⟩, spec19_selected, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step20 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction20
      (state20 h0 h1 h2) (state21 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec20, spec20_selected, ?_⟩
  exact ⟨5, 5, 10, rfl, rfl, rfl, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step21 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction21
      (state21 h0 h1 h2) (state22 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.store 1 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.store\",\"operands\":[23,17,3,3],\"properties\":[],\"regions\":[],\"results\":[]}" (state21 h0 h1 h2) 10
  · exact ⟨⟨1, ⟨19, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨27, (.scalar "i32"), none⟩, [0,0], spec21_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl, rfl⟩
  · decide
theorem step22 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction22
      (state22 h0 h1 h2) (state23 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.load 1 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[17,3,3],\"properties\":[],\"regions\":[],\"results\":[[24,\"i32\"]]}" (state22 h0 h1 h2) 10 (state23 h0 h1 h2).observed
  · exact ⟨⟨1, ⟨19, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨28, (.scalar "i32"), none⟩, [0,0], spec22_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl⟩
  · decide
  · rfl
  · exact ⟨⟨1, ⟨19, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨28, (.scalar "i32"), none⟩, spec22_selected, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step23 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction23
      (state23 h0 h1 h2) (state24 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec23, spec23_selected, ?_⟩
  rfl
theorem step24 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction24
      (state24 h0 h1 h2) (state25 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec24, spec24_selected, ?_⟩
  exact ⟨3, 10, 13, 23, by decide, rfl, rfl, rfl, rfl, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step25 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction25
      (state25 h0 h1 h2) (state26 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  exact GraphLoopsReuse.Step.release 1 false (state25 h0 h1 h2)
theorem step26 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction26
      (state26 h0 h1 h2) (state27 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  exact GraphLoopsReuse.Step.allocate 2 false (state26 h0 h1 h2)
theorem step27 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction27
      (state27 h0 h1 h2) (state28 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec27, spec27_selected, ?_⟩
  rfl
theorem step28 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction28
      (state28 h0 h1 h2) (state29 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec28, spec28_selected, ?_⟩
  rfl
theorem step30 (h0 h1 h2 : PrivateHeap) (read2 : h2 2 0 = some 3) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction30
      (state30 h0 h1 h2) (state31 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.load 2 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[27,3,3],\"properties\":[],\"regions\":[],\"results\":[[32,\"i32\"]]}" (state30 h0 h1 h2) 3 (state31 h0 h1 h2).observed
  · exact ⟨⟨2, ⟨31, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨38, (.scalar "i32"), none⟩, [0,0], spec30_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl⟩
  · decide
  · exact read2
  · exact ⟨⟨2, ⟨31, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨38, (.scalar "i32"), none⟩, spec30_selected, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step31 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction31
      (state31 h0 h1 h2) (state32 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec31, spec31_selected, ?_⟩
  exact ⟨3, 3, 6, rfl, rfl, rfl, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step32 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction32
      (state32 h0 h1 h2) (state33 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.store 2 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.store\",\"operands\":[33,27,3,3],\"properties\":[],\"regions\":[],\"results\":[]}" (state32 h0 h1 h2) 6
  · exact ⟨⟨2, ⟨31, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨39, (.scalar "i32"), none⟩, [0,0], spec32_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl, rfl⟩
  · decide
theorem step33 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction33
      (state33 h0 h1 h2) (state34 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.load 2 0 "{\"attributes\":[],\"index_constant\":null,\"location\":\"loc(unknown)\",\"name\":\"memref.load\",\"operands\":[27,3,3],\"properties\":[],\"regions\":[],\"results\":[[34,\"i32\"]]}" (state33 h0 h1 h2) 6 (state34 h0 h1 h2).observed
  · exact ⟨⟨2, ⟨31, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨40, (.scalar "i32"), none⟩, [0,0], spec33_selected, ⟨rfl, rfl, ⟨by decide, by decide, trivial⟩⟩, rfl⟩
  · decide
  · rfl
  · exact ⟨⟨2, ⟨31, (.view ⟨[2, 3], 0, [3, 1], "i32", 0⟩), none⟩, [⟨3, .index, (some 0)⟩, ⟨3, .index, (some 0)⟩], [2, 3], "i32"⟩, ⟨40, (.scalar "i32"), none⟩, spec33_selected, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step34 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction34
      (state34 h0 h1 h2) (state35 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec34, spec34_selected, ?_⟩
  rfl
theorem step35 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction35
      (state35 h0 h1 h2) (state36 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec35, spec35_selected, ?_⟩
  exact ⟨3, 6, 23, 29, by decide, rfl, rfl, rfl, rfl, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step36 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction36
      (state36 h0 h1 h2) (state37 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  exact GraphLoopsReuse.Step.release 2 true (state36 h0 h1 h2)
theorem step37 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction37
      (state37 h0 h1 h2) (state38 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec37, spec37_selected, ?_⟩
  exact ⟨13, 23, 36, rfl, rfl, rfl, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step38 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction38
      (state38 h0 h1 h2) (state39 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec38, spec38_selected, ?_⟩
  exact ⟨36, 29, 65, rfl, rfl, rfl, (Binding.holds_plain _ _ rfl rfl), rfl⟩
theorem step39 (h0 h1 h2 : PrivateHeap) :
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction39
      (state39 h0 h1 h2) (state40 h0 h1 h2) := by
  apply GraphLoopsMemorySCF.Step.ordinary (by trivial)
  apply GraphLoopsReuse.Step.retained
  refine ⟨spec39, spec39_selected, ?_⟩
  rfl
end GraphCorpusWitness
