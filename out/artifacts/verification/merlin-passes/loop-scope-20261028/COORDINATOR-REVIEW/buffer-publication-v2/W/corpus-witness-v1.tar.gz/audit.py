from pathlib import Path
import os,subprocess,time,json,sys
r=Path.cwd();b=Path(__file__).resolve().parent/sys.argv.pop(1);label=sys.argv[1];rootsfile=Path(sys.argv[2]);modules=sys.argv[3:];dest=b/label;dest.mkdir(exist_ok=False)
lean='/home/jeremy/.elan/toolchains/leanprover--lean4---v4.35.0/bin/lean';env=dict(os.environ,PATH=str(Path(lean).parent)+':'+os.environ['PATH'],LEAN_PATH=':'.join(str(r/p) for p in ['out/build/loop-scope-20261028/corpus-witness-v1/'+b.name, ('out/build/loop-scope-20261028/buffer-three-epoch-shape' if b.name=='three_disjoint_epochs' else 'out/build/loop-scope-20261028/qualification/buffer-final-v1/positives/'+b.name+'/lib'),'out/build/loop-scope-20261028/kernel-witness','out/build/loop-scope-20261028/buffer-whole-factored-v1','out/build/loop-scope-20261028/buffer-candidates']))
for name,flags in [('audit',[]),('types',['--statements',','.join(json.loads(rootsfile.read_text()))])]:
 cmd=[lean,'--run','src/merlin/verify/lean/Merlin/GraphStateAudit.lean',*flags,*modules];start=time.time()
 with (dest/(name+'.stdout')).open('wb') as out,(dest/(name+'.stderr')).open('wb') as err:
  try:rc=subprocess.run(cmd,env=env,cwd=r,stdout=out,stderr=err,timeout=120).returncode
  except subprocess.TimeoutExpired:rc='TIMEOUT'
 result=dict(command=cmd,returncode=rc,seconds=time.time()-start);(dest/(name+'.process.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((dest/(name+'.stdout')).read_text()[:600] if name=='audit' else '')
 if rc!=0:break
