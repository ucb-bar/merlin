from pathlib import Path
import json,subprocess,os,time,hashlib,sys
r=Path.cwd();b=Path(__file__).resolve().parent;module=sys.argv[1];version=sys.argv[2];source=b/(module+'.lean');dest=b/version;dest.mkdir(exist_ok=False);objects=r/'out/build/loop-scope-20261028/kernel-witness';objects.mkdir(exist_ok=True);lean='/home/jeremy/.elan/toolchains/leanprover--lean4---v4.35.0/bin/lean';env=dict(os.environ,LEAN_PATH=':'.join(str(r/p) for p in ['out/build/loop-scope-20261028/kernel-witness','out/build/loop-scope-20261028/buffer-whole-factored-v1','out/build/loop-scope-20261028/buffer-candidates']));cmd=[lean,'-R',str(r),'-o',str(objects/(module+'.olean')),str(source)];start=time.time();(dest/source.name).write_bytes(source.read_bytes())
with (dest/'stdout').open('wb') as out,(dest/'stderr').open('wb') as err:
 try:rc=subprocess.run(cmd,env=env,cwd=r,stdout=out,stderr=err,timeout=120).returncode
 except subprocess.TimeoutExpired:rc='TIMEOUT'
result=dict(cmd=cmd,returncode=rc,seconds=time.time()-start,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest());(dest/'PROCESS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((dest/'stdout').read_text()[:6000])
