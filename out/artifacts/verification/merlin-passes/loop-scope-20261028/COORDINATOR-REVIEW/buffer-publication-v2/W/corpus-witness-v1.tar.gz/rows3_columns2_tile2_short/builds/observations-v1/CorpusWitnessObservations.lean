import CorpusWitnessExecution
set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphCorpusWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation
theorem ordered_execution_witness : ∃ h0 h1 : PrivateHeap,
    GraphLoopsMemorySCF.Execution plan.objects plan.configs meaning false false
      kernel.instructions initial (state28 h0 h1) ∧
    (state14 h0 h1).observed.callerHeap 2 0 = some 13 ∧
    (state25 h0 h1).observed.callerHeap 2 0 = some 23 ∧
    (state28 h0 h1).observed.returned = [.scalar "i32" 36, .index 3] ∧
    (∀ index, index < 6 → h0 0 index = some 3) ∧
    (∀ index, index < 6 → h1 1 index = some 5) := by
  obtain ⟨h0, h1, run, all0, all1⟩ := source_epoch_run
  exact ⟨h0, h1, run, rfl, rfl, rfl, all0, all1⟩
theorem private_objects_hidden (object index : Nat) (inside : object < 2) :
    observation.heap object index = none := by
  have different : object ≠ 2 := by omega
  simp only [observation, publicHeap, different, false_and, ↓reduceIte]
theorem caller_changed : initialHeap 2 0 = some 7 ∧ observation.heap 2 0 = some 23 := ⟨rfl, rfl⟩
end GraphCorpusWitness
