import KernelWitnessStates
import Merlin.GraphLoopsMemorySCFWitness
set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphMemoryKernelWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation

abbrev OldMeaning := GraphLoopsMemorySCF.Interpretation Int (Epoch.PublicState Int Nat)
def meaning : OldMeaning := plan.oldMeaning scalar

theorem initialization0_exists : ∃ h0 : PrivateHeap,
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction7
      (state7 initialHeap initialHeap) (state8 h0 initialHeap) ∧
    (∀ index, index < 6 → h0 0 index = some 3) := by
  obtain ⟨heap, run, values⟩ := GraphLoopsMemorySCF.Witness.uniform_heap meaning.pure
    2 3 10 11 0 2 0 (by decide) (by decide) (by decide) (by decide) (by decide)
    (meaning.captures (state7 initialHeap initialHeap).observed) 3 (by rfl)
    (state7 initialHeap initialHeap).heap
  refine ⟨heap, ?_, values⟩
  exact GraphLoopsMemorySCF.Step.initialized (config := link0.config) (by decide)
    (state7 initialHeap initialHeap) run

theorem initialization1_exists (h0 : PrivateHeap) : ∃ h1 : PrivateHeap,
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction18
      (state18 h0 initialHeap) (state19 h0 h1) ∧
    (∀ index, index < 6 → h1 1 index = some 5) := by
  obtain ⟨heap, run, values⟩ := GraphLoopsMemorySCF.Witness.uniform_heap meaning.pure
    2 3 20 21 1 2 1 (by decide) (by decide) (by decide) (by decide) (by decide)
    (meaning.captures (state18 h0 initialHeap).observed) 5 (by rfl)
    (state18 h0 initialHeap).heap
  refine ⟨heap, ?_, values⟩
  exact GraphLoopsMemorySCF.Step.initialized (config := link1.config) (by decide)
    (state18 h0 initialHeap) run

end GraphMemoryKernelWitness
