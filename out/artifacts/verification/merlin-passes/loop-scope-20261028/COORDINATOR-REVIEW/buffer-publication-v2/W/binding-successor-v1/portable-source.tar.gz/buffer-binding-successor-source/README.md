# Source-only binding successor

This package contains the exact191 source files, Q5 raw4 inputs and exact generated query/parts/root rosters for five cases. Only buffer_reuse_intake.py differs from Q5: five already imported scheduler files join the fingerprint. No semantics, generated theorem, policy or toolchain changes.

In a compatible Python environment, run `python -I -B rebase.py` within this extracted directory. Then use `python -I -B run.py . /NEW/prepare --mode prepare`. For an explicitly selected Lean executable, `python -I -B run.py . /NEW/check --mode check --lean /ABS/lean`. After success, a separate process runs `python -I -B run.py . /NEW/replay --mode replay --lean /ABS/lean --report /NEW/check/fresh-check/REPORT.json`. Each destination must be new. The harness admits only local Merlin Python sources, checks all191 bytes before/after and confirms all five query/part/root rosters before checking the retained baseline. Fresh project proof objects are built.

No SDK, binaries or old project proof objects are supplied. Linux receipts are historical evidence, not laptop authority. The existing selected Python/Lean environment remains a dependency; this is not new-host admission. Third-party Python packages and Lean/runtime fidelity remain trust boundaries. The baseline fresh native check/replay covers one case, while all-five source-generated identities are checked. The original F2 five-case campaign has its own exact Q5 historical source cut.

The relation concerns possible successful public observations under typed input/caller domains and total private unobservable allocation. It does not establish error/divergence, finite allocator capacity, arbitrary aliasing, native hardware or numerical fidelity, or independent human approval.
