"""Record source-only proof closure and exact new witness evidence, no SDK reads."""
from pathlib import Path
import difflib
import hashlib
import json

BASE = Path(__file__).resolve().parent
REPO = Path.cwd()
CASES = ('three_disjoint_epochs', 'alignment32_tile3', 'rows1_columns1_tile3', 'rows3_columns2_tile2_short')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def record(path):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(REPO)), sha256=sha(data), bytes=len(data))


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


closure = {}
outcomes = []
owned = []
for name in CASES:
    case = BASE / name
    audit = json.loads((case / 'complete-audit-v1/audit.stdout').read_text())
    types = json.loads((case / 'complete-audit-v1/types.stdout').read_text())['statements']
    roots = json.loads((case / 'COMPLETE-ROOTS.json').read_text())
    assert not audit['violations'] and set(types) == set(roots)
    assert set(audit['axioms_used']) <= {'propext', 'Classical.choice', 'Quot.sound'}
    assert types['GraphCorpusWitness.actual_kernel_nonvacuity'].lstrip().startswith('And ')
    sources = {}
    for path in sorted((case / 'sources').glob('*.lean')):
        row = record(path)
        owned.append(row)
        version = path.stem.removeprefix('CorpusWitness').lower() + '-v1'
        build = json.loads((case / 'builds' / version / 'PROCESS.json').read_text())
        assert build['returncode'] == 0 and build['source_sha256'] == row['sha256']
        sources[path.stem] = row
        closure[row['path']] = row
    dependencies = json.loads((case / 'ACTUAL-QUERY-DEPENDENCIES.json').read_text())['modules']
    query = {row['module']: row for row in dependencies}
    for item in audit['imports']:
        module = item['module']
        if module.startswith('CorpusWitness'):
            path = case / 'sources' / (module + '.lean')
        elif module in query:
            path = REPO / query[module]['source']
            assert sha(path.read_bytes()) == query[module]['source_sha256']
        elif module.startswith('Merlin.'):
            path = REPO / 'src/merlin/verify/lean' / Path(*module.split('.')).with_suffix('.lean')
        else:
            # Builtin/toolchain imports remain in raw Lean audit metadata. Do
            # not open their objects or source/archive images here.
            continue
        row = record(path)
        sources[module] = row
        closure[row['path']] = row
    write(case / 'SOURCE-CLOSURE.json', sources)
    proposal = json.loads((case / 'PROPOSED-STATES.json').read_text())
    result = dict(case=name, status='development_compiled_std3_audited', root='GraphCorpusWitness.actual_kernel_nonvacuity',
                  root_has_premises=False, audited_modules=json.loads((case / 'COMPLETE-AUDIT-MODULES.json').read_text()), printed_roots=len(roots), transitive_theorems=audit['theorems_audited'],
                  violations=[], interpretation='Int addition for selected binary operations; literal value 1',
                  source_commands=len(proposal['states']), initializer_cells=proposal['initialized_volumes'],
                  input_scalars=[3, 5], initial_caller=7, returned=proposal['returned'], final_caller=proposal['caller'],
                  ordered_touches=proposal['touches'], user=99,
                  actual_raw4=json.loads((case / 'RAW4.json').read_text()),
                  qualification=False, native_fidelity=False, finite_allocator_equivalence=False, human_approval=False)
    write(case / 'RESULT.json', result)
    outcomes.append(result)

for path in sorted(BASE.glob('*.py')):
    row = record(path)
    owned.append(row)
    closure[row['path']] = row
audit_source = REPO / 'src/merlin/verify/lean/Merlin/GraphStateAudit.lean'
closure[str(audit_source.relative_to(REPO))] = record(audit_source)
write(BASE / 'OWNED-SOURCES.json', owned)
write(BASE / 'SOURCE-CLOSURE.json', list(closure.values()))
snapshot = BASE / 'complete-source-snapshot'
snapshot.mkdir(exist_ok=False)
for row in closure.values():
    path = snapshot / row['path']
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((REPO / row['path']).read_bytes())
patch = ''.join(''.join(difflib.unified_diff([], (REPO / row['path']).read_text().splitlines(keepends=True),
                                          fromfile='/dev/null', tofile='b/' + row['path'])) for row in owned)
(BASE / 'owned-source.patch').write_text(patch)

old_base = BASE.parents[2] / 'W/kernel-witness-v1'
old_raw = json.loads((old_base / 'RAW-BINDINGS.json').read_text())
retained_raw = json.loads((BASE / 'retained_two_epochs/RAW4.json').read_text())
for old, new in zip(old_raw, retained_raw, strict=True):
    assert old['sha256'] == new['sha256']
    assert (REPO / old['path']).read_bytes() == (REPO / new['path']).read_bytes()
write(BASE / 'RETAINED-EXACT-RAW4.json', dict(old_witness=str(old_base.relative_to(REPO)), old=old_raw, current=retained_raw,
                                           all_four_bytes_identical=True, no_rebuild=True))
write(BASE / 'RESULT.json', dict(new_actual_cases=outcomes, retained_case='RETAINED-EXACT-RAW4.json',
                                owned_sources=len(owned), project_source_closure=len(closure),
                                scope='existing finite actual F buffer corpus; successful public observations only',
                                allocator='total/private/unobservable; 8-to-16-byte finite-capacity counterexample retained',
                                qualification=False, native_fidelity=False, human_approval=False))
print(json.dumps(dict(new_cases=len(outcomes), owned_sources=len(owned), source_closure=len(closure))))
