import CorpusWitnessSteps
set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphCorpusWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation
open GraphMemoryAfterWhole GraphMemoryAfterExpansion
open Merlin.GraphLoopsMemorySCF.After
theorem source_epoch_run : ∃ h0 h1 h2 : PrivateHeap,
    GraphLoopsMemorySCF.Execution plan.objects plan.configs meaning false false
      kernel.instructions initial (state40 h0 h1 h2) ∧
    (∀ index, index < 6 → h0 0 index = some 3) ∧
    (∀ index, index < 6 → h1 1 index = some 5) ∧
    (∀ index, index < 6 → h2 2 index = some 3) := by
  obtain ⟨h0, run0, all0⟩ := initialization0_exists 
  obtain ⟨h1, run1, all1⟩ := initialization1_exists h0
  obtain ⟨h2, run2, all2⟩ := initialization2_exists h0 h1
  refine ⟨h0, h1, h2, ?_, all0, all1, all2⟩
  rw [← instructions_exact]
  exact GraphLoopsMemorySCF.Execution.more (step0 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step1 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step2 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step3 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step4 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step5 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step6 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more run0 (
    GraphLoopsMemorySCF.Execution.more (step8 h0 h1 h2 (all0 0 (by decide))) (
    GraphLoopsMemorySCF.Execution.more (step9 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step10 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step11 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step12 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step13 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step14 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step15 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step16 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step17 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more run1 (
    GraphLoopsMemorySCF.Execution.more (step19 h0 h1 h2 (all1 0 (by decide))) (
    GraphLoopsMemorySCF.Execution.more (step20 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step21 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step22 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step23 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step24 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step25 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step26 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step27 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step28 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more run2 (
    GraphLoopsMemorySCF.Execution.more (step30 h0 h1 h2 (all2 0 (by decide))) (
    GraphLoopsMemorySCF.Execution.more (step31 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step32 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step33 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step34 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step35 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step36 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step37 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step38 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.more (step39 h0 h1 h2) (
    GraphLoopsMemorySCF.Execution.done _))))))))))))))))))))))))))))))))))))))))
def publicHeap : GraphLoopsReuse.Heap Int := fun object index =>
  if object = 3 ∧ index = 0 then some 29 else none
def observation : Epoch.Observation Int Nat :=
  ⟨[.scalar "i32" 65, .index 2], publicHeap, 99⟩
theorem final_state_observation (h0 h1 h2 : PrivateHeap) :
    Epoch.observePublic plan.objects.length (state40 h0 h1 h2).observed = observation := by
  change Epoch.Observation.mk [.scalar "i32" 65, .index 2]
    (Epoch.visibleHeap 3 (GraphLoopsReuse.replaceCell (GraphLoopsReuse.replaceCell (GraphLoopsReuse.replaceCell initialHeap 3 0 13) 3 0 23) 3 0 29)) 99 = observation
  unfold observation
  congr 1
  funext object index
  by_cases same : object = 3 <;> by_cases cell : index = 0 <;>
    simp [Epoch.visibleHeap, GraphLoopsReuse.replaceCell, GraphLoopsReuse.replaceObject,
      initialHeap, publicHeap, same, cell]
theorem normalized_source_success : Epoch.graphOutcomes plan.objects.length
    (Epoch.graphMeaning plan.opcodes scalar) plan.module kernel.function.name
    inputs initialHeap user observation := by
  obtain ⟨h0, h1, h2, run, _, _, _⟩ := source_epoch_run
  apply (kernel.observations plan (of_decide_eq_true plan_valid) (of_decide_eq_true kernel_facts)
    scalar inputs inputs_typed callers_valid initialHeap user observation).mpr
  exact ⟨(state40 h0 h1 h2).observed, ⟨state40 h0 h1 h2, run, rfl⟩, final_state_observation h0 h1 h2⟩

theorem original_source_success : Epoch.graphOutcomes plan.objects.length
    (Epoch.graphMeaning plan.opcodes scalar) independentSource kernel.function.name
    inputs initialHeap user observation :=
  (Epoch.shape_outcomes independentSource 64 source_valid plan.module source_normalized
    plan.objects.length (Epoch.graphMeaning plan.opcodes scalar) kernel.function.name
    inputs initialHeap user observation).mpr normalized_source_success

theorem source_success : Epoch.graphOutcomes plan.objects.length
    (finalMeaning 64 indices plan.opcodes scalar) independentSource kernel.function.name
    inputs initialHeap user observation := by
  obtain ⟨returned, world, run, observed⟩ := original_source_success
  exact ⟨returned, world,
    (source_complete_extension 64 indices plan.opcodes scalar independentSource source_index_absent
      kernel.function.name inputs _ returned world).mp run, observed⟩

theorem actual_final_success : Epoch.graphOutcomes plan.objects.length
    (finalMeaning 64 indices plan.opcodes scalar) GraphMemoryAfterMaterialization.actualFinal
    kernel.function.name inputs initialHeap user observation :=
  (GraphMemoryAfterWhole.complete_actual_chain scalar inputs inputs_typed callers_valid
    initialHeap user observation).mp source_success


theorem actual_source_entry_success : Epoch.graphOutcomes plan.objects.length
    (entryMeaning 64 indices plan.opcodes scalar GraphMemoryAfterEntries.literals literal)
    independentSource kernel.function.name inputs initialHeap user observation :=
  (literal_outcomes_extension plan.objects.length (finalMeaning 64 indices plan.opcodes scalar)
    GraphMemoryAfterEntries.literals literal independentSource GraphMemoryAfterEntries.kernelReachable
    GraphMemoryAfterEntries.kernel_support.2.1 GraphMemoryAfterEntries.kernel_support.2.2.2.1
    kernel.function.name GraphMemoryAfterEntries.kernel_support.1 inputs initialHeap user observation).mp source_success

theorem actual_final_entry_success : Epoch.graphOutcomes plan.objects.length
    (entryMeaning 64 indices plan.opcodes scalar GraphMemoryAfterEntries.literals literal)
    GraphMemoryAfterMaterialization.actualFinal kernel.function.name inputs initialHeap user observation :=
  (GraphMemoryAfterEntries.complete_roster scalar literal GraphMemoryAfterEntries.entry0Row
    GraphMemoryAfterEntries.entry0_member inputs domain initialHeap user observation).mp actual_source_entry_success

theorem actual_kernel_nonvacuity :
    EntryDomain independentSource plan kernel GraphMemoryAfterEntries.entry0Row inputs ∧
    Epoch.graphOutcomes plan.objects.length
      (entryMeaning 64 indices plan.opcodes scalar GraphMemoryAfterEntries.literals literal)
      independentSource kernel.function.name inputs initialHeap user observation ∧
    Epoch.graphOutcomes plan.objects.length
      (entryMeaning 64 indices plan.opcodes scalar GraphMemoryAfterEntries.literals literal)
      GraphMemoryAfterMaterialization.actualFinal kernel.function.name inputs initialHeap user observation :=
  ⟨domain, actual_source_entry_success, actual_final_entry_success⟩

theorem ordered_touch0 (h0 h1 h2 : PrivateHeap) : (state14 h0 h1 h2).observed.callerHeap 3 0 = some 13 ∧ (state14 h0 h1 h2).observed.registers 18 = .scalar "i32" 13 := ⟨rfl, rfl⟩
theorem ordered_touch1 (h0 h1 h2 : PrivateHeap) : (state25 h0 h1 h2).observed.callerHeap 3 0 = some 23 ∧ (state25 h0 h1 h2).observed.registers 30 = .scalar "i32" 23 := ⟨rfl, rfl⟩
theorem ordered_touch2 (h0 h1 h2 : PrivateHeap) : (state36 h0 h1 h2).observed.callerHeap 3 0 = some 29 ∧ (state36 h0 h1 h2).observed.registers 42 = .scalar "i32" 29 := ⟨rfl, rfl⟩
theorem returned_exact : observation.returned = [.scalar "i32" 65, .index 2] := rfl
theorem caller_exact : observation.heap 3 0 = some 29 := rfl
theorem user_exact : observation.user = 99 := rfl
theorem all_other_cells_unchanged (object index : Nat) (different : object ≠ 3 ∨ index ≠ 0) :
    observation.heap object index = initialHeap object index := by
  rcases different with outside | offset
  · simp only [observation, publicHeap, initialHeap, outside, false_and, ↓reduceIte]
  · simp only [observation, publicHeap, initialHeap, offset, and_false, ↓reduceIte]
end GraphCorpusWitness
