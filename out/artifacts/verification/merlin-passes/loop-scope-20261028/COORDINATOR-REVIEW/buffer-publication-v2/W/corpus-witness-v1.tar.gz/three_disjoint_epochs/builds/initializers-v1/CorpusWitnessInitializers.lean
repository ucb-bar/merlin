import CorpusWitnessStates
import Merlin.GraphLoopsMemorySCFWitness
set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphCorpusWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation
abbrev OldMeaning := GraphLoopsMemorySCF.Interpretation Int (Epoch.PublicState Int Nat)
def meaning : OldMeaning := plan.oldMeaning scalar
theorem initialization0_exists  : ∃ h0 : PrivateHeap,
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction7
      (state7 initialHeap initialHeap initialHeap) (state8 h0 initialHeap initialHeap) ∧
    (∀ index, index < 6 → h0 0 index = some 3) := by
  obtain ⟨heap, run, values⟩ := GraphLoopsMemorySCF.Witness.uniform_heap meaning.pure
    2 3 10 11 0 2 0 (by decide) (by decide) (by decide) (by decide) (by decide)
    (meaning.captures (state7 initialHeap initialHeap initialHeap).observed) 3 (by rfl)
    (state7 initialHeap initialHeap initialHeap).heap
  refine ⟨heap, ?_, values⟩
  exact GraphLoopsMemorySCF.Step.initialized (config := link0.config) (by decide)
    (state7 initialHeap initialHeap initialHeap) run
theorem initialization1_exists (h0 : PrivateHeap) : ∃ h1 : PrivateHeap,
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction18
      (state18 h0 initialHeap initialHeap) (state19 h0 h1 initialHeap) ∧
    (∀ index, index < 6 → h1 1 index = some 5) := by
  obtain ⟨heap, run, values⟩ := GraphLoopsMemorySCF.Witness.uniform_heap meaning.pure
    2 3 20 21 1 2 1 (by decide) (by decide) (by decide) (by decide) (by decide)
    (meaning.captures (state18 h0 initialHeap initialHeap).observed) 5 (by rfl)
    (state18 h0 initialHeap initialHeap).heap
  refine ⟨heap, ?_, values⟩
  exact GraphLoopsMemorySCF.Step.initialized (config := link1.config) (by decide)
    (state18 h0 initialHeap initialHeap) run
theorem initialization2_exists (h0 h1 : PrivateHeap) : ∃ h2 : PrivateHeap,
    GraphLoopsMemorySCF.Step plan.objects plan.configs meaning false false instruction29
      (state29 h0 h1 initialHeap) (state30 h0 h1 h2) ∧
    (∀ index, index < 6 → h2 2 index = some 3) := by
  obtain ⟨heap, run, values⟩ := GraphLoopsMemorySCF.Witness.uniform_heap meaning.pure
    2 3 30 31 0 2 2 (by decide) (by decide) (by decide) (by decide) (by decide)
    (meaning.captures (state29 h0 h1 initialHeap).observed) 3 (by rfl)
    (state29 h0 h1 initialHeap).heap
  refine ⟨heap, ?_, values⟩
  exact GraphLoopsMemorySCF.Step.initialized (config := link2.config) (by decide)
    (state29 h0 h1 initialHeap) run
end GraphCorpusWitness
