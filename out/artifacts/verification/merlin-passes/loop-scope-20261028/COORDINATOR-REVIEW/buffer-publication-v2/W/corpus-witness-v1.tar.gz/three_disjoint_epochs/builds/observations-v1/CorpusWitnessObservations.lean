import CorpusWitnessExecution
set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphCorpusWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation
theorem ordered_execution_witness : ∃ h0 h1 h2 : PrivateHeap,
    GraphLoopsMemorySCF.Execution plan.objects plan.configs meaning false false
      kernel.instructions initial (state40 h0 h1 h2) ∧
    (state14 h0 h1 h2).observed.callerHeap 3 0 = some 13 ∧
    (state25 h0 h1 h2).observed.callerHeap 3 0 = some 23 ∧
    (state36 h0 h1 h2).observed.callerHeap 3 0 = some 29 ∧
    (state40 h0 h1 h2).observed.returned = [.scalar "i32" 65, .index 2] ∧
    (∀ index, index < 6 → h0 0 index = some 3) ∧
    (∀ index, index < 6 → h1 1 index = some 5) ∧
    (∀ index, index < 6 → h2 2 index = some 3) := by
  obtain ⟨h0, h1, h2, run, all0, all1, all2⟩ := source_epoch_run
  exact ⟨h0, h1, h2, run, rfl, rfl, rfl, rfl, all0, all1, all2⟩
theorem private_objects_hidden (object index : Nat) (inside : object < 3) :
    observation.heap object index = none := by
  have different : object ≠ 3 := by omega
  simp only [observation, publicHeap, different, false_and, ↓reduceIte]
theorem caller_changed : initialHeap 3 0 = some 7 ∧ observation.heap 3 0 = some 29 := ⟨rfl, rfl⟩
end GraphCorpusWitness
