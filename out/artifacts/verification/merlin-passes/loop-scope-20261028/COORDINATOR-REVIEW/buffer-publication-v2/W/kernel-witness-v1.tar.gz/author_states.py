"""Emit concrete witness states; Lean checks every transition and actual list binding.

Python's arithmetic here only proposes witnesses. It is not an evaluator accepted
as proof and cannot discharge a semantic obligation.
"""
from pathlib import Path
import json
from merlin.verify.lean_graph_loops_shape_epoch_plan import spec
from merlin.verify.lean_graph_loops_unroll import _string

BASE = Path(__file__).resolve().parent
adapter = json.loads((BASE/'ACTUAL-PLAN.json').read_text())['adapter']
plan = adapter['step_binding']
steps = plan['steps'] + [dict(instruction=plan['terminal'])]
specs = dict(plan['specifications'])
registers = {0:3, 1:5}
private = {}
caller = 7
text = '''import KernelWitnessBase
set_option autoImplicit false
set_option maxRecDepth 16384
set_option maxHeartbeats 2000000
namespace GraphMemoryKernelWitness
open Merlin Merlin.GraphLoopsShape
open GraphShapeEpochObligation
abbrev State := GraphLoopsReuse.Memory Int (Epoch.PublicState Int Nat)
abbrev PrivateHeap := GraphLoopsReuse.Heap Int
def state0 (_h0 _h1 : PrivateHeap) : State := initial
'''
records=[]
for i, step in enumerate(steps):
    instruction = step['instruction']; tag = instruction['kind']; before=f'(state{i} h0 h1)'
    if tag in ('allocate','release'):
        value=f'.{tag} {instruction["object"]} {str(instruction["retained"]).lower()}'
        after=f'GraphLoopsReuse.clearMemory plan.objects false {instruction["object"]} {str(instruction["retained"]).lower()} {before}'
    else:
        key=instruction['key']; value=f'.{tag} '+('' if tag=='retained' else str(instruction['object'])+' ')+_string(key)
        if tag=='initialize':
            object=instruction['object']; seed=3 if object==0 else 5; private[object]=seed
            after=f'⟨{before}.observed, h{object}⟩'
        else:
            chosen=specs[key]; tag2=chosen['tag']
            text+=f'def spec{i} : Epoch.Spec := {spec(chosen)}\n'
            text+=f'theorem spec{i}_selected : Epoch.specAt plan.specifications {_string(key)} = some spec{i} := by decide\n'
            if tag2=='constant':
                n=chosen['result']['name']; registers[n]=chosen['value'];runtime=f'.index {registers[n]}'
            elif tag2=='binary':
                n=chosen['result']['name'];registers[n]=registers[chosen['left']['name']]+registers[chosen['right']['name']];runtime=f'.scalar "i32" {registers[n]}'
            elif tag2=='observer':
                n=chosen['result']['name'];caller+=registers[chosen['input']['name']];registers[n]=caller;runtime=f'.scalar "i32" {caller}'
            elif tag2=='load':
                n=chosen['result']['name'];registers[n]=private[chosen['access']['object']];runtime=f'.scalar "i32" {registers[n]}'
            if tag2 in ['constant','binary','load']:
                after=f'⟨Epoch.writeRegister {before}.observed {n} ({runtime}), {before}.heap⟩'
            elif tag2=='observer':
                after=f'⟨{{ Epoch.writeRegister {before}.observed {n} ({runtime}) with callerHeap := GraphLoopsReuse.replaceCell {before}.observed.callerHeap 2 0 {caller} }}, {before}.heap⟩'
            elif tag2=='store':
                v=registers[chosen['value']['name']];object=chosen['access']['object'];private[object]=v
                after=f'GraphLoopsReuse.storeMemory plan.objects false {object} 0 {v} {before}'
            elif tag2=='returned':
                returned=[registers[v['name']] for v in chosen['values']];assert returned==[36,2]
                after=f'⟨{{ {before}.observed with returned := [.scalar "i32" 36, .index 2] }}, {before}.heap⟩'
    text+=f'def instruction{i} : GraphLoopsReuse.Instruction := {value}\n'
    text+=f'def state{i+1} (h0 h1 : PrivateHeap) : State := {after}\n'
    records.append(dict(index=i,instruction=instruction,public_caller=caller,registers=dict(registers)))
text+='def instructions : List GraphLoopsReuse.Instruction := ['+','.join(f'instruction{i}' for i in range(len(steps)))+']\n'
text+='theorem instructions_exact : instructions = kernel.instructions := by decide\n'
text+='end GraphMemoryKernelWitness\n'
(BASE/'KernelWitnessStates.lean').write_text(text)
(BASE/'PROPOSED-STATES.json').write_text(json.dumps(dict(trusted_execution=False,checked_by='Lean per-step constructors and instructions_exact (once compiled)',states=records),indent=2)+'\n')
