"""Bind successful old-Q5/F2 evidence, without relabeling the new 191 cut.

The main gate campaign and the supplementary corpus-witness build have separate
statuses. This collector performs file/data checks only and launches no compiler.
"""
import hashlib
import json
import subprocess
from pathlib import Path

root = Path.cwd()
f = Path(__file__).resolve().parent.parent
out = f / "delivery-v2"
producer = Path("/home/jeremy/Projects/merlin-graph-proof-intake")


def read(path):
    return json.loads(path.read_text())


def reference(path):
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def verify(old, path=None):
    path = Path(old["path"]) if path is None else path
    path = path if path.is_absolute() else root / path
    actual = reference(path)
    assert actual["sha256"] == old["sha256"]
    assert actual["bytes"] == old.get("bytes", old.get("size"))
    return path


def write(path, document):
    path.write_text(json.dumps(document, indent=2) + "\n")


sources = {}


def source(old, role, selected=None):
    original = Path(old["path"])
    original = original if original.is_absolute() else root / original
    selected = verify(old, selected)
    context = "submission" if original.is_relative_to(root) else "pinned4499" if original.is_relative_to(producer) else None
    assert context is not None
    base = root if context == "submission" else producer
    relative = str(original.relative_to(base))
    key = (context, relative)
    if key not in sources:
        target = out / "sources" / context / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(selected.read_bytes())
        verify(old, target)
        sources[key] = {"root": context, "path": relative, "sha256": old["sha256"], "bytes": old.get("bytes", old.get("size")), "snapshot": str(target.relative_to(f)), "roles": []}
    assert sources[key]["sha256"] == old["sha256"]
    sources[key]["roles"].append(role)


result = read(f / "qualification-v2/RESULT.json")
assert result["status"] == "BOUNDED_BUFFER_ENGINEERING_BATCH_PASSED"
assert (result["actual_gate_positives"], result["valid_mutant_quadruples"], result["actual_gate_native_refusals"], result["host_refusals"]) == (5, 24, 1, 23)
assert result["failed_or_unavailable"] == []
replay = read(f / "qualification-v2/fresh-process-replay/RESULT.json")
assert replay["status"] == "checked" and replay["incoming_ledger"] == 0 and replay["issued_live_completions"] == 1
assert read(f / "qualification-v2/artifact-controls/RESULT.json")["attacks"] == 9
baseline = read(f / "kernel-witness-binding-v1/RESULT.json")
assert len(baseline["roots"]) == 326 and len(baseline["audited_modules"]) == 17 and baseline["audit"]["violations"] == []
corpus = read(f / "corpus-witness-binding-v1/FINAL.json")
assert corpus["status"] == "PARTIAL_UNAVAILABLE_FIRST_WITNESS_COMPILE_TIMEOUT"
assert corpus["completed_cases"] == 0

old186 = read(out / "OLD186-SOURCES.json")
assert old186["source_count"] == 186
for old in old186["sources"]:
    source(old, "historical_Q5_F2_gate_bound_source", out / "old186-source-snapshot" / old["path"])
reports = []
for row in read(f / "qualification-v2/POSITIVES.json"):
    assert row["status"] == "checked" and row["consumer_called"] and row["final_bytes_identical"]
    report = read(verify(row["report"]))
    assert len(report["sources"]) == 186 and len(report["statements"]) == row["roots"]
    assert "GraphMemoryAfterEntries.every_definition" in report["statements"]
    assert report["audit"]["violations"] == []
    assert set(report["audit"]["axioms_used"]) <= {"propext", "Classical.choice", "Quot.sound"}
    for old in [*report["library"], *report["actual4"], report["query"], *report["process_evidence"]]:
        verify(old)
    reports.append({"case": row["name"], "report": row["report"], "roots": row["roots"], "audit_theorems": report["audit"]["theorems_audited"]})
for old in read(f / "source-cut-v2/SOURCES.json")["sources"]:
    source(old, "F_owned_qualification_source")
qcut = f.parent / "Q/source-cut-v5"
for old in read(qcut / "SOURCES.json")["sources"]:
    source(old, "Q_frozen_v5_source", qcut / old["snapshot"])
for old in read(f / "qualification-v2/EXACT-INPUTS.json")["producer_sources"]:
    source(old, "actually_loaded_pinned4499_producer_source")
for path in sorted((f / "kernel-witness-binding-v1").glob("*.lean")):
    source(reference(path), "F_independently_compiled_baseline_constructive_witness")
for path in sorted((f / "corpus-witness-binding-v1/three_disjoint_epochs").glob("*.lean")):
    source(reference(path), "F_corpus_witness_candidate_NOT_qualified_timeout")
for folder in ["kernel-witness-binding-v1", "corpus-witness-binding-v1", "supplementary-mutants-v1", "unsupported-boundaries-v1", "compiler-byte-binding-v2", "compiler-oracle-controls-v1", "negative-binding-offline-v1", "delivery-v1", "delivery-v2"]:
    for path in sorted((f / folder).glob("*.py")):
        source(reference(path), "owned_artifact_binding_or_data_runner")
manifest = {"schema": "merlin.buffer.F-source-delivery.v2", "status": "HISTORICAL_Q5_F2_186_SOURCE_COHORT_PLUS_OWNED_QUALIFICATION", "sources": sorted(sources.values(), key=lambda item: (item["root"], item["path"])), "native_binaries_included": False, "new191_qualification": False}
write(f / "SOURCE-DELIVERY.json", manifest)
status = {"schema": "merlin.buffer.F-final.v2", "status": "SCOPED_BUFFER_MAIN_QUALIFICATION_PASSED_SUPPLEMENTARY_CORPUS_WITNESS_BUILD_PARTIAL", "branch": subprocess.check_output(["git", "branch", "--show-current"], text=True).strip(), "HEAD_at_seal": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(), "Q_source_cut": "v5 historical186", "F_source_cut": "v2", "campaign": reference(f / "qualification-v2/RESULT.json"), "positive_reports": reports, "separate_fresh_process_replay": reference(f / "qualification-v2/fresh-process-replay/RESULT.json"), "baseline_independent_witness": reference(f / "kernel-witness-binding-v1/RESULT.json"), "four_additional_independent_witnesses": reference(f / "corpus-witness-binding-v1/FINAL.json"), "source_manifest": reference(f / "SOURCE-DELIVERY.json"), "owned_source_patch": "source-cut-v2/owned.patch", "relation": "equal_possible_successful_returned_public_caller_heap_user_observation_sets", "full_error_world_equivalence": False, "allocator_mode": "total_private_unobservable", "human_approved": False, "native_word_allocator_descriptor_alias_hardware_fidelity": False, "production_wide_enforcement": False, "new191_qualification": False, "next_task": "NEXT-CONFIGURATION/F/TASK.md HELD until root review+primary merge release"}
write(f / "FINAL_STATUS.json", status)
print(json.dumps({"status": status["status"], "selected_source_files": len(sources), "positive_cases": len(reports), "baseline_independent_witness": True, "all4_additional_independent_witnesses": False}))
