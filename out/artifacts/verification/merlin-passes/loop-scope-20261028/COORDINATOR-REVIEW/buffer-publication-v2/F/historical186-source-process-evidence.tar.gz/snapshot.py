"""Source/data-only preservation of the exact historical 186-source cohort."""
import hashlib
import json
import shutil
from pathlib import Path

root = Path.cwd()
out = Path(__file__).resolve().parent
f = out.parent


def ref(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(root)), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


write(out / "FIRST-COLLECTOR-ERROR.json", {"phase": "initial inline source-only collector", "error": "KeyError: bytes", "cause": "report project source refs use size, unlike file refs", "native_launched": False, "snapshot_was_not_saved": True})
qcut = f.parent / "Q/source-cut-v5"
qrows = {row["path"]: row for row in json.loads((qcut / "SOURCES.json").read_text())["sources"]}
entries = {}
for row in json.loads((f / "qualification-v2/POSITIVES.json").read_text()):
    report = json.loads(Path(row["report"]["path"]).read_text())
    assert len(report["sources"]) == 186
    for old in report["sources"]:
        path = Path(old["path"])
        path = path if path.is_absolute() else root / path
        relative = str(path.relative_to(root))
        expected = {"path": relative, "sha256": old["sha256"], "bytes": old.get("bytes", old.get("size"))}
        selected = path
        if ref(path) != expected:
            frozen = qrows[relative]
            selected = qcut / frozen["snapshot"]
            observed = ref(selected)
            assert observed["sha256"] == expected["sha256"] and observed["bytes"] == expected["bytes"]
        assert relative not in entries or entries[relative]["ref"] == expected
        entries[relative] = {"ref": expected, "selected": selected}

for relative, entry in entries.items():
    target = out / "old186-source-snapshot" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(entry["selected"].read_bytes())
    actual = ref(target)
    assert actual["sha256"] == entry["ref"]["sha256"] and actual["bytes"] == entry["ref"]["bytes"]

write(out / "OLD186-SOURCES.json", {"schema": "merlin.buffer.F.old186.snapshot.v1", "status": "EXACT_HISTORICAL_Q5_F2_186_SOURCE_SNAPSHOT", "source_count": len(entries), "sources": sorted([item["ref"] for item in entries.values()], key=lambda item: item["path"]), "source_snapshot": "old186-source-snapshot", "future191_qualification": False})
first = f / "corpus-witness-binding-v1/three_disjoint_epochs/build-CorpusWitnessStates/PROCESS.json"
process = json.loads(first.read_text())
write(f / "corpus-witness-binding-v1/FINAL.json", {"status": "PARTIAL_UNAVAILABLE_FIRST_WITNESS_COMPILE_TIMEOUT", "completed_cases": 0, "expected_cases": 4, "first_case": "three_disjoint_epochs", "first_module": "CorpusWitnessStates", "timeout_seconds": 120, "process": ref(first), "raw_traceback": ref(f / "corpus-witness-binding-v1/runner.log"), "cleanup": process["cleanup"], "no_unchanged_retry": True, "baseline_independent_witness": "kernel-witness-binding-v1/RESULT.json", "main_qualification": "qualification-v2/RESULT.json", "main_qualification_status_unchanged": True, "independent_F_all4_witness_qualification": False, "human_approved": False})
write(out / "SAFE-BOUNDARY.json", {"status": "ALL_F_NATIVE_JOBS_TERMINAL_OLD186_SOURCE_SNAPSHOT_SAVED", "old186_manifest": ref(out / "OLD186-SOURCES.json"), "baseline_witness": ref(f / "kernel-witness-binding-v1/RESULT.json"), "corpus_partial": ref(f / "corpus-witness-binding-v1/FINAL.json"), "canonical186_hold_released": True, "native_retries": False})
print(json.dumps({"status": "SAFE_BOUNDARY_OLD186_SAVED", "sources": len(entries), "all_F_native_jobs_terminal": True, "four_corpus_witnesses": "UNAVAILABLE timeout preserved"}))
