"""Retain source/text outputs and seal the historical F qualification packet.

No native execution, SDK reads or proof-status changes occur here. The seal
records bytes; it is not a mathematical or human-review authority.
"""
import hashlib
import json
from pathlib import Path

root = Path.cwd()
f = Path(__file__).resolve().parent.parent
out = f / "delivery-v2"


def ref(path):
    data = path.read_bytes()
    return {"path": str(path.relative_to(root)), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def verify(old, path):
    actual = ref(path)
    assert actual["sha256"] == old["sha256"] and actual["bytes"] == old.get("bytes", old.get("size"))


copies = []
positives = json.loads((f / "qualification-v2/POSITIVES.json").read_text())
replay = json.loads((f / "qualification-v2/fresh-process-replay/RESULT.json").read_text())
selected = [(row["name"], row["report"]) for row in positives] + [("fresh-process-replay", replay["report"])]
for case, report_ref in selected:
    report_path = Path(report_ref["path"])
    verify(report_ref, report_path)
    report = json.loads(report_path.read_text())
    paths = {report_path}
    paths.update(Path(item["path"]) for item in report["actual4"])
    paths.update(Path(item["path"]) for item in report["process_evidence"])
    paths.add(Path(report["query"]["path"]))
    paths.update(report_path.parent.glob("*.lean"))
    for path in sorted(paths):
        assert path.is_relative_to(root / "out/build/loop-scope-20261028/qualification/buffer-final-v2")
        assert not path.is_symlink() and path.is_file()
        target = out / "retained-output" / case / path.name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(path.read_bytes())
        original = ref(path)
        verify(original, target)
        copies.append({"original": original, "copy": ref(target)})
(out / "RETAINED-OUTPUT.json").write_text(json.dumps({"schema": "merlin.buffer.F.retained-output.v1", "source_cohort": "historical Q5/F2 186", "copies": copies, "binaries_copied": False}, indent=2) + "\n")
members = []
allowed = {".py", ".lean", ".mlir", ".json", ".md", ".patch", ".txt", ".log"}
for path in sorted(f.rglob("*")):
    if not path.is_file() or path.name in {"ACTIVE.md", "SEAL-v1.json"}:
        continue
    assert not path.is_symlink()
    if path.suffix not in allowed and path.name not in {"stdout", "stderr"}:
        continue
    members.append(ref(path))
seal = {"schema": "merlin.buffer.F.retention-seal.v1", "source_cohort": "historical Q5/F2 186; new191 separate", "status": "MAIN_QUALIFICATION_PASSED_BASELINE_WITNESS_PASSED_EXTRA_WITNESS_PARTIAL", "members": members, "member_count": len(members), "total_bytes": sum(item["bytes"] for item in members), "excluded_mutable": ["ACTIVE.md"], "excluded_binaries": True, "human_approved": False, "native_allocator_fidelity": False, "future191_qualification": False}
with (f / "SEAL-v1.json").open("x") as stream:
    stream.write(json.dumps(seal, indent=2) + "\n")
print(json.dumps({key: value for key, value in seal.items() if key != "members"}))
