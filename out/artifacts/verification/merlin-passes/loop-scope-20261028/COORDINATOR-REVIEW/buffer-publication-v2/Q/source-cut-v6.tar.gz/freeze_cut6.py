"""Freeze only after root applies exact reviewed191-source binding successor."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil

from merlin.common.paths import repo_root
from merlin.verify.buffer_reuse_intake import ALLOCATOR,prepare_chain,revalidate
from merlin.verify.buffer_reuse_gate import _ordered_sources


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    root=repo_root()
    here=Path(__file__).parent
    own=here.parent
    old,dest=own/'source-cut-v5',own/'source-cut-v6'
    source=root/'src/merlin/verify/buffer_reuse_intake.py'
    assert source.read_bytes()==(here/'candidate_intake.py').read_bytes(),'root exact intake not yet applied'
    buffers=tuple((old/'raw'/f'stage{i}.mlir').read_text() for i in range(4))
    candidate=prepare_chain(buffers,allocator=ALLOCATOR)
    assert candidate.query==(old/'CanonicalBufferQuery.lean').read_text()
    assert list(candidate.roots)==json.loads((old/'ROOTS.json').read_text())
    assert json.loads(candidate.query_parts_json)==json.loads((old/'QUERY_PARTS.json').read_text())
    refs=json.loads(candidate.sources_json)
    prior={row['path']:row for row in json.loads((old/'DEPENDENCIES.json').read_text())}
    added=[row for row in refs if row['path'] not in prior]
    missing=json.loads((here/'SOURCE-ADDENDUM.json').read_text())['additional_project_sources']
    assert len(refs)==191 and len(prior)==186 and len(added)==5
    assert {str(Path(row['path']).relative_to(root)):row['sha256'] for row in added}=={
        row['path']:row['sha256'] for row in missing}
    changed=[row for row in refs if row['path'] in prior and row['sha256']!=prior[row['path']]['sha256']]
    assert [row['path'] for row in changed]==[str(source)]
    revalidate(candidate)
    shutil.copytree(old,dest)
    manifest=json.loads((old/'SOURCES.json').read_text())
    delta=''
    patch=''
    for row in manifest['sources']:
        name=row['path']
        data=(root/name).read_bytes()
        previous=(old/row['snapshot']).read_text()
        if sha(data)!=row['sha256']:
            delta+=''.join(difflib.unified_diff(previous.splitlines(True),data.decode().splitlines(True),
                                              fromfile='a/'+name,tofile='b/'+name))
        (dest/row['snapshot']).write_bytes(data)
        row.update(sha256=sha(data),bytes=len(data))
        baseline=dest/'old-baselines'/name
        before=baseline.read_text() if baseline.is_file() else ''
        patch+=''.join(difflib.unified_diff(before.splitlines(True),data.decode().splitlines(True),
                                          fromfile='a/'+name if before else '/dev/null',tofile='b/'+name))
    (dest/'owned.patch').write_text(patch)
    (dest/'successor-v5-to-v6.patch').write_text(delta)
    (dest/'successor-v4-to-v5.patch').unlink()
    (dest/'PREPARATION.json').write_text(json.dumps(candidate.describe(),indent=2)+'\n')
    (dest/'DEPENDENCIES.json').write_text(json.dumps(refs,indent=2)+'\n')
    for row in refs:
        path=Path(row['path'])
        data=path.read_bytes()
        assert path.is_relative_to(root) and sha(data)==row['sha256']
        target=dest/'dependencies'/path.relative_to(root)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
    assert {module:sha(path.read_bytes()) for module,path in _ordered_sources(candidate)}=={
        row['module']:row['sha256'] for row in json.loads((old/'PROJECT_CLOSURE.json').read_text())}
    manifest.update(schema='merlin.buffer-reuse.q-source.v6',previous_cut='source-cut-v5',
                    candidate_identity=candidate.identity,bound_source_count=191,
                    changed_owned_sources=[str(source)],additional_existing_source_dependencies=added,
                    change='five existing project dependencies added to freshness binding; no query/proof/tool/domain change',
                    new_gate_native_outcome='UNOBSERVED_IN_CANONICAL_Q6',qualification='PENDING_REVIEWED_BINDING_SUCCESSOR_BOUNDARY')
    (dest/'SOURCES.json').write_text(json.dumps(manifest,indent=2)+'\n')
    for name in ('TRIAGE.md','SOURCE-ADDENDUM.json','ENVIRONMENT-BOUNDARY.md','BUILD.json','SDK-PROCESS-v1.json'):
        shutil.copyfile(here/name,dest/('binding-'+name))
    shutil.copytree(here/'sdk-v1',dest/'binding-SDK-controls')
    revalidate(candidate)
    print(json.dumps({'cut':str(dest.relative_to(root)),'source_refs':len(refs),'same_query_parts_roots':True,
                      'same111proof_sources':True,'qualification_inherited':False}))


if __name__=='__main__':
    main()
