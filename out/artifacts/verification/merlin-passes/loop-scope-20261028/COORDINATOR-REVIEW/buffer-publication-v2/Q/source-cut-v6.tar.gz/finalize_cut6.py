"""Finalize the reviewed Q6 source packet without launching any native checker."""

import hashlib
import json
from pathlib import Path
import shutil

from merlin.common.paths import repo_root
from merlin.verify.buffer_reuse_intake import ALLOCATOR, prepare_chain, revalidate


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    root = repo_root()
    here = Path(__file__).parent
    base = here.parent.parent
    cut = here.parent / "source-cut-v6"
    old = here.parent / "source-cut-v5"
    intake = root / "src/merlin/verify/buffer_reuse_intake.py"
    assert intake.read_bytes() == (here / "candidate_intake.py").read_bytes()
    assert digest(intake.read_bytes()) == "575842becf867163b3aacdadb55d4653c05b8f4aac3e0a77beede2098f060768"
    assert "97 passed" in (cut / "Q6-final-tests-v1.stdout").read_text()
    assert (cut / "Q6-final-tests-v1.stderr").read_bytes() == b""
    assert "Found 7 errors." in (cut / "Q6-final-lint-v1.stdout").read_text()
    assert "All checks passed!" in (cut / "Q6-changed-source-lint-v1.stdout").read_text()

    cases = []
    for folder in sorted((cut / "case-requests").iterdir()):
        if not folder.is_dir():
            continue
        buffers = tuple((folder / f"stage{i}.mlir").read_text() for i in range(4))
        candidate = prepare_chain(buffers, allocator=ALLOCATOR)
        assert candidate.query == (folder / "CanonicalBufferQuery.lean").read_text()
        assert list(candidate.roots) == json.loads((folder / "ROOTS.json").read_text())
        assert json.loads(candidate.query_parts_json) == json.loads((folder / "PARTS.json").read_text())
        refs = json.loads(candidate.sources_json)
        assert len(refs) == 191
        revalidate(candidate)
        cases.append({
            "case": folder.name, "candidate_identity": candidate.identity,
            "bound_source_count": len(refs), "query_sha256": digest(candidate.query.encode()),
            "roots": len(candidate.roots), "modules": len(json.loads(candidate.query_parts_json)),
            "raw4_sha256": [digest(raw.encode()) for raw in buffers],
            "same_Q5_query_parts_roots": True, "canonical_Q6_native_outcome": "UNOBSERVED",
            "authority": False, "qualification_inherited": False,
        })
    assert len(cases) == 5
    (cut / "Q6-CANDIDATES.json").write_text(json.dumps(cases, indent=2) + "\n")

    sources = json.loads((cut / "SOURCES.json").read_text())
    for row in sources["sources"]:
        assert digest((root / row["path"]).read_bytes()) == row["sha256"]
        assert (root / row["path"]).read_bytes() == (cut / row["snapshot"]).read_bytes()
    refs = json.loads((cut / "DEPENDENCIES.json").read_text())
    previous = {row["path"]: row for row in json.loads((old / "DEPENDENCIES.json").read_text())}
    additions = [row for row in refs if row["path"] not in previous]
    changed = [row for row in refs if row["path"] in previous and row["sha256"] != previous[row["path"]]["sha256"]]
    assert len(refs) == 191 and len(additions) == 5 and [row["path"] for row in changed] == [str(intake)]
    relative = []
    for row in refs:
        path = Path(row["path"])
        name = str(path.relative_to(root))
        data = path.read_bytes()
        assert digest(data) == row["sha256"]
        assert data == (cut / "dependencies" / name).read_bytes()
        relative.append({"path": name, "sha256": row["sha256"], "bytes": len(data),
                         "snapshot": "dependencies/" + name})
    (cut / "SOURCE-CLOSURE-RELATIVE.json").write_text(json.dumps(relative, indent=2) + "\n")

    evidence_dir = cut / "evidence-lineage"
    evidence_dir.mkdir(exist_ok=True)
    evidence = []
    selected = {
        "ROOT-BINDING-REPAIR.json": base.parent / "COORDINATOR-REVIEW/BUFFER-BINDING-REPAIR.json",
        "F-SAFE-BOUNDARY.json": base / "F/delivery-v2/SAFE-BOUNDARY.json",
        "F2-MAIN-186.json": base / "F/qualification-v2/RESULT.json",
        "F2-REPLAY-186.json": base / "F/qualification-v2/fresh-process-replay/RESULT.json",
        "W-191-CHECK-REPLAY.json": base / "CONTEXT/W/binding-successor-v1/RESULT.json",
        "W-191-CHECK.json": base / "CONTEXT/W/binding-successor-v1/check-v1/RESULT.json",
        "W-191-REPLAY.json": base / "CONTEXT/W/binding-successor-v1/replay-v1/RESULT.json",
        "W-CONSTRUCTIVE-CORPUS-JOIN.json": here.parent / "paper-evidence-v1/WITNESS-JOIN.json",
        "F-CORPUS-WITNESS-PARTIAL.json": base / "F/corpus-witness-binding-v1/FINAL.json",
        "F-CORPUS-WITNESS-FIRST-PROCESS.json": base / "F/corpus-witness-binding-v1/three_disjoint_epochs/build-CorpusWitnessStates/PROCESS.json",
        "F-CORPUS-WITNESS-FIRST-INTENT.json": base / "F/corpus-witness-binding-v1/three_disjoint_epochs/build-CorpusWitnessStates/INTENT.json",
        "F-CORPUS-WITNESS-FIRST-stdout": base / "F/corpus-witness-binding-v1/three_disjoint_epochs/build-CorpusWitnessStates/stdout",
        "F-CORPUS-WITNESS-FIRST-stderr": base / "F/corpus-witness-binding-v1/three_disjoint_epochs/build-CorpusWitnessStates/stderr",
        "F-CORPUS-WITNESS-FIRST-TRACEBACK.txt": base / "F/corpus-witness-binding-v1/runner.log",
    }
    for name, path in selected.items():
        data = path.read_bytes()
        (evidence_dir / name).write_bytes(data)
        evidence.append({"original": str(path.relative_to(root)), "snapshot": "evidence-lineage/" + name,
                         "sha256": digest(data), "bytes": len(data)})
    w = json.loads((evidence_dir / "W-191-CHECK-REPLAY.json").read_text())
    assert w["candidate_sha256"] == digest(intake.read_bytes())
    assert len(w["cases"]) == 2 and all(row["source_files"] == 191 for row in w["cases"])
    assert not w["all_five_native_rerun"] and not w["new_host_qualification"]
    f = json.loads((evidence_dir / "F2-MAIN-186.json").read_text())
    assert f["actual_gate_positives"] == 5 and not f["failed_or_unavailable"]
    (cut / "EVIDENCE-LINEAGE.json").write_text(json.dumps({
        "schema": "merlin.buffer-reuse.q6-evidence-lineage.v1", "records": evidence,
        "historical_F2_binding": 186, "F2_positives": 5, "F2_valid_mutations": 24,
        "successor_binding": 191, "W_successor_native_cases": ["retained_two_epochs"],
        "W_successor_separate_process_replay": True, "all5_successor_preparation_identity": True,
        "full191_five_case_independent_qualification": False, "qualification_transferred": False,
        "human_approval": False, "native_allocator_fidelity": False,
    }, indent=2) + "\n")

    sources.update(
        qualification="SOURCE_DELIVERY_SEALED_SEPARATE_EVIDENCE_SCOPES",
        new_gate_native_outcome="UNOBSERVED_IN_CANONICAL_Q6",
        historical_F2_evidence="evidence-lineage/F2-MAIN-186.json",
        isolated_W_191_evidence="evidence-lineage/W-191-CHECK-REPLAY.json",
        independent_full191_five_case_qualification=False,
        review_approved=False, production_enforcement=False,
    )
    (cut / "SOURCES.json").write_text(json.dumps(sources, indent=2) + "\n")
    (cut / "REPAIR-STATUS.json").write_text(json.dumps({
        "Q6_change": "five existing Python project sources added to freshness binding",
        "intake_sha256": digest(intake.read_bytes()), "bound_sources": 191,
        "same_Q5_all5_queries_parts_roots": True, "same111_project_proof_sources": True,
        "same_actual_raw4": True, "proof_process_or_semantic_limits_changed": False,
        "old186_capsules_preserved": True, "no_qualification_transfer": True,
        "canonical_Q6_native_outcome": "UNOBSERVED", "Q_native_executed": False,
        "root_binding_repair": "evidence-lineage/ROOT-BINDING-REPAIR.json",
    }, indent=2) + "\n")
    (cut / "SDK-TEST-STATUS.json").write_text(json.dumps({
        "97_selected_tests": {"returncode": 0, "stdout": "Q6-final-tests-v1.stdout", "stderr": "Q6-final-tests-v1.stderr"},
        "all10_source_lint": {"returncode": 1, "stdout": "Q6-final-lint-v1.stdout", "stderr": "Q6-final-lint-v1.stderr",
                              "finding": "seven preexisting E501 long lines in unchanged entry emitters; preserved without source edits"},
        "changed_intake_lint": {"returncode": 0, "stdout": "Q6-changed-source-lint-v1.stdout", "stderr": "Q6-changed-source-lint-v1.stderr"},
        "candidate_source_copy_controls": "binding-SDK-controls/RESULT.json", "native_launched": False,
        "own_live_jobs": 0,
    }, indent=2) + "\n")

    docs = {
        "README.md": """# Buffer Q6 source-binding delivery

This cut binds191 project/host sources, snapshots the111-project Lean closure,
and retains the exact original/normalized/reused/segmented buffers. The only Q5
source change adds five already-imported Kernel IR Python files to freshness
checks. All five canonical queries, twelve-part source rosters, root/type names,
actual buffer bytes, proof terms, premises and limits remain unchanged.

The source packet is sealed independently of native qualification. F2 completed
five real positives,24 valid mutations (one native refusal,23 host refusals),
and a fresh-process replay on the OLD186 binding. W separately checked and
replayed the exact191 successor baseline in a fresh source-only copy, auditing
250 roots and2338 transitive std3 theorems, with53 observed local Python imports
bound and no original-source fallback. This is ONE native successor example,
not a repeat of all five on191 or a new-host qualification. EVIDENCE-LINEAGE.json
keeps these scopes separate; no old receipt is relabeled.

Q ran97 SDK-free tests on the applied source and retained five added-file
staleness refusals in an isolated191-source copy. Changed intake lint passes.
The wider ten-file lint scan reports seven existing long-line issues in unchanged
emitters; its first output is retained. Q launched no native jobs and has none live.

Relation: equal possible successful public observations for every supported
defined entry, under typed/caller/domain and total/private/unobservable allocator
premises. No full error/world relation, finite allocator equivalence, native
allocator/numerical/hardware fidelity, production registration or human approval.
The finite-capacity8-to16-byte counterexample and all old failures remain.

W separately supplied constructive initialized/nonzero model witnesses for all
five actual raw4 cases. F independently checked the baseline witness; its later
four-case witness campaign stopped at the first120s CorpusWitnessStates timeout
(0/4 completed). That unavailable first result does not change the main F2 run
and is not promoted to independent witness qualification.

See REVIEW.md and PAPER-ROW.md for exact premises/claims; RUN.md for reconstruction.
SOURCE-CLOSURE-RELATIVE.json and dependencies/ contain portable source snapshots.
Existing absolute Linux paths in reports are historical bindings, not authority
or qualification on another checkout/host. Prepare and check freshly there.
Root owns final review, merge and release; NEXT-CONFIGURATION remains HELD.
""",
        "REVIEW.md": """# Exact source/field/observation map and review limits

| Complete boundary | Binding and proof obligation |
|---|---|
| Original full module | Independently decoded Module, complete source frame, source_term_exact/source_frame_exact; no saved source term substitutes. |
| Normalized join | One exact normalized buffer joins source shape output to reuse input; finite metadata/binding goals remain in the query. |
| Reused intermediate | Actual allocations/accesses/initializers/control, object-slot maps and lifetimes are checked. Runtime allocator conformance is separate. |
| Segmented full final | Independently decoded actualFinal, materialization/expansion checks and surrounding frames; no selected-return-only equality. |
| Every defined entry | Matching complete headers/types/visibility, kernel and unchanged call-closed entries. External declarations and wrappers reaching the changed kernel are refused by this basic route. |
| Shared interpretation | Generic Value/User, scalar/literal/external relations and allocator meaning remain explicit. Unit values occur only in concrete input witnesses. |
| Public observations | Possible successful returned Runtime values, caller heap outside private objects and user state. No error/divergence/failure-world relation. |
| Runtime domain | Typed EntryDomain, external descriptors outside private object IDs and kernel CallersValid. Static typing/inhabited input alone is not successful execution. |
| Allocator | Total, private and unobservable; finite capacity, address identity/escape, asynchronous completion and actual allocator delivery are not proved. |

Root GraphMemoryAfterEntries.every_definition extends selected-kernel root
GraphMemoryAfterWhole.complete_actual_chain. The retained baseline has250 printed
roots; three_disjoint_epochs has255. All twelve generated modules are audited,
including expanded_to_actual, rather than only the last module or a root subset.
No frozen evaluator, numerical law, runtime or proof/process limit changes.

Q6 repairs a real Python source-binding gap: literal helpers import merlin.sched
through lean_graph_loops_unroll/lean_graph_loops. The five added source files are
listed in binding-SOURCE-ADDENDUM.json, each copied and fingerprinted. All53
observed local imports are covered on the tested preparation route. This is not
a universal import closure claim: Python/xDSL and the genuine selected Lean tool,
host process transport and native/import delivery remain explicit trust boundaries.

Every candidate binds complete canonical query bytes, twelve reconstructed source
parts/import maps, actual raw4 and complete root/entry rosters. Sources are checked
before/after compilation and delivery; new private objects are fingerprinted before
audits and afterward, with exact tree membership and raw process records. Only a
real checked/audited/revalidated process can issue a same-object private live token.
Saved JSON, copied tokens, callbacks and source snapshots grant no authority.

EVIDENCE-LINEAGE.json distinguishes F2's full186-source five-case campaign from
W's new191-source one-case fresh check/replay. Q6's five freshly prepared candidates
retain exact old query/parts/roots; their native outcomes are UNOBSERVED here.
97 SDK-free tests and five added-source staleness controls are host evidence, not
Lean proofs. Seven existing lint E501 diagnostics are retained without edits.

Constructive corpus model witnesses are separately W-checked, with explicit Int
addition/literal semantics and nonzero initialized inputs. F's independent baseline
witness succeeds; its subsequent four-case witness campaign times out on the first
module,0/4 completed. Keep that timeout and old SIGSEGV/WholeEpoch timeout/Shape.valid
failures unavailable; do not infer full native or hardware fidelity from witnesses.

Independent projection/premise approval, actual allocator conformance and any
production enforcement remain outstanding. Existing loop-v6 source selections
are untouched. Context candidate work is preserved separately and not promoted.
""",
        "GATE-INTERFACE.md": """# Buffer Q6 direct-consumer API

No production registry activation. prepare_chain(raw4, allocator=
\"total_private_unobservable\", index_bits=64) freshly reconstructs every complete
original/normalized/reused/segmented boundary. It returns a diagnostic Candidate
with no authority. Identity binds actual raw4, full canonical query, all twelve
parts/import maps, full root/entry rosters and191 current source fingerprints.
Identity-normalized three-buffer input remains refused.

check(candidate, lean=SELECTED_LEAN, destination=NEW) builds111 exact project Lean
modules and twelve generated modules in a new private object tree, performs full
module std3/import and exact root/type audits, and revalidates source/query/object/
process/raw data. Ordinary repository tool freshness is used; no custom provider
or environment/SDK inventory is introduced. Unknown diagnostics, signals, timeouts,
resource/import/runtime failures remain unavailable, with first raw logs retained.

Only real success can create a process-local nonserializable Completion in the
private weak ledger. deliver(token, SAME_candidate, consumer) revalidates and
passes exact final bytes. replay(report, ..., destination=ANOTHER_NEW) reconstructs
from original four buffers and checks freshly; saved statuses never authorize.

Root is GraphMemoryAfterEntries.every_definition. Relation is equal possible
successful public observations under typed/caller/domain, shared interpretation
and total/private/unobservable allocator premises. No full error/world, finite
allocation, native allocator/numerical/hardware or human approval claim.

Evidence: old186 F2 five-case qualification and separate191 W baseline fresh check
and replay, with exact same query/root/proof bytes. See EVIDENCE-LINEAGE.json.
The canonical Q6 five-case campaign has not been rerun; it inherits no qualification.
Python/xDSL projection, actual selected tool/process/import delivery remain trusted.
""",
        "PAPER-ROW.md": """# Proposed bounded buffer paper row

For accepted complete modules in the static rectangular private-buffer submode,
the checker establishes equality of possible successful public observations for
every supported defined entry across actual shape normalization, storage reuse
and ordered segmentation, conditional on typed/caller/entry domain, shared
primitive/literal/external relations and a total/private/unobservable allocator.

Complete-entry root: GraphMemoryAfterEntries.every_definition. Actual-kernel root:
GraphMemoryAfterWhole.complete_actual_chain. Actual source/middle/final buffers,
complete frames/SSA/entries,111 proof-source closure, twelve generated modules and
250 baseline roots (255 for three epochs) are retained and exactly bound.

Enumerated evidence: F2 five real old186-binding positives,24 valid mutations
(one native refusal,23 host refusals) and fresh replay. The source-binding repair
adds five existing Python imports; separate W191 baseline check/replay preserves
all query/root/proof bytes and audits2338 transitive std3 theorems. All five191
preparations are SDK-checked for exact query/parts/roots; full five-case191 native
qualification has not occurred. No historical qualification transfer is asserted.

Constructive initialized/nonzero model witnesses exist for all five actual raw4
cases under explicit Int addition/literal meaning. F independently checked the
baseline; its four-case witness campaign stopped at the first120s compile timeout,
0/4 completed. These distinct results remain separate from main checker qualification.

Outstanding: independent model/projection/premise approval, actual native allocator
and primitive fidelity, any production enforcement and portability/new-host checks.
No full error/world, finite-memory, hardware, numerical, universal-pass or all-graph
claim. The finite allocator8-to16-byte counterexample remains binding evidence.
""",
        "RUN.md": """# Reconstruct and check freshly

This is a command plan, not permission for Q to launch native work. Root selects
any fresh native review/qualification boundary; F owns that execution. The normal
repository-selected genuine Lean executable and ordinary freshness checks are
required. Old Linux reports/source snapshots do not authorize another process.

Using the current repository source, read four exact strings from raw/stage0.mlir
through stage3.mlir in THIS source-cut-v6 and call prepare_chain(raw4,
allocator=ALLOCATOR). Compare candidate.describe(), source refs, canonical query,
all roots and all twelve parts with PREPARATION.json, DEPENDENCIES.json,
CanonicalBufferQuery.lean, ROOTS.json and QUERY_PARTS.json. Preparation gives no
authority. Q6-CANDIDATES.json records current identities for all five cases.

Then independently call check(candidate, lean=selected_lean, destination=NEW).
Only status checked plus a live completion permits deliver(completion,
SAME_candidate, consumer), whose received final bytes must equal stage3.mlir.
Call replay(completion.report, lean=selected_lean, destination=ANOTHER_NEW) in a
separate fresh Python process, retaining first raw output/status and all artifacts.
Never deserialize or reuse a copied token as authority.

Exact build plan:111 topologically ordered project sources in PROJECT_CLOSURE.json,
then WholeShape, WholeReuse, WholeMemory, EpochSyntax, EpochCommands, EpochPlan,
EpochKernel, WholeEpoch, WholeMaterialization, WholeExpansion, WholeFinal,
RawChainEntries into one new private object tree. The full canonical query is
retained for exact factoring, not compiled as the old failing monolith.
GraphStateAudit runs over ALL twelve names for forbidden constructs/std3/imports
and separately over the complete exact root/type roster (250 baseline or255 for
three epochs). No selected-subset audit. No proof/process limit increase.

Default timeout120s per process. First signal/timeout/resource/import/runtime or
unknown diagnostic stops that context as unavailable; preserve raw output and
never retry unchanged or refresh expected pins to promote. Include source/objects/
query/import/root/report mutations, fresh replay and exact-byte delivery controls.

SDK-free commands already retained:97 tests in three canonical buffer unit files
plus Q/epoch-successor/test_classifier_candidate.py and
Q/shape-successor/test_shape_candidate.py. Changed intake lint passes. A wider
ten-file lint scan retains seven existing E501 issues in unchanged emitters.
No source changes were made to silence those diagnostics.

SOURCE-CLOSURE-RELATIVE.json maps191 source snapshots for handoff; installed
third-party Python/xDSL/tool/runtime fidelity is not proved by that list. This is
not a portability fix, SDK inventory or permission to revive old held profiles.
""",
    }
    for name, content in docs.items():
        (cut / name).write_text(content)

    shutil.copyfile(here / "freeze_cut6.py", cut / "freeze_cut6.py")
    shutil.copyfile(__file__, cut / "finalize_cut6.py")
    assert (cut / "CanonicalBufferQuery.lean").read_bytes() == (old / "CanonicalBufferQuery.lean").read_bytes()
    assert (cut / "PROJECT_CLOSURE.json").read_bytes() == (old / "PROJECT_CLOSURE.json").read_bytes()
    for row in refs:
        assert digest(Path(row["path"]).read_bytes()) == row["sha256"]
    files = []
    for path in sorted(cut.rglob("*")):
        assert not path.is_symlink()
        if path.is_file() and path != cut / "MANIFEST.json":
            data = path.read_bytes()
            files.append({"path": str(path.relative_to(cut)), "sha256": digest(data), "bytes": len(data)})
    manifest = {
        "schema": "merlin.buffer-reuse.q-delivery.v6", "files": files,
        "bound_source_count": 191, "proof_source_count": 111, "generated_modules": 12,
        "historical_F2_186_scope": "five positives/24 valid mutants/fresh replay",
        "isolated_W_191_scope": "one baseline freshcheck/separate-process replay",
        "full191_five_case_independent_qualification": False,
        "qualification_transferred": False, "human_approved": False, "production_enforcement": False,
    }
    (cut / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    for row in files:
        assert digest((cut / row["path"]).read_bytes()) == row["sha256"]
    print(json.dumps({"cut": str(cut.relative_to(root)), "manifest_files": len(files),
                      "sources": 191, "same_all5_queries_parts_roots": True,
                      "SDK_tests": 97, "Q_native_jobs": 0, "qualification_transferred": False}))


if __name__ == "__main__":
    main()
