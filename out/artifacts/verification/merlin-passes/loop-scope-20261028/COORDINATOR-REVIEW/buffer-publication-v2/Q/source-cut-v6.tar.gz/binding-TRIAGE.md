# Selected source binding versus project runtime import closure

Q5 selects186 project proof/host sources. It is a conservative set of graph
helpers, not the complete transitive Python import closure. W's clean source
copy reproduced a real missing import, retained in CONTEXT/W/clean-source-v1/
prepare-v1. No original checkout fallback was allowed. Adding the five exact
project files in MISSING-SOURCES-v1.json permits fresh preparation from the copy,
producing identical Q5 query/12 parts/250 roots. W owns the independent clean
copy/native check; Q does not duplicate it.

The missing files are sched/__init__.py and sched/ir/{__init__,expr,kernel,parse}.py.
They load through shape_model → lean_graph_loops_unroll → lean_graph_loops. The
buffer route calls literal helpers, not the Kernel IR materialization/parser
entry points, but Python still executes their imports/class definitions. Their
package/root identity is therefore part of the project host trusted boundary.
expr imports dataclasses/typing; kernel imports expr plus standard library;
parse imports expr/kernel. No further project import is present in these five.

Comparison with W's53 recorded actual Merlin imports shows EXACTLY these five
outside Q5's selected set; every resolved module came from the copied tree and
no fallback occurred. This is a bounded observed import closure, not a universal
statement about arbitrary optional helpers or future source versions. Standard
Python, xDSL/other third-party packages, the genuine selected Lean kernel and
native tool/runtime delivery remain explicit trusted boundaries.

Packaging the five files fixes the clean-copy import gap but does not repair
Candidate identity/live revalidation: Q5 still binds186. A genuine fingerprint
gap remains, even if those imports only provide unused Kernel classes on this
path. Do not label the old source set a full transitive closure or silently
extend F2's qualification. The mathematical acceptance theorem is unaffected;
end-to-end byte-binding coverage is narrower than previously described.

The concrete minimal candidate adds only those five paths to prepare's source
set. Existing source hashing, fresh reconstruction and before/after/delivery
revalidation then cover them automatically. It changes Candidate identities
and source-only receipt metadata (191), while leaving every raw buffer, query,
root/type, proof source, numerical/allocator premise and native command unchanged.
SDK staleness controls must show mutation of each added dependency refuses
before native execution. F/root choose the reviewed qualification boundary after
F2 is terminal. No canonical edit, pin refresh, new provider or SDK investigation.
