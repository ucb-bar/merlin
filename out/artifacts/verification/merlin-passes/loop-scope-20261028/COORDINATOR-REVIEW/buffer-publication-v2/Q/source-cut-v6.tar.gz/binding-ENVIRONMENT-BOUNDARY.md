# Environment and source boundary

This addendum supplies exactly five existing project source files required by
normal imports. It does not select a new SDK, toolchain, environment provider or
interpreter. SDK-free tests used the existing repository Python with its xDSL
installation; a restricted project import finder rejected original-checkout
fallback. All53 observed Merlin imports were in the191-file source tree.

The five files use only one another and standard-library dependencies. Python
and third-party library implementations, genuine selected Lean/compiler runtime,
and actual host/native delivery remain trusted. W's clean-source real check and
separate-process replay use the same selected host/environment, not a new laptop
qualification. Old absolute receipt paths do not become portable qualifications.

Q5/F2 still binds186. Extra packaging alone does not expand its live freshness
guarantee. The explicit candidate adds these five refs to the existing source
fingerprint/revalidation path. Root must select the new source/binding version;
no old receipt or failure is refreshed/promoted by this addendum.
