"""SDK-free raw-diagnostic controls only; no synthetic proof/live completion."""
import importlib.util
from pathlib import Path
import subprocess
import sys

import pytest

from merlin.common.paths import repo_root


@pytest.fixture(scope='module')
def gate():
    # Unique ephemeral module; the canonical source selection is unchanged.
    path = repo_root() / 'src/merlin/verify/buffer_reuse_gate.py'
    spec = importlib.util.spec_from_file_location('merlin.verify._q_buffer_epoch_gate', path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def result(output, code=1, stderr=''):
    return subprocess.CompletedProcess(['/synthetic-not-executed'], code, output, stderr)


@pytest.mark.parametrize('name', [
    'final_wrong_seed', 'final_wrong_inner_cutoff', 'final_missing_observer', 'final_wrong_observer_operand',
    'final_observer_reordered', 'final_alignment1', 'final_observer_arguments_order',
    'final_early_free', 'final_missing_free', 'final_wrong_scalar_return',
    'final_wrong_load_address', 'final_wrong_store_address', 'final_wrong_tile_stride', 'final_entry_renamed',
])
def test_retained_closed_failures_are_prospective_not_established(gate, name):
    base = repo_root() / 'out/artifacts/verification/merlin-passes/loop-scope-20261028/NEXT-BUFFER/F/component-v1'
    path = base / name / 'lean/stdout.txt'
    if not path.is_file():
        pytest.skip('explicit retained first output absent')
    with pytest.raises(gate.NotEstablished):
        gate.require_query_success(result(path.read_text()))
    assert not gate._LIVE  # classification cannot promote a historical run


@pytest.mark.parametrize('name', ['source_wrong_scalar_return', 'source_wrong_seed'])
def test_old_source_slice_resource_errors_stay_unavailable(gate, name):
    base = repo_root() / 'out/artifacts/verification/merlin-passes/loop-scope-20261028/NEXT-BUFFER/F/component-v1'
    path = base / name / 'lean/stdout.txt'
    if not path.is_file():
        pytest.skip('explicit retained first output absent')
    assert 'maximum recursion depth' in path.read_text()
    with pytest.raises(gate.Unavailable):
        gate.require_query_success(result(path.read_text()))
    assert not gate._LIVE


@pytest.mark.parametrize('head', [
    'Tactic `rfl` failed: The left-hand side', 'Type mismatch', 'type mismatch',
    'Application type mismatch', 'unsolved goals',
])
def test_known_closed_diagnostics(gate, head):
    with pytest.raises(gate.NotEstablished):
        gate.require_query_success(result('Candidate.lean:2:3: error: ' + head + '\nSYNTHETIC TEST DATA\n'))


@pytest.mark.parametrize('diagnostic', [
    'Tactic `decide` failed', 'unknown identifier bad', 'object file missing',
    'internal error', 'maximum recursion depth has been reached',
    'maximum number of heartbeats (4000000) has been reached', 'no executable code',
    'completely unknown compiler condition',
])
def test_unknown_and_infrastructure_never_become_refusals(gate, diagnostic):
    with pytest.raises(gate.Unavailable):
        gate.require_query_success(result('Candidate.lean:2:3: error: ' + diagnostic + '\n'))


@pytest.mark.parametrize('extra', [
    'Candidate.lean:9:1: error: unknown namespace Missing\n',
    'Candidate.lean:9:1: error: completely unknown compiler condition\n',
    'error: additional unlocated failure\n',
    'Candidate.lean:9:1: error(lean.unknownTactic): Unknown tactic\n',
])
def test_mixed_known_and_unknown(gate, extra):
    known = 'Candidate.lean:2:3: error: Tactic `decide` proved that the proposition\n  False\nis false\n'
    with pytest.raises(gate.Unavailable):
        gate.require_query_success(result(known + extra))


def test_signal_and_stderr_never_become_refusals(gate):
    with pytest.raises(gate.Unavailable):
        gate.require_query_success(result('', -11))
    with pytest.raises(gate.Unavailable):
        gate.require_query_success(result('Candidate.lean:2:3: error: unsolved goals\n', stderr='unknown native stderr'))
    assert not gate._LIVE


def test_nonstandard_positive_exit_is_unavailable_even_with_known_error(gate):
    with pytest.raises(gate.Unavailable, match='unexpected error exit'):
        gate.require_query_success(result('Candidate.lean:2:3: error: unsolved goals\n', code=2))
    assert not gate._LIVE
