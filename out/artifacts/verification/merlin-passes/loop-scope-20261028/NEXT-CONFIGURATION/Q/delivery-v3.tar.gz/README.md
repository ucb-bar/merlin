# Final Q configuration integration delivery

Source cut Q/source-cut-v3 is immutable:221files,35SDK controls,7owned Python/tests,
7canonical project Lean modules and13 unchanged actual closed queries/17roots.
F3 independently passed13supported pairs,1explicit dynamic unsupported boundary,
21compiler-valid native obligation refusals plus1reserved-metadata host refusal,
15forged requests,11live artifact controls and empty-ledger fresh-process replay.
EXACT-Q3-F3-JOIN.json independently joins every actual F report to frozen Q3
candidate/query/root/source bytes; each audited247transitive std3 theorems.
These are observed kernel/checker results, not human or hardware approval.

The full source patch/snapshots/dependencies are in ../source-cut-v3. The actual
worked example and field/premise map are in ../paper-evidence-v2. Root alone
reviews/publishes/integrates. No production registration or adjacent loop/buffer
composition is claimed. Entry outcome/error/terminal-state equality is conditional
on the exact local instruction interpretation/effects/nonaliasing state map.
No source-success, initialized-config or whole-run-equality premise replaces proof.

Old cut1 first import-root unavailability and cut2 reserved-marker projection gap
remain retained/unqualified. Raw counterexample and lexer admission repair remain
available. No historical qualification transfer or SDK/toolchain repair occurred.
Source/domain changes after this cut require fresh checked evidence. Absolute Linux
bindings are historical and do not qualify a laptop/new host. Q native/livejobs0.
