# Actual configuration-write worked example and claim boundary

The selected4499 production IR adapter changes the complete retained function
from16 operations to14, removing two repeated pair writes while retaining all ten
constants, both ordered work observers, its argument, signature and return.
The copied source.mlir and final.mlir are exact complete actual buffers;
BINDINGS.json binds them to source-cut-v3, its query, root roster and projection.

After those unchanged constants, the changed sequence is:

```text
source: pair(field0=3, field1=5); work; pair(3,5); work; pair(3,5); return
final:  pair(field0=3, field1=5); work;            work;            return
```

The first pair remains because entry knowledge is empty. The later pairs may
disappear only if their complete declared operation means a total exact overwrite
and intervening work preserves those configuration cells. Unknown/unordered effects
forget knowledge; clobbers invalidate cells. A pulse, token, memory effect, reset
or hidden observation cannot be declared away by a matching instruction name.

| Actual IR field | Independently projected binding |
|---|---|
| Full module/declarations/order | Program.frame; canonical complete module/function properties, attributes, locations and declaration roster |
| Every definition/signature | Entries.Entry name/header, argument types, complete paired entry roster |
| SSA operands/results | Lexical argument/result slots; every typed operation token binds operands, results, types, attrs/properties/location |
| Instruction encoding | Original selected ISA widths/fields/fixed bits, exact constant operand interpretation and unique bit roundtrip |
| Configuration effects | Explicit source-owned reads/writes/clobbers/order/purity, actual field indices/values and one nonaliasing registry |
| Output omissions | Actual target commands match original occurrence IDs; the Lean checker determines whole-call omission legality |
| Whole outcome | Missing-entry result or complete modeled success/error and terminal state, under one admitted local interpretation |

Proposed root: ActualConfigurationElision.complete_entries, derived from the
reviewed canonical Configuration.Entries.check_sound and existing Elision.check_sound.
The generated query also checks the whole frame and arbitrary complete-outcome
observers. There is no source-success, initially installed configuration or
whole-program-equality premise. It is an operational atomic-instruction model,
with actual instruction/SSA/observer-to-state agreement still an explicit premise.

W compiled this exact12,277-byte query9cfb2201 and audited all17 requested roots
within its90-root/247-theorem std3 development audit. F's first gate campaign was
unavailable before any proof because project compilation used the wrong working
directory. That first evidence remains unchanged. The narrow invocation successor
is source-cut-v3; its13 supported cases and21 valid negatives, real live delivery,
artifact controls and separate-process replay await F's independent result.
28 SDK-free controls are host evidence, not proof or qualification.

The selected synthetic fixture declaration's reviewed/caller-qualification strings
are parser inputs, not human approval or hardware fidelity. The generic theorem
preserves modeled errors/state; it does not establish actual hardware, instruction
delivery, numerical fidelity, local runtime typing/definedness for arbitrary models,
or composition with previous loop/buffer passes. No production registration.

Current correction: cut2 selected tests passed but remain UNQUALIFIED because raw reserved op_name__ keys could be lost by xDSL. The valid counterpair is retained. Root reviewed/intook exact5a07268a source fix: reject bare/quoted/escaped/unit reserved keys before parsing; all13query bytes/models/17roots stay unchanged.35SDK controls pass; Fqualification-v3 is RUNNING and no final qualification claim is made here.


Final observed successor result: F3 independently PASSED13supported pairs,
21native false-obligation refusals and1reserved-metadata host refusal, plus
15forged requests/11live artifact controls/empty-ledger separate-process replay.
checker-output retains the actual multifield compiler process and full17root/type
and247theorem std3 output, bound to its real report. Q/delivery-v3 independently
joins all13actual F reports to frozen candidate/query/root/source identities.
The preceding PENDING text describes earlier observations, not the final state.
Human interpretation/ISA/hardware review, local runtime fidelity and any production
or adjacent-pass integration remain separate. Cut2 remains unqualified.
