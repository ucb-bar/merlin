# Configuration-write elimination: paper claim and evidence

Current status: **Q3/F3 engineering qualification complete**.13supported changed
pairs,21actual Lean refusals+1reserved metadata host refusal, all live controls and
fresh-process replay passed. F independently rebuilt the actual-query witness:
110types/276project theorems/std3/0violations. Exact source closure, tool versions,
retained checker output and seal are linked from ../FINAL_STATUS.json and README.
Q1 stays unavailable and Q2 stays UNQUALIFIED; neither is promoted.

## Proposed exact claim

For accepted complete modules in the declared constant-integer, straight-line
configuration domain, every supported defined entry and missing-entry lookup has
the same modeled complete outcome before and after elimination: success state,
or the same first error and terminal state. Any observer of that outcome agrees.
Invocation starts with unknown configuration, not an assumed installed value.

The actual root is `ActualConfigurationElision.complete_entries`, using new
`Merlin.GraphState.Configuration.Entries.check_sound` and unchanged
`Merlin.GraphState.Elision.check_sound`. The latter proves known-state tracking,
unknown/order invalidation, partial clobber, whole-write omission and sequential
composition. `Configuration.put_idempotent` is an existing local anchor; the
older configuration-hoist theorem alone does not establish this pass.

The checker compares the complete module frame/entry roster and independently
reconstructed source/target commands. A deletion must be a result-free ordered
pure setter with every written field already equal. Pure setters implement an
EXACT TOTAL overwrite of the declared configuration cells, preserving every other
state cell and producing no pulse, enqueue, token, memory, synchronization,
observer or failure effect. Retained commands share one arbitrary deterministic
partial interpretation; declared ordered writes/frame/reads must hold on successful
steps. Unknown/unordered commands remain and invalidate knowledge. No supplied
whole-run equality or source-success premise replaces these local contracts.

`State Value` must represent all relevant SSA, caller, return, memory and observer
state; configuration fields must map injectively to distinct cells. Actual ISA/
bit/effect decoding and Python/xDSL-to-model mapping are trusted review boundaries.
This is a conditional graph-transformation theorem, not hardware or numerical
correctness. Synthetic software status/review and qualification strings are test
input requirements, never human approval. Production-wide enforcement and adjacent
pass/model composition are separate obligations.

## Actual example and modeled execution

The worked source is `corpus-v1/positives/multifield/stage0.mlir`; its actual final
is stage1.mlir. Both are complete modules with the full signature, ten retained
constants, three pair setters, two work observers and return. The pinned actual
`ConfigurationIRSelection.apply` calls `eliminate_redundant_configuration` and
removes the two redundant pair setters, retaining the first write and both work
calls. The exact reference is 4499eebb959c0f92cefd92cc6d80646ba66474ed.
All fourteen captures were also reproduced byte-for-byte through the original
source-byte-executing isolated producer, with exact facts/software/code bindings.

W's separate actual-query witness starts configuration cells at 19 and -8,
observer cell100 at5. It proves the decoded first setter establishes3/5, both
retained work steps produce observer21, and final success follows through the
checked entry theorem. A separate shared interpretation fails at the second work
with error73 and the same terminal state21 on both programs. Source success/error
is derived by explicit execution. F independently rebuilt/bound these110roots on its current Q3 checked objects,
explicitly auditing both custom modules and all7project imports.
This is a concrete abstract interpretation, not native SSA/numerical fidelity.

## Actual IR fields to Lean terms

| Compiler data | Model/checker binding |
| --- | --- |
| Complete original and final byte strings | Independent source/target parse; separate raw SHA identities; closed query rederived from both |
| Module/function metadata, properties, types, locations, declarations | Complete frame and per-entry header strings; exact ordered roster including unchanged entries |
| Every operation, SSA operand/result and block argument | Full typed operation token and original occurrence ID; target matched to retained source occurrences |
| Constant integer ISA operands/immediates | Independently reconstructed integer bit interpretation and original codec roundtrip; exact field/value assignments |
| Resource capacity, field index and field identity | Finite injective field registry; reads/writes/clobbers in existing Elision Effect terms |
| Unknown/unordered, reset, pulse, result/token and work operations | Retained exact tokens; knowledge forgotten/framed according to declared effects; local execution meaning explicit |
| Every defined entry and missing lookup | New Entries checker plus universal invoke/error/terminal-state/observer theorems |
| Delivery and replay | Private fresh proof objects, all17root types/std3/import audit and source/raw/query/object/log/report guards; nonserializable same-live authority |

The authoritative compiler parses/verifies exact buffers with unregistered custom
ISA dialects allowed. Its builtin function/arithmetic/SSA checks and the original
registered-ISA resolver/codec checks have distinct roles. Generic MLIR verification
does not establish custom instruction execution semantics. Raw `op_name__`
metadata is explicitly unsupported because it cannot be faithfully represented
by this xDSL unregistered-operation path.

## Qualification matrix and limits

Core denominator is ten actual changed producer cases: single/multifield setters,
partly changed values, partial clobber, unknown/unordered effects, retained pulses,
SSA/token results and unsigned32/64bit constants. Three additional changed cases
cover independent invocations, an unchanged helper and metadata barrier. A dynamic
selected-ISA operand is explicitly unsupported. All original twenty-one valid
mutants remain; a twenty-second compiler-valid reserved-metadata mutation is an
explicit host-admission refusal. Native expected-obligation refusals, host refusals
and unavailable execution are counted separately.

Q3/F3 completed actual gates, all root/types/std3 audits, exact final consumers,
fifteen forged-request checks, eleven genuinely checked artifact guards, copied/
saved tokens and separate Python-process fresh replay. Thirty-six SDK-free F
controls and128finite Python state/observer/failure comparisons are supplemental
tests, not universal proofs. The final145-source manifest, retained worked checker output and seal bind
completed outcomes without editing earlier capsules.

Unsupported: nested regions/CFG/loops, internal calls to defined entries, dynamic
selected fields/operands, cross-invocation assumptions, scheduling motion,
pipelines/barriers/async, hardware/word/ISA implementation fidelity, numerical
policies and general cross-pass composition. No real target policy is approved.
All absolute Linux receipts are historical host evidence; a new host needs a
fresh check/replay. Frozen semantics, specifications, locks and production pass
implementations stay unchanged. Coordinator alone publishes/integrates.
