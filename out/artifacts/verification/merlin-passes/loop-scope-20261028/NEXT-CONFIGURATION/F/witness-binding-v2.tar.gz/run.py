"""Independently bind W's actual-query success/error witness to checked F objects.

Launch only after the complete Q3/F3 campaign terminates successfully. No W
object is imported; the exact query and all project source hashes must agree.
Both custom modules are explicitly audited, together with all Merlin imports.
"""
import hashlib
import json
import os
import sys
from pathlib import Path

from merlin.common.owned_process import run_owned
from merlin.common.paths import repo_root
from merlin.verify.configuration_elision_bridge import file_ref

root = repo_root()
sys.path.insert(0, str(root / "merlin/tests/ir"))
from configuration_elision_qualification_live import source_cut
from configuration_elision_qualification_process import save

out = Path(__file__).resolve().parent
f = out.parent
w = f.parent / "W"
assert json.loads((f / "qualification-v3/RESULT.json").read_text())["status"] == "CONFIGURATION_ENGINEERING_QUALIFICATION_PASSED"
for cut in (f / "Q-INPUT-CUT-v3.json", f / "source-cut-v3/SOURCES.json"):
    source_cut(cut)
row = next(row for row in json.loads((f / "qualification-v3/POSITIVES.json").read_text()) if row["name"] == "multifield")
assert file_ref(row["report"]["path"]) == row["report"]
report = json.loads(Path(row["report"]["path"]).read_text())
selected = json.loads((w / "actual-witness-audit-v2/SOURCES.json").read_text())
sources = {item["module"]: item for item in selected}
for item in report["proof_sources"]:
    assert sources[item["module"]]["sha256"] == item["sha256"]
query = Path(sources["ConfigurationElisionQuery"]["path"])
assert hashlib.sha256(query.read_bytes()).hexdigest() == report["query"]["sha256"]
assert query.read_bytes() == Path(report["query"]["path"]).read_bytes()
original = Path(sources["ConfigurationElisionWitness"]["path"])
assert hashlib.sha256(original.read_bytes()).hexdigest() == sources["ConfigurationElisionWitness"]["sha256"]
copy = out / "ConfigurationElisionWitness.lean"
with copy.open("xb") as stream:
    stream.write(original.read_bytes())
roots = json.loads((w / "actual-witness-audit-v2/ROOTS.json").read_text())
assert len(roots) == 110 and set(report["statements"]) <= set(roots)
modules = ["ConfigurationElisionQuery", "ConfigurationElisionWitness"]
private = root / "out/build/loop-scope-20261028/qualification/configuration-witness-v2/lib"
private.mkdir(parents=True, exist_ok=False)
parent = Path(report["library_root"])
lean = report["tool"]["path"]
env = {**os.environ, "LEAN_PATH": str(private) + os.pathsep + str(parent),
       "PATH": str(Path(lean).parent) + os.pathsep + os.environ.get("PATH", "")}
for item in report["library"]:
    assert file_ref(item["path"]) == item
save(out / "BINDINGS.json", {"parent_report": row["report"], "complete_actual_before_after": row["original_before_after"],
                            "query": report["query"], "witness_original": file_ref(original), "witness_copy": file_ref(copy),
                            "all_project_sources_match": True, "roots": roots, "explicit_custom_modules": modules,
                            "no_W_objects": True})


def command(args, label):
    save(out / (label + ".intent.json"), {"command": list(map(str, args)), "cwd": str(out), "timeout": 120})
    try:
        process = run_owned(list(map(str, args)), cwd=out, env=env, capture_output=True, text=True, timeout=120, check=False)
    except Exception as error:
        for suffix in ("stdout", "stderr"):
            value = getattr(error, suffix, "") or ""
            (out / (label + "." + suffix)).write_text(value.decode(errors="replace") if isinstance(value, bytes) else value)
        save(out / (label + ".process.json"), {"returncode": None, "error": str(error), "cleanup": getattr(error, "__notes__", [])})
        raise
    (out / (label + ".stdout")).write_text(process.stdout)
    (out / (label + ".stderr")).write_text(process.stderr)
    save(out / (label + ".process.json"), {"returncode": process.returncode})
    assert process.returncode == 0, "first native witness failure retained; no unchanged retry"
    return process.stdout


command([lean, "-j1", "-o", private / "ConfigurationElisionWitness.olean", copy], "compile")
audit = json.loads(command([lean, "--run", report["auditor"]["path"], *modules], "audit").strip().splitlines()[-1])
statements = json.loads(command([lean, "--run", report["auditor"]["path"], "--statements", ",".join(roots), *modules], "types").strip().splitlines()[-1])["statements"]
assert set(statements) == set(roots) and audit["violations"] == []
assert set(audit["axioms_used"]) <= {"propext", "Classical.choice", "Quot.sound"}
for item in audit["imports"]:
    if item["module"].startswith("Merlin.") or item["module"] in modules:
        assert Path(item["olean"]).resolve().is_relative_to(parent) or Path(item["olean"]).resolve().is_relative_to(private)
for item in report["library"]:
    assert file_ref(item["path"]) == item
for cut in (f / "Q-INPUT-CUT-v3.json", f / "source-cut-v3/SOURCES.json"):
    source_cut(cut)
save(out / "RESULT.json", {"status": "ACTUAL_QUERY_NONZERO_SUCCESS_AND_FIRST_FAILURE_WITNESS_INDEPENDENTLY_CHECKED",
                          "roots": len(roots), "explicit_custom_modules": modules, "audit": audit, "statements": statements,
                          "source_success_premise": False, "whole_run_equivalence_premise": False,
                          "model": "Int fields3/5; observer cell100 initial5 ->21; second work failure73 + same terminal state",
                          "native_SSA_numeric_hardware_fidelity": False, "human_approved": False})
print(json.dumps({"status": "WITNESS_CHECKED", "roots": len(roots), "theorems": audit["theorems_audited"]}))
