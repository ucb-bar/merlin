/- Source-bound inhabitation for F's ACTUAL multifield fixture, interpreted
under its explicit abstract persistent-register/observer model. Constants have
no configuration effect; this is not numerical/native SSA qualification. -/
import ConfigurationElisionQuery

namespace ActualConfigurationWitness
open Merlin.StateEffects Merlin.GraphState
open Merlin.GraphState.Configuration
set_option autoImplicit false

def pairEffect : Elision.Effect := ⟨[],[(0,3),(1,5)],[],true,true⟩
def workEffect : Elision.Effect := ⟨[(0,3),(1,5)],[],[],true,false⟩
def scalarEffect : Elision.Effect := ⟨[],[],[],true,false⟩
def setterID (id : Nat) : Prop := id = 10 ∨ id = 12 ∨ id = 14
def workID (id : Nat) : Prop := id = 11 ∨ id = 13
instance (id : Nat) : Decidable (setterID id) := inferInstanceAs (Decidable (id = 10 ∨ id = 12 ∨ id = 14))
instance (id : Nat) : Decidable (workID id) := inferInstanceAs (Decidable (id = 11 ∨ id = 13))

def Supported (atom : Elision.Atom) : Prop :=
  (atom.effect = some scalarEffect ∧ ¬ setterID atom.id ∧ ¬ workID atom.id) ∨
  (atom.effect = some pairEffect ∧ setterID atom.id) ∨
  (atom.effect = some workEffect ∧ workID atom.id) ∨ atom.effect = none
instance (atom : Elision.Atom) : Decidable (Supported atom) :=
  inferInstanceAs (Decidable ((_ ∧ _ ∧ _) ∨ (_ ∧ _) ∨ (_ ∧ _) ∨ _))

/-- This finite statement is recomputed from the exact full original module. -/
theorem actual_bindings : ActualConfigurationElision.before.entries.all
    (fun entry => entry.code.all (fun atom => decide (Supported atom))) = true := by decide

def setCell (key : Nat) (value : Int) (state : State Int) : State Int :=
  fun index => if index = key then value else state index

def run (failAtSecondWork : Bool) (_entry : String) (id : Nat) (state : State Int) :
    Except (Nat × State Int) (State Int) :=
  if setterID id then .ok (Elision.assign (fun x => x) pairEffect.writes state)
  else if workID id then
    if state 0 = 3 ∧ state 1 = 5 then
      let observed := setCell 100 (state 100 + state 0 + state 1) state
      if failAtSecondWork && id == 13 then .error (73,observed) else .ok observed
    else .error (12,state)
  else .ok state

theorem pair_model {atom : Elision.Atom} (effect : atom.effect = some pairEffect)
    (id : setterID atom.id) (fail : Bool) (entry : String) :
    Elision.Admitted [0,1] (fun x => x) (run fail entry) atom := by
  simp only [Elision.Admitted,effect]
  constructor
  · intro _ initial final success
    have equal : final = Elision.assign (fun x => x) pairEffect.writes initial := by
      simpa only [run,id,ite_true,Except.ok.injEq] using success.symm
    subst final
    refine ⟨?_,?_,?_⟩
    · intro key value found
      simp only [Elision.assign,found]
    · intro key _ absent _
      simp only [Elision.assign,absent]
    · intro pair impossible; cases impossible
  · intro _ state; simp only [run,id,ite_true]

theorem scalar_model {atom : Elision.Atom} (effect : atom.effect = some scalarEffect)
    (notSetter : ¬setterID atom.id) (notWork : ¬workID atom.id) (fail : Bool) (entry : String) :
    Elision.Admitted [0,1] (fun x => x) (run fail entry) atom := by
  simp only [Elision.Admitted,effect]
  constructor
  · intro _ initial final success
    have equal : initial = final := by simpa only [run,notSetter,notWork,ite_false,Except.ok.injEq] using success
    subst final
    refine ⟨?_,?_,?_⟩
    · intro key value impossible; cases impossible
    · intros; rfl
    · intro pair impossible; cases impossible
  · intro impossible
    simp [Elision.pure,scalarEffect] at impossible

theorem work_model {atom : Elision.Atom} (effect : atom.effect = some workEffect)
    (id : workID atom.id) (fail : Bool) (entry : String) :
    Elision.Admitted [0,1] (fun x => x) (run fail entry) atom := by
  have notSetter : ¬setterID atom.id := by
    rcases id with left | right
    · simp [setterID,left]
    · simp [setterID,right]
  simp only [Elision.Admitted,effect]
  constructor
  · intro _ initial final success
    have installed : initial 0 = 3 ∧ initial 1 = 5 := by
      by_cases h : initial 0 = 3 ∧ initial 1 = 5
      · exact h
      · simp [run,notSetter,id,h] at success
    have equal : final = setCell 100 (initial 100 + initial 0 + initial 1) initial := by
      by_cases failure : (fail && atom.id == 13) = true
      · simp [run,notSetter,id,installed,failure] at success
      · simpa [run,notSetter,id,installed,failure] using success.symm
    subst final
    refine ⟨?_,?_,?_⟩
    · intro key value impossible; cases impossible
    · intro key member _ _
      have alternatives : key = 0 ∨ key = 1 := by simpa using member
      rcases alternatives with rfl | rfl <;> simp [setCell]
    · intro pair member
      have alternatives : pair = (0,3) ∨ pair = (1,5) := by simpa [workEffect] using member
      rcases alternatives with rfl | rfl
      · exact installed.1
      · exact installed.2
  · intro impossible
    simp [Elision.pure,workEffect] at impossible

theorem admitted (fail : Bool) : Entries.Admitted ActualConfigurationElision.fields
    (fun x => x) (run fail) ActualConfigurationElision.before := by
  intro entry member atom inside
  have allEntries := List.all_eq_true.mp actual_bindings entry member
  have supported : Supported atom := of_decide_eq_true (List.all_eq_true.mp allEntries atom inside)
  rcases supported with scalar | pair | work | unknown
  · exact scalar_model scalar.1 scalar.2.1 scalar.2.2 fail entry.name
  · exact pair_model pair.1 pair.2 fail entry.name
  · exact work_model work.1 work.2 fail entry.name
  · simp only [Elision.Admitted,unknown]

def initial : State Int := fun key => if key = 0 then 19 else if key = 1 then -8 else if key = 100 then 5 else 0

def finalState : State Int := setCell 100 21 (Elision.assign (fun x => x) pairEffect.writes initial)

theorem source_success : Entries.invoke (run false) ActualConfigurationElision.before "run" initial =
    some (.ok finalState) := by
  simp [Entries.invoke,Entries.findEntry,ActualConfigurationElision.before,Elision.execute,
    run,setterID,workID,pairEffect,Elision.assign,initial,setCell,finalState,Except.bind,List.lookup_cons]
  funext key
  by_cases zero : key = 0 <;> by_cases one : key = 1 <;> by_cases observation : key = 100 <;>
    simp [Elision.assign,initial,setCell,List.lookup_cons,zero,one,observation]
  all_goals cases (key == 0) <;> cases (key == 1) <;> rfl

theorem final_success : Entries.invoke (run false) ActualConfigurationElision.after "run" initial =
    some (.ok finalState) := by
  rw [←ActualConfigurationElision.complete_entries (fun x => x) (run false) (admitted false) "run" initial]
  exact source_success

theorem observed_nonzero : finalState 100 = 21 := rfl

theorem source_first_failure : Entries.invoke (run true) ActualConfigurationElision.before "run" initial =
    some (.error (73,finalState)) := by
  simp [Entries.invoke,Entries.findEntry,ActualConfigurationElision.before,Elision.execute,
    run,setterID,workID,pairEffect,Elision.assign,initial,setCell,finalState,Except.bind,List.lookup_cons]
  funext key
  by_cases zero : key = 0 <;> by_cases one : key = 1 <;> by_cases observation : key = 100 <;>
    simp [Elision.assign,initial,setCell,List.lookup_cons,zero,one,observation]
  all_goals cases (key == 0) <;> cases (key == 1) <;> rfl

theorem final_first_failure : Entries.invoke (run true) ActualConfigurationElision.after "run" initial =
    some (.error (73,finalState)) := by
  rw [←ActualConfigurationElision.complete_entries (fun x => x) (run true) (admitted true) "run" initial]
  exact source_first_failure

end ActualConfigurationWitness
