# Actual redundant-configuration-write example

`source.mlir` and `final.mlir` are complete pinned4499 before/after modules.
Three pair setters write fields0/1 to3/5; two work observers remain. The pass keeps
the first setter and removes the two redundant later setters. All constants,
SSA uses/types, full signature/locations, returns and observer order are bound.
Original source/final attribution and source-byte execution are recorded in F's
corpus and producer-source-reproduction-v2, not inferred from a receipt label.

`ConfigurationElisionQuery.lean` independently reconstructs both complete programs
and instantiates `ActualConfigurationElision.complete_entries`. `types.stdout`
prints all17final/support types; `audit.stdout` records247project theorems with
only standard3 axioms/0violations. The gate built7canonical modules+query into
fresh private objects and delivered byte-identical final text. `REPORT.json` and
`BINDINGS.json` retain exact source/tool/query/root/fresh-replay associations.

`negative-final.mlir` drops the first write. It is compiler-valid, but actual Lean
returned rc1/closedFalse at `ActualConfigurationElision.accepted`; negative-query
source/command/stdout are retained. No Python shape guard substitutes for this
negative's real kernel check. The new raw reserved-metadata case is separately
compiler-valid and explicitly host-refused; see ../reserved-metadata-v1.

F's independent actual-query witness110roots/276std3 derives success from initial
fields19/-8 and observer5, reaching3/5 and observer21. Its second-work-failure
interpretation yields error73 plus the same terminal state on both programs.
That is a concrete abstract model, not native SSA/numerical execution.

The general theorem preserves complete modeled entry results/errors/terminal
states for arbitrary initial configuration and admitted common local meanings.
Pure setters must be exact total overwrites with no other effect. Python/xDSL
projection and ISA/field/implementation agreement remain explicit trusted review
premises. Hardware/policy approval, production enforcement and adjacent-pass
composition are not established. Historical Linux paths require fresh replay on
a laptop or other host. No old failed profile is promoted.
