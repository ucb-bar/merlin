"""The ON-CHIP ADDRESS SPACE a target's compiler must schedule into, DERIVED from that target's RTL facts.

A capacity in BYTES is not what a backend addresses. It addresses ROWS: an operand store is an SRAM
whose row is exactly as wide as the edge of the compute array it feeds, and every instruction that moves
a tile names a row index. Two measured failures, both of which read as "the oracle returned nothing":

  * a graded backend tiled its ITERATION space correctly but addressed all ``kt*nt`` weight tiles as
    simultaneously resident (``b_spad = weight_base + (kk*nt + nn)*DIM``). At 512x512 that is
    32*32*16 = 16384 scratchpad rows against a 16384-row scratchpad, and the simulator aborted with
    ``vector::_M_range_check: __n (which is 16384) >= this->size() (which is 16384)``;
  * four whole-model layers -- (345,32)@(32,256) and (96,64)@(64,512) -- whose operands sat well inside
    a 262144-byte scratchpad, so nothing tiled them, and whose OUTPUT overran the accumulator's 1024
    rows: ``__n (which is 1024) >= this->size() (which is 1024)``.

Both numbers are row counts, and neither is in the facts artifact: it declares ``bytes`` and ``depth``
per memory and stops. The row width, the total row count, the bank count, and whether the accumulator is
a SEPARATE address space (writing an accumulator row index where a scratchpad row index belongs is a
silent-wrong-data class, not a crash) all have to be derived -- from the array geometry the store feeds
and the element width of the datapath that fills it. This module does that derivation, once, so a
capsule that wants to state a memory-mapping obligation has row-granular facts to state it against.

Three-state throughout, because this repo has a recurring bug class where an unmeasurable quantity was
reported as a measured zero. Every field is a real value, or ``None`` WITH an entry in
:attr:`AddressSpace.unknowns` saying which quantity is unknown and why. "This target declares no on-chip
store" (``stores_status == ABSENT``) and "this target's facts could not tell us" (``UNKNOWN``) are
distinct states and never collapse into each other -- one target's extractor really does report an empty
memory list, while another's artifact carries no ``memories`` key at all.

Nothing here is a literal about any device: the row width comes from the target's own ``arrays``
geometry times its own ``datapaths`` element width, the capacities from its own ``memories``, and the
element width from the shared quant-format registry (which fails closed on an unrecognized spelling
rather than assuming a byte). :func:`corroborate` checks the derived row widths against the SRAM row
widths mlc discovers directly in the RTL, so a wrong derivation is caught rather than believed.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any

#: ``stores_status`` values. DERIVED = the facts named at least one on-chip store. ABSENT = the facts
#: carry a memory list and it is EMPTY (the extractor ran and found none) -- a fact about the device.
#: UNKNOWN = the facts could not be read, or carry no memory list at all -- a fact about our extraction.
#: The last two must never be conflated: one says "there is nothing there", the other "we cannot see".
DERIVED = "derived"
ABSENT = "absent"
UNKNOWN = "unknown"


@dataclass(frozen=True)
class Unknown:
    """One quantity that could NOT be derived, and why.

    Carried as data rather than logged, because the caller (a capsule obligation, a report) has to be
    able to say WHICH bound it is missing. A quantity that is merely absent from this list is derived;
    a quantity that is ``None`` without an entry here would be exactly the silent-zero bug this module
    exists to avoid, so every ``None`` below is paired with one of these.
    """

    quantity: str
    reason: str
    store: str | None = None

    def to_dict(self) -> dict:
        out = {"quantity": self.quantity, "reason": self.reason}
        if self.store:
            out["store"] = self.store
        return out


def element_bits(token: str | None) -> int | None:
    """Width in BITS of one element of ``token``, or ``None`` when the spelling is not recognized.

    Fails closed on purpose. The obvious alternative -- default to 8 when nothing is known -- is not
    hypothetical: the accumulator bound in the contract predicate does exactly that, and an omitted
    accumulator dtype makes a 65536-byte accumulator read as 65536 elements instead of the 16384 its
    declared 32-bit accumulate word actually allows, i.e. four times too much room (see the module note
    in the test file). A returned ``None`` costs the caller a reported UNKNOWN; a defaulted 8 costs it a
    wrong answer that looks derived.

    Resolution order: the quant-format registry first (it knows the float formats, whose names carry
    several digit runs -- ``fp8_e4m3`` scraped for digits yields 843), then the plain machine spellings
    (``i8``/``i32``/``f32``) via the registry's own structural parser.
    """
    if not token:
        return None
    from merlin.common import quant_formats as qf

    tok = str(token)
    try:
        if qf.has(tok):
            return int(qf.get(tok).element_bits)
    except Exception:  # noqa: BLE001 -- registry unreadable: try machine
        pass
    try:
        return qf.machine_bits(tok)
    except Exception:  # noqa: BLE001 -- unrecognized spelling: UNKNOWN
        return None


def _ceil_div(a: int, b: int) -> int:
    return -(-a // b)


@dataclass(frozen=True)
class Store:
    """One on-chip store, described in the unit a backend actually addresses: the ROW.

    ``nbytes``/``depth`` are read from the facts. Everything else is derived:

    ``row_bytes``
        the width of one addressable row = the array edge the store feeds (``row_elems``) times the
        element width of the datapath that fills it. Measured on a 16x16 int8 array: a 16-byte operand
        row and a 64-byte (16 x i32) accumulator row -- both confirmed against the RTL SRAM widths mlc
        discovers (``operand_row_bytes: 16``, ``accum_row_bytes: 64``).
    ``total_rows``
        ``nbytes // row_bytes`` -- 262144/16 = 16384 operand rows, 65536/64 = 1024 accumulator rows.
        These are the two numbers the measured aborts printed; neither is in the facts artifact.
    ``banks``
        ``total_rows // depth`` when it divides -- 16384/4096 = 4 operand banks, 1024/512 = 2
        accumulator banks. ``depth`` is the PER-BANK row count, which is why it is smaller than the row
        total; reading it as the address limit under-addresses the store by the bank factor.

    A quantity that does not divide is NOT rounded: the residue is kept (``row_residue_bytes``,
    ``bank_residue_rows``) and the quotient it would have produced is withheld, because a row width that
    does not evenly tile the store is evidence the width is wrong, not something to floor away.
    """

    name: str
    nbytes: int | None
    depth: int | None
    row_elems: int | None
    element_dtype: str | None
    element_bits: int | None
    row_bytes: int | None
    total_rows: int | None
    banks: int | None
    row_residue_bytes: int | None = None
    bank_residue_rows: int | None = None
    #: True only where the access width came from a LANE COUNT rather than from an array edge plus a
    #: datapath element. The distinction is load-bearing and getting it wrong was a real defect: a
    #: store whose element width simply could not be LINKED to a datapath also has no `element_bits`,
    #: and treating that as lane-granular answered "16 elements per row" for a store whose row width is
    #: genuinely unknown -- exactly the assumption-wearing-a-derivation's-clothes this module refuses
    #: everywhere else. Only the SIMT path sets it.
    lane_granular: bool = False
    #: Elements per row as the store's own SRAM DECLARES them (``UInt<8>[32]`` -> 32), when a census read
    #: the declaration. ``None`` for a port-derived store, whose ``row_elems`` is a byte-enable lane count,
    #: not an element vector.
    declared_row_elems: int | None = None
    sources: dict[str, str] = field(default_factory=dict)

    @property
    def bytes_per_depth_entry(self) -> int | None:
        """``nbytes // depth`` -- the bytes one depth index covers ACROSS all banks (64 on the measured
        operand store: 4 banks of a 16-byte row). Independent of ``row_bytes``, so it is the cross-check
        that catches a wrong row width: it must be an exact multiple of ``row_bytes``, and the multiple
        is the bank count."""
        if not self.nbytes or not self.depth:
            return None
        return self.nbytes // self.depth

    def elems_per_row(self, dtype: str | None = None) -> int | None:
        """How many elements of ``dtype`` (default: the store's own datapath element) one row holds.

        Counted in BITS so a sub-byte packed format is not silently rounded up to a byte apiece, and a
        dtype WIDER than the row (which cannot be stored row-aligned at all) returns ``None`` rather
        than 0 -- 0 would divide into a division-by-zero one layer down, or worse, into "it fits".
        """
        bits = element_bits(dtype) if dtype else self.element_bits
        if not self.row_bytes or not bits:
            # A LANE-GRANULAR STORE HAS NO FIXED ROW IN BYTES, and that is not the same as having no
            # row. Its access width is a LANE COUNT (`row_elems`) that holds whatever element the
            # program puts in it, so the elements per access are the lanes themselves -- the byte width
            # is what varies. Gated on the store SAYING so: an array-derived store whose element width
            # could not be linked to a datapath also has no `element_bits`, and its row is unknown.
            if self.lane_granular and self.row_bytes is None and self.row_elems:
                return int(self.row_elems)
            return None
        n = (self.row_bytes * 8) // bits
        return n or None

    def capacity_rows(self, dtype: str | None = None) -> int | None:
        """How many rows of ``dtype`` the store holds. ``total_rows`` where the row is a fixed byte
        width; on a lane-granular store the row's SIZE depends on the element, so the capacity does
        too, and answering with a single number would be answering a different question."""
        if self.total_rows:
            return int(self.total_rows)
        per_row = self.elems_per_row(dtype)
        bits = element_bits(dtype) if dtype else self.element_bits
        if not per_row or not bits or not self.nbytes:
            return None
        row_bits = per_row * bits
        return (int(self.nbytes) * 8) // row_bits or None

    def working_set_rows(self, shape: Sequence[int], dtype: str | None = None) -> int | None:
        """See :func:`working_set_rows`."""
        return working_set_rows(self, shape, dtype)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "bytes": self.nbytes,
            "depth": self.depth,
            "row_elems": self.row_elems,
            "element_dtype": self.element_dtype,
            "element_bits": self.element_bits,
            "row_bytes": self.row_bytes,
            "total_rows": self.total_rows,
            "banks": self.banks,
            "bytes_per_depth_entry": self.bytes_per_depth_entry,
            "row_residue_bytes": self.row_residue_bytes,
            "bank_residue_rows": self.bank_residue_rows,
            "lane_granular": self.lane_granular,
            "sources": dict(self.sources),
        }


def working_set_rows(store: Store, shape: Sequence[int], dtype: str | None = None) -> int | None:
    """How many ROWS of ``store`` a tensor of ``shape`` in ``dtype`` occupies, or ``None`` if unknown.

    Row-granular, and that is the whole point of it: the contract predicate counts the working set in
    ELEMENTS (capacity in bytes times 8 over the element width), which is only the same number when the
    innermost extent is a whole multiple of the row. A (K,N) weight tile with N=24 on a 16-element row
    occupies 2 rows per K, not 1.5 -- element accounting reports 75% of the residency the hardware
    actually spends, and it reports it as a fit. The last axis is the one laid along the row (row-major
    residency, which is what the movement instructions do); every leading axis multiplies.

    ``None`` (never 0) when the row width or the element width is unknown: a working set that cannot be
    computed is not an empty working set. An empty ``shape`` is a scalar and still occupies one row; a
    zero extent occupies none.
    """
    per_row = store.elems_per_row(dtype)
    if not per_row:
        return None
    dims = [int(x) for x in shape]
    if any(d < 0 for d in dims):
        raise ValueError(f"negative extent in shape {tuple(dims)}")
    if any(d == 0 for d in dims):
        return 0
    lead = 1
    for d in dims[:-1]:
        lead *= d
    return lead * _ceil_div(dims[-1], per_row) if dims else 1


@dataclass
class AddressSpace:
    """Every on-chip store of one target, in rows, with its unknowns attached.

    ``separate_accumulator_space`` is the field a memory-mapping obligation keys on. Two stores with
    DIFFERENT row widths cannot be one flat space: a row index means a different number of bytes in
    each, so an address computed for one and issued against the other reads the wrong data at no fault
    -- silent wrong numbers rather than the range-check abort an oversized index gets. Measured on a
    16x16 int8 array: 16-byte operand rows against 64-byte accumulator rows, a factor of four.
    """

    target: str
    stores: tuple[Store, ...] = ()
    stores_status: str = UNKNOWN
    array_name: str | None = None
    array_rows: int | None = None
    array_cols: int | None = None
    separate_accumulator_space: bool | None = None
    unknowns: tuple[Unknown, ...] = ()
    sources: dict[str, str] = field(default_factory=dict)
    #: The facts' ``datapaths`` exactly as read -- kept because WHERE the accumulate type lives (in a
    #: store, or inside the compute element) is answered by them, not by the memory list.
    datapaths: tuple[dict, ...] = ()

    def store(self, name: str) -> Store | None:
        """The store named ``name`` (the role name the facts schema assigns it), or ``None``."""
        return next((s for s in self.stores if s.name == name), None)

    @property
    def row_widths(self) -> tuple[int, ...]:
        """The DISTINCT known row widths, ascending. Its length is how many address granularities a
        backend has to keep straight."""
        return tuple(sorted({s.row_bytes for s in self.stores if s.row_bytes}))

    def unknown_quantities(self) -> tuple[str, ...]:
        return tuple(u.quantity for u in self.unknowns)

    def to_dict(self) -> dict:
        return {
            "target": self.target,
            "stores_status": self.stores_status,
            "stores": [s.to_dict() for s in self.stores],
            "array": (
                {"name": self.array_name, "rows": self.array_rows, "cols": self.array_cols}
                if self.array_rows is not None
                else None
            ),
            "separate_accumulator_space": self.separate_accumulator_space,
            "row_widths": list(self.row_widths),
            "unknowns": [u.to_dict() for u in self.unknowns],
            "sources": dict(self.sources),
        }


def _facts_for(target: str, facts: dict[str, Any] | None) -> tuple[dict[str, Any] | None, str | None]:
    """``(facts body, reason it is unavailable)``. Never raises: an unreadable artifact is a reported
    UNKNOWN, not a crash, because this module is called from reporting paths that must still describe
    the stores they DID derive.

    Accepts an already-loaded artifact (``{schema_version, inputs, facts: {...}}``) or an injected bare
    body, and reuses the facts module's own refusal messages so the reason a body is missing reads the
    same here as everywhere else -- an EMPTY body means the extractor never reached the RTL (a missing
    input worth fixing), which is a different problem from a body of another shape.
    """
    from merlin.targetgen.rtl import facts as rtl_facts

    doc = facts
    if doc is None:
        try:
            doc = rtl_facts.load_facts(target)
        except Exception as e:  # noqa: BLE001 -- no artifact, no toolchain, ...
            return None, f"RTL facts unavailable: {type(e).__name__}: {e}"
    if isinstance(doc, dict) and "facts" not in doc and any(k in doc for k in ("memories", "arrays", "datapaths")):
        return doc, None  # an injected bare body, already unwrapped
    try:
        return rtl_facts.facts_body(doc, target, needs="the on-chip address space"), None
    except Exception as e:  # noqa: BLE001 -- empty / differently-shaped body
        return None, f"{type(e).__name__}: {e}"


def _array_geometry(body: dict[str, Any]) -> tuple[dict[str, Any] | None, str | None]:
    """The compute array whose edge sets the row width, or ``(None, reason)``.

    Requires exactly ONE array carrying both extents. Picking "the first" out of several would silently
    choose which unit the stores feed, and on a device with two arrays of different widths that choice
    IS the row width -- an assumption dressed as a derivation. Ambiguity is reported instead.
    """
    cands = [
        a
        for a in (body.get("arrays") or [])
        if isinstance(a, dict) and isinstance(a.get("rows"), int) and isinstance(a.get("cols"), int)
    ]
    if len(cands) == 1:
        return cands[0], None
    if not cands:
        return None, "these facts declare no array with both a row and a column extent"
    names = [str(a.get("name")) for a in cands]
    return None, (
        f"these facts declare {len(cands)} arrays ({', '.join(names)}); which one a store "
        "feeds is not derivable, and choosing would be an assumption"
    )


def _evidence_tokens(text: Any) -> list[str]:
    """The lowercased whitespace-separated tokens of a datapath's ``evidence`` string.

    Structural split, no pattern matching: the evidence is prose the extractor wrote (``"scratchpad smem
    UInt<8>"``), and a too-narrow pattern over it would drop a conformant spelling silently -- the
    failure mode the no-regex rule exists for.
    """
    return [t.casefold() for t in str(text or "").split() if t]


def _element_dtype_for(store_name: str, datapaths: list[dict]) -> tuple[str | None, str | None, str | None]:
    """``(dtype token, how it was linked, reason it could not be)`` for the datapath filling ``store_name``.

    The link is structural and lives in the facts themselves: a datapath either carries the store's own
    role name (``accumulator`` -> ``accumulator``), or NAMES the store in the evidence string that
    grounds it (``input`` is evidenced by ``"scratchpad smem UInt<8>"``). Three tiers, each requiring a
    UNIQUE hit -- two datapaths claiming one store is an ambiguity to report, not a coin to flip.
    """
    want = store_name.casefold()
    dps = [d for d in datapaths if isinstance(d, dict) and d.get("dtype")]
    hits = [d for d in dps if str(d.get("name", "")).casefold() == want]
    how = "datapath name == store name"
    if not hits:
        hits = [d for d in dps if want in _evidence_tokens(d.get("evidence"))]
        how = "the store is named in the datapath's evidence"
    if not hits:
        hits = [d for d in dps if any(t.startswith(want) for t in _evidence_tokens(d.get("evidence")))]
        how = "the store name prefixes a token of the datapath's evidence"
    if len(hits) == 1:
        return str(hits[0]["dtype"]), how, None
    if not hits:
        declared = sorted(str(d.get("name")) for d in dps)
        return (
            None,
            None,
            (
                f"no datapath declares or evidences this store (declared: "
                f"{declared or 'none'}), so its element width is not derivable"
            ),
        )
    claimants = sorted(str(d.get("name")) for d in hits)
    return None, None, f"{len(hits)} datapaths claim this store ({', '.join(claimants)}); ambiguous"


def derive_address_space(target: str, *, facts: dict[str, Any] | None = None) -> AddressSpace:
    """Derive ``target``'s on-chip address space from its own RTL facts. Never raises.

    Everything is read out of the target's artifact: ``memories`` (name/bytes/depth), ``arrays``
    (the edge a row spans) and ``datapaths`` (the element width that edge is measured in). Pass
    ``facts`` to derive against an artifact already in hand (or a synthetic one, in a test) instead of
    re-reading it.
    """
    space = AddressSpace(target=target)
    unknowns: list[Unknown] = []
    body, reason = _facts_for(target, facts)
    if body is None:
        space.unknowns = (
            Unknown("stores", reason or "no facts body"),
            Unknown("separate_accumulator_space", reason or "no facts body"),
        )
        space.sources = {"facts": "unavailable"}
        return space
    space.sources = {"facts": "merlin.targetgen.rtl.facts.load_facts(target)['facts']"}

    mems = body.get("memories")
    if mems is None:
        space.stores_status = UNKNOWN
        unknowns.append(
            Unknown(
                "stores",
                "these facts carry no `memories` list at all, so whether the "
                "device has on-chip stores is UNKNOWN -- not that it has none",
            )
        )
    elif not mems:
        space.stores_status = ABSENT
        unknowns.append(
            Unknown(
                "stores",
                "the extractor produced an EMPTY memory list: this device is "
                "declared to have no on-chip store of its own",
            )
        )
    else:
        space.stores_status = DERIVED

    lane_granular = False
    array, array_reason = _array_geometry(body)
    if array is not None:
        space.array_name = str(array.get("name")) if array.get("name") else None
        space.array_rows, space.array_cols = int(array["rows"]), int(array["cols"])
        space.sources["row_elems"] = f"arrays[{space.array_name!r}].cols ({space.array_rows}x{space.array_cols})"
        if space.array_rows != space.array_cols:
            # A square array cannot tell us which edge a row spans, and every array measured so far is
            # square, so nothing has ever exercised the choice. On a rectangular one it matters: the
            # column edge is taken (a row of the store feeds one row of operands ACROSS the array), and
            # that is stated as an assumption to corroborate rather than buried.
            unknowns.append(
                Unknown(
                    "row_elems",
                    f"the array is {space.array_rows}x{space.array_cols} (not square); the row "
                    "width was taken as the COLUMN edge -- corroborate() against the RTL SRAM "
                    "widths before trusting it",
                )
            )
    elif mems:
        # NO ARRAY IS NOT NO ACCESS WIDTH. A SIMT device has no systolic array at all -- its facts
        # carry a `simt` block instead -- and its store is reached one WARP at a time: a coalesced
        # access moves `lanes_per_warp` elements, whatever their width, exactly the role the array's
        # column edge plays on a spatial device. Reading only `arrays` reported "no row width" for a
        # target whose own facts state the width in the units that fit it, and the whole memory-mapping
        # axis then reported 0/0 required regimes on a 128 KiB store.
        lanes = ((body.get("simt") or {}) if isinstance(body.get("simt"), dict) else {}).get("lanes_per_warp")
        if isinstance(lanes, int) and lanes > 0:
            space.array_cols = int(lanes)
            lane_granular = True
            space.sources["row_elems"] = f"simt.lanes_per_warp ({lanes}); this device has no array"
        else:
            unknowns.append(Unknown("row_elems", array_reason or "no array geometry"))

    datapaths = [d for d in (body.get("datapaths") or []) if isinstance(d, dict)]
    space.datapaths = tuple(datapaths)
    if mems and not datapaths:
        unknowns.append(
            Unknown(
                "element_bits",
                "these facts declare no `datapaths`, so no element width -- and a row is only measurable in elements",
            )
        )

    stores: list[Store] = []
    for mem in mems or []:
        if not isinstance(mem, dict) or not mem.get("name"):
            continue
        name = str(mem["name"])
        nbytes = int(mem["bytes"]) if isinstance(mem.get("bytes"), int) else None
        depth = int(mem["depth"]) if isinstance(mem.get("depth"), int) else None
        if nbytes is None:
            unknowns.append(Unknown("bytes", "this memory declares no byte capacity", name))
        if depth is None:
            unknowns.append(
                Unknown(
                    "depth",
                    "this memory declares no depth, so its bank count cannot be derived from its row total",
                    name,
                )
            )
        dtype, how, why = _element_dtype_for(name, datapaths) if datapaths else (None, None, None)
        if why:
            unknowns.append(Unknown("element_dtype", why, name))
        bits = element_bits(dtype)
        # An SRAM DECLARATION states its element vector (``UInt<16>[32]``): the width of each element and
        # how many a row holds. Where no datapath links to the store, that declared width is the element
        # width -- but only when the vector is the array's edge (a row of array lanes), and never from a
        # port-derived store, whose "elements" are byte-enable lanes (it says so in its own note).
        declared_row_elems = (
            int(mem["row_elems"])
            if isinstance(mem.get("row_elems"), int)
            and "row_element_note" not in mem
            and mem.get("source") != "firrtl_port_geometry"
            else None
        )
        declared_width_conflict = (
            bits is not None
            and declared_row_elems == space.array_cols
            and isinstance(mem.get("elem_bits"), int)
            and mem["elem_bits"] > 0
            and mem["elem_bits"] != bits
        )
        if declared_width_conflict:
            unknowns.append(
                Unknown(
                    "element_bits",
                    f"the linked datapath dtype {dtype!r} has {bits}-bit elements, but this "
                    f"store's SRAM declares {mem['elem_bits']}-bit elements on the same row lanes",
                    name,
                )
            )
            dtype, bits = None, None
        if (
            bits is None
            and dtype is None
            and not declared_width_conflict
            and declared_row_elems is not None
            and declared_row_elems == space.array_cols
            and isinstance(mem.get("elem_bits"), int)
        ):
            bits = int(mem["elem_bits"])
            how = "the store's own SRAM declaration (element WIDTH only; a memory does not declare a format)"
        if dtype and bits is None:
            unknowns.append(
                Unknown(
                    "element_bits",
                    f"datapath dtype {dtype!r} is not a spelling the quant-format registry recognizes",
                    name,
                )
            )
        row_elems = space.array_cols
        row_bytes = None
        if row_elems and bits:
            if bits % 8:
                # A sub-byte or otherwise unaligned datapath element leaves the row width genuinely
                # ambiguous: whether the SRAM packs N of them into a row or pads each to a byte is a
                # wiring fact these facts do not carry, and guessing picks a width that is wrong by up
                # to the packing factor. Refuse, and say what would settle it.
                unknowns.append(
                    Unknown(
                        "row_bytes",
                        f"the datapath element is {bits} bits (not byte-aligned), so whether a "
                        "row packs the array's elements or pads each to a byte is not derivable "
                        "from these facts -- corroborate() against the RTL row width",
                        name,
                    )
                )
            else:
                row_bytes = row_elems * (bits // 8)
        # A STORE MAY DECLARE ITS OWN ROW WIDTH, and where it does that is better evidence than the
        # array-times-datapath product this derives everywhere else: it is the width the RTL wrote down.
        # Without this, a target whose facts carry a row width but no `datapaths` had no row at all --
        # its byte capacity said nothing about how many rows are addressable, `capacity_rows` answered
        # None, and every memory-regime cell for it read `unknown` over a store whose geometry is fully
        # stated. Read only where the array path produced nothing, so no target's existing derivation
        # moves; where BOTH exist and disagree, the disagreement is surfaced rather than resolved.
        declared_bits = mem.get("row_bits_rtl")
        declared_bytes = (
            int(declared_bits) // 8
            if isinstance(declared_bits, int) and declared_bits > 0 and declared_bits % 8 == 0
            else None
        )
        # The same width may be declared in BYTES (`row_bytes`) instead of bits. Two spellings of one
        # quantity are read into one unit before anything compares them -- mixing them is a factor-of-8
        # error -- and two declarations that disagree are surfaced, not ranked.
        declared_field = "row_bits_rtl"
        stated_bytes = mem.get("row_bytes")
        stated_bytes = int(stated_bytes) if isinstance(stated_bytes, int) and stated_bytes > 0 else None
        if stated_bytes and declared_bytes and stated_bytes != declared_bytes:
            unknowns.append(
                Unknown(
                    "row_bytes",
                    f"this store declares its row as {declared_bits} bits AND as {stated_bytes} "
                    "bytes; the two declarations disagree",
                    name,
                )
            )
            declared_bytes = None
        elif stated_bytes and not declared_bytes:
            declared_bits, declared_bytes, declared_field = stated_bytes * 8, stated_bytes, "row_bytes"
        if row_bytes is None and declared_bytes:
            row_bytes = declared_bytes
            srcs_row_bytes = (
                f"memories[{name!r}].{declared_field} ({declared_bits} bits): the row width "
                f"this store's own RTL declares"
            )
        elif row_bytes and declared_bytes and declared_bytes != row_bytes:
            unknowns.append(
                Unknown(
                    "row_bytes",
                    f"the array-derived row width ({row_bytes} bytes) and the width this "
                    f"store's RTL declares ({declared_bytes} bytes) DISAGREE; one of them is "
                    f"wrong and a capacity computed from either is suspect",
                    name,
                )
            )
            srcs_row_bytes = None
        else:
            srcs_row_bytes = None
        total_rows = row_residue = banks = bank_residue = None
        if nbytes and row_bytes:
            total_rows, row_residue = nbytes // row_bytes, nbytes % row_bytes
            if row_residue:
                unknowns.append(
                    Unknown(
                        "total_rows",
                        f"{nbytes} bytes is not a whole number of {row_bytes}-byte rows "
                        f"({row_residue} bytes over): the derived row width is suspect",
                        name,
                    )
                )
            if depth:
                banks, bank_residue = total_rows // depth, total_rows % depth
                if bank_residue:
                    banks = None
                    unknowns.append(
                        Unknown(
                            "banks",
                            f"{total_rows} rows do not divide into banks of the declared depth "
                            f"{depth} ({bank_residue} rows over)",
                            name,
                        )
                    )
        elif nbytes and not (row_elems and lane_granular):
            unknowns.append(
                Unknown(
                    "total_rows",
                    "no row width, so a byte capacity says nothing about how many rows are addressable",
                    name,
                )
            )
        elif nbytes:
            # row_elems without row_bytes: a lane-granular store. Its capacity IS derivable, per
            # element type -- `Store.capacity_rows(dtype)` -- so this is not an unknown, and recording
            # it as one would report a derivable quantity as missing.
            pass
        # DECLARED COUNTS. Some extractors write the row total and bank count they read off the RTL
        # (`rows`, `banks`) beside the bytes/depth this derives them from. Where both exist they are two
        # measurements of one quantity: agreement is recorded, disagreement withholds the quantity with
        # an Unknown rather than preferring either. (A declared count never has a gap to fill: wherever
        # it would be consistent with bytes, row width and depth, those already derive it.) Element-level
        # fields (`row_elems`,
        # `elem_bits`) are deliberately NOT read: on a port-derived memory they are the WRITE GRANULARITY
        # a byte enable declares, not the element type the store holds, and an extractor says so.
        declared_counts = {}
        for key, quantity in (("rows", "total_rows"), ("banks", "banks")):
            value = mem.get(key)
            if isinstance(value, int) and value > 0:
                declared_counts[quantity] = value
        if "total_rows" in declared_counts:
            stated = declared_counts["total_rows"]
            if total_rows is not None and stated != total_rows:
                unknowns.append(
                    Unknown(
                        "total_rows",
                        f"derived {total_rows} rows but the facts declare {stated}; one of them "
                        "is wrong, so neither is used",
                        name,
                    )
                )
                total_rows = banks = None
        if "banks" in declared_counts:
            stated = declared_counts["banks"]
            if banks is not None and stated != banks:
                unknowns.append(
                    Unknown(
                        "banks",
                        f"derived {banks} banks but the facts declare {stated}; one of them is wrong, "
                        "so neither is used",
                        name,
                    )
                )
                banks = None
        srcs = {"bytes_depth": str(mem.get("source") or "facts.memories")}
        if how:
            srcs["element_dtype"] = how
        if srcs_row_bytes:
            srcs["row_bytes"] = srcs_row_bytes
        elif row_bytes:
            srcs["row_bytes"] = f"array cols {row_elems} x {dtype or 'declared element'} ({bits} bits)"
        if declared_counts:
            srcs["declared_counts"] = ", ".join(f"{q}={v}" for q, v in declared_counts.items())
        stores.append(
            Store(
                name=name,
                nbytes=nbytes,
                depth=depth,
                row_elems=row_elems,
                element_dtype=dtype,
                element_bits=bits,
                row_bytes=row_bytes,
                total_rows=total_rows,
                banks=banks,
                row_residue_bytes=row_residue,
                bank_residue_rows=bank_residue,
                lane_granular=lane_granular,
                sources=srcs,
                declared_row_elems=declared_row_elems,
            )
        )

    space.stores = tuple(stores)
    sep, sep_reason = _separate_accumulator_space(space)
    space.separate_accumulator_space = sep
    if sep is None:
        unknowns.append(Unknown("separate_accumulator_space", sep_reason or "undecidable"))
    space.unknowns = tuple(unknowns)
    return space


def _separate_accumulator_space(space: AddressSpace) -> tuple[bool | None, str | None]:
    """Is the accumulator a second address space, or is there one flat store? ``(verdict, reason)``.

    Decided on ROW WIDTH, not on names: names are a labelling convention, whereas two stores whose rows
    are different sizes cannot share an address space by construction. One store means one space
    (``False``); equal widths across several stores leaves it UNDECIDED rather than ``False``, because
    equal granularity is not evidence of a shared space -- and answering ``False`` there would tell a
    backend it may address them alike, which is the silent-wrong-data direction.
    """
    if space.stores_status != DERIVED:
        return None, (
            f"stores are {space.stores_status}: with no store list there is no second space "
            "to have, and claiming there is none would overstate what we read"
        )
    if len(space.stores) == 1:
        return False, None
    widths = [s.row_bytes for s in space.stores]
    if any(w is None for w in widths):
        return None, (
            "at least one store's row width is unknown, so two stores cannot be compared -- "
            "reporting 'one space' here would license addressing them alike"
        )
    if len(set(widths)) > 1:
        return True, None
    return None, (
        f"all {len(widths)} stores have {widths[0]}-byte rows; equal granularity is not "
        "evidence that they share one address space"
    )


#: ``RoleResolution.basis`` values -- HOW a store came to hold a role, so a caller can decide what the
#: resolution licenses. ``BY_WIDTH``: several stores whose row widths are all known and distinct, ranked
#: by width (the operand store is the narrowest, the accumulator the widest: a separate accumulator space
#: exists precisely BECAUSE its row holds the wider accumulate type). ``SOLE_STORE``: the facts name one
#: store, so it is where operands live -- but nothing CLASSIFIED it against another store, and a device
#: can expose one extracted memory out of many.
BY_WIDTH = "by_width"
SOLE_STORE = "sole_store"


@dataclass(frozen=True)
class RoleResolution:
    """Which store holds one role, how that was decided, and -- when no store does -- why not.

    Exactly one of ``store`` and ``reason`` is set. A resolver that answered ``None`` with no reason would
    turn a refusal into a silence, and every consumer here refuses by quoting the reason.
    """

    role: str
    store: Store | None
    basis: str | None
    reason: str | None = None

    def capacity_rows(self, dtype: str | None = None) -> int | None:
        return self.store.capacity_rows(dtype) if self.store is not None else None


def _row_bits(store: Store, dtype: str | None) -> int | None:
    """A store's row width in BITS at ``dtype`` -- the one scale on which a fixed-byte row and a
    lane-granular one are comparable. ``None`` when it cannot be measured."""
    if store.row_bytes:
        return int(store.row_bytes) * 8
    per_row = store.elems_per_row(dtype)
    bits = element_bits(dtype) if dtype else store.element_bits
    return per_row * bits if (per_row and bits) else None


def _array_fed(store: Store, space: AddressSpace) -> bool:
    """Whether ``store`` can hold rows a compute array streams: one array-edge vector of whole elements.

    Structural, never by name. A store whose SRAM declares a row of some other vector length (an
    instruction memory's single 32-bit word, a register file's one 256-bit word) is not an array's operand
    or accumulator store, and neither is one whose row is too narrow to hold one byte per array lane. A
    lane-granular store (no fixed row) and a store without a known array edge are not excluded: there is
    no edge to test them against.
    """
    edge = space.array_cols
    if not edge or store.lane_granular:
        return True
    if store.declared_row_elems is not None and store.declared_row_elems != edge:
        return False
    return not (store.row_bytes and store.row_bytes < edge)


def operand_store(space: AddressSpace, *, dtype: str | None = None) -> RoleResolution:
    """The store operands live in, chosen by ROW WIDTH, never by name.

    A name is a labelling convention of whichever extractor wrote the facts; row width is a property of
    the device. Several stores are ranked only when every width is measurable and the narrowest is
    unique -- an unmeasurable width or a tie is a refusal with its reason, because picking one would be a
    guess about which memory the device computes from.
    """
    role = "operand"
    if space.stores_status != DERIVED:
        return RoleResolution(role, None, None, f"the facts' store list is {space.stores_status}")
    stores = [s for s in space.stores if (s.row_bytes or s.row_elems) and _array_fed(s, space)]
    if not stores:
        return RoleResolution(
            role,
            None,
            None,
            f"none of {[s.name for s in space.stores]} has a derivable row width that holds one array-edge row",
        )
    if len(stores) == 1:
        return RoleResolution(role, stores[0], SOLE_STORE)
    widths = {s.name: _row_bits(s, dtype) for s in stores}
    unmeasured = sorted(name for name, bits in widths.items() if bits is None)
    if unmeasured:
        return RoleResolution(
            role,
            None,
            None,
            f"row widths of {unmeasured} are not measurable at dtype {dtype!r}, so "
            f"{len(stores)} stores cannot be ranked",
        )
    narrowest = min(widths.values())
    tied = sorted(name for name, bits in widths.items() if bits == narrowest)
    if len(tied) > 1:
        return RoleResolution(
            role,
            None,
            None,
            f"stores {tied} tie at the narrowest row ({narrowest} bits); which one "
            "holds operands is not decidable from width",
        )
    return RoleResolution(role, next(s for s in stores if s.name == tied[0]), BY_WIDTH)


def accumulator_store(space: AddressSpace) -> RoleResolution:
    """The ADDRESSABLE store accumulate results live in, chosen by row width, or why there is none.

    Only where the address space is decided to be separate (``separate_accumulator_space is True``: at
    least two stores, every row width known, not all equal) -- with one store there is no second region
    to hold an accumulator, and a width comparison that could not be made is not evidence of one. The
    widest store answers; a tie at the widest is a refusal.
    """
    role = "accumulator"
    if space.separate_accumulator_space is not True:
        if space.stores_status == DERIVED and len(space.stores) == 1:
            why = (
                f"the facts name one store ({space.stores[0].name!r}); with no second address space "
                "there is no addressable accumulator region"
            )
        else:
            why = next(
                (u.reason for u in space.unknowns if u.quantity == "separate_accumulator_space"),
                f"the facts' store list is {space.stores_status}",
            )
        return RoleResolution(role, None, None, why)
    fed = [s for s in space.stores if s.row_bytes and _array_fed(s, space)]
    if len(fed) < 2:
        return RoleResolution(role, None, None, f"fewer than two stores hold array-edge rows ({[s.name for s in fed]})")
    widest = max(s.row_bytes for s in fed)
    tied = sorted(s.name for s in fed if s.row_bytes == widest)
    if len(tied) > 1:
        return RoleResolution(
            role,
            None,
            None,
            f"stores {tied} tie at the widest row ({widest} bytes); which one accumulates is not decidable from width",
        )
    return RoleResolution(role, next(s for s in fed if s.name == tied[0]), BY_WIDTH)


#: ``AccumulatorKind.kind`` values. ``ADDRESSABLE``: accumulate results land in an on-chip STORE a
#: backend addresses by row, distinct from the operand store. ``IN_DATAPATH``: the facts declare an
#: accumulate type but no store it fills -- the accumulator is state inside the compute element, so there
#: are no accumulator rows to address, and its depth (in tiles) is something the facts do not say.
#: ``UNKNOWN_KIND``: neither is derivable, or the facts disagree with themselves.
ADDRESSABLE = "addressable"
IN_DATAPATH = "in_datapath"
UNKNOWN_KIND = "unknown"

#: The facts schema's ROLE for the accumulate datapath -- a key the extractors write
#: (``datapaths[].name == "accumulator"``, or an ``accumulator`` dtype on a datapath), not a spelling of
#: any target's.
_ACCUMULATE_ROLE = "accumulator"


@dataclass(frozen=True)
class AccumulatorKind:
    """Where one target's accumulate results live, derived from its facts, with the evidence.

    ``rows`` is set only for ``ADDRESSABLE``. ``IN_DATAPATH`` deliberately carries ``rows=None`` and an
    ``unknown``: the facts say WHERE the accumulator is (a module, its ports, the type) and nothing about
    how many tiles of it there are, so any number here would be a constant wearing a derivation's clothes.
    """

    kind: str
    store: Store | None = None
    rows: int | None = None
    dtype: str | None = None
    datapath: str | None = None
    unknown: Unknown | None = None
    #: How many identical accumulator buffers the store is one of (one per buffer index a compute
    #: selects); ``rows`` is per buffer.
    buffers: int = 1

    @property
    def reason(self) -> str | None:
        return self.unknown.reason if self.unknown is not None else None


def _holds_accumulate_type(store: Store, declared: str) -> bool:
    """Whether ``store``'s elements are the declared accumulate type. A store whose element came from an
    SRAM declaration (no linked datapath) knows only a WIDTH, so there agreement is width agreement; a
    linked datapath's type must match exactly."""
    if store.element_dtype is not None:
        return store.element_dtype == declared
    return store.element_bits is not None and store.element_bits == element_bits(declared)


def _declared_accumulate_types(datapaths: Sequence[dict]) -> list[tuple[str, str]]:
    """``(datapath name, accumulate dtype)`` for every accumulate type the facts declare, in either form
    the extractors write: a datapath whose role IS the accumulator, or a datapath carrying an
    ``accumulator`` dtype for what it computes."""
    out: list[tuple[str, str]] = []
    for d in datapaths:
        if str(d.get("name", "")).casefold() == _ACCUMULATE_ROLE and d.get("dtype"):
            out.append((str(d["name"]), str(d["dtype"])))
        elif isinstance(d.get(_ACCUMULATE_ROLE), str) and d.get(_ACCUMULATE_ROLE):
            out.append((str(d.get("name")), str(d[_ACCUMULATE_ROLE])))
    return out


def accumulator_kind(space: AddressSpace) -> AccumulatorKind:
    """ADDRESSABLE, IN_DATAPATH or UNKNOWN -- from the store list AND the datapaths, never width alone.

    Row width can say that two stores are different address spaces; it cannot say that the wider one is
    where results accumulate (an instruction buffer and a scratchpad differ in width too). So an
    ADDRESSABLE verdict needs both: the width-resolved accumulator store, and an accumulate datapath
    structurally linked to it (the store's element type came from that datapath). Declared accumulate
    types that disagree with each other, or with the store they would fill, are UNKNOWN -- a device with
    two datapaths declaring i32 and f32 accumulators has no single accumulate type to schedule for.
    """
    declared = _declared_accumulate_types(space.datapaths)
    types = sorted({dtype for _, dtype in declared})
    if len(types) > 1:
        return AccumulatorKind(
            UNKNOWN_KIND,
            unknown=Unknown(
                "accumulator_kind",
                f"the datapaths declare {len(types)} different accumulate types "
                f"({', '.join(f'{n}: {t}' for n, t in declared)}); which one a schedule "
                "accumulates in is not decidable from the facts",
            ),
        )
    resolved = accumulator_store(space)
    if resolved.store is None and types:
        # A TIE AT THE WIDEST ROW between identical stores that all hold the declared accumulate type is not
        # an ambiguity: it is several accumulator BUFFERS a compute selects between (a device with acc0 and
        # acc1). Only exact geometric twins qualify -- anything else stays the refusal it was.
        fed = [s for s in space.stores if s.row_bytes and _array_fed(s, space)]
        if space.separate_accumulator_space is True and len(fed) >= 2:
            widest = max(s.row_bytes for s in fed)
            twins = sorted((s for s in fed if s.row_bytes == widest), key=lambda s: s.name)
            shape = {(s.row_bytes, s.total_rows, s.depth, s.banks) for s in twins}
            if len(twins) > 1 and len(shape) == 1 and all(_holds_accumulate_type(s, types[0]) for s in twins):
                return AccumulatorKind(
                    ADDRESSABLE,
                    store=twins[0],
                    rows=twins[0].total_rows,
                    dtype=types[0],
                    datapath=declared[0][0],
                    buffers=len(twins),
                )
    if resolved.store is not None:
        store = resolved.store
        if store.element_bits is None or not types:
            return AccumulatorKind(
                UNKNOWN_KIND,
                unknown=Unknown(
                    "accumulator_kind",
                    f"{store.name!r} is the widest of separate stores, but "
                    + (
                        "no element width is known for it"
                        if store.element_bits is None
                        else "no datapath declares an accumulate type"
                    )
                    + ", so nothing says results accumulate there",
                    store.name,
                ),
            )
        if not _holds_accumulate_type(store, types[0]):
            return AccumulatorKind(
                UNKNOWN_KIND,
                unknown=Unknown(
                    "accumulator_kind",
                    f"{store.name!r} holds {store.element_dtype or f'{store.element_bits}-bit elements'} "
                    f"but the facts declare an accumulate type of {types[0]}",
                    store.name,
                ),
            )
        return AccumulatorKind(ADDRESSABLE, store=store, rows=store.total_rows, dtype=types[0], datapath=declared[0][0])
    if not declared:
        return AccumulatorKind(
            UNKNOWN_KIND,
            unknown=Unknown(
                "accumulator_kind",
                f"no addressable accumulator store ({resolved.reason}), and no datapath declares an accumulate type",
            ),
        )
    linked = [
        s.name
        for s in space.stores
        if s.element_dtype == types[0] and _element_dtype_for(s.name, list(space.datapaths))[0] == types[0]
    ]
    if linked:
        return AccumulatorKind(
            UNKNOWN_KIND,
            unknown=Unknown(
                "accumulator_kind",
                f"the accumulate type {types[0]} is linked to store(s) {linked}, but those "
                f"are not a separate accumulator space ({resolved.reason})",
            ),
        )
    name, dtype = declared[0]
    return AccumulatorKind(
        IN_DATAPATH,
        dtype=dtype,
        datapath=name,
        unknown=Unknown(
            "accumulator_rows",
            f"the accumulator is state inside the compute element (datapath {name!r}, "
            f"{dtype}), not an addressable store; the facts do not declare how many tiles "
            "deep it is, so there are no accumulator rows to schedule into",
        ),
    )


def corroborate(target: str, space: AddressSpace | None = None) -> dict:
    """Check the DERIVED row widths and capacities against the SRAM widths mlc discovers in the RTL.

    The derivation multiplies an array edge by a datapath element width; mlc reads the memory's actual
    row width out of the HW dialect. They are independent, and on the measured 16x16 int8 device they
    agree exactly (16-byte operand rows, 64-byte accumulator rows, 4 and 2 banks) -- which is what makes
    the derived numbers usable on a device where mlc cannot classify the SRAMs at all.

    Stores are matched to mlc's groups by (bytes, depth), never by name: mlc reports RTL instance paths
    while the facts carry the schema's role names, and matching those two by string is exactly the kind
    of spelling assumption that silently drops a conformant target.

    Returns ``{available, reason, agree, stores: [...]}`` with ``agree`` tri-state -- ``None`` when mlc
    is unavailable (the common case in a sandbox), never ``True``.
    """
    space = space or derive_address_space(target)
    out: dict[str, Any] = {"target": target, "available": False, "reason": None, "agree": None, "stores": []}
    try:
        from merlin.targetgen.rtl import mlc_bridge as mb

        caps = mb.discovered_capacities(target) or {}
        mm = mb.discovered_memory_map(target) or {}
    except Exception as e:  # noqa: BLE001 -- no mlc: undecidable, not a pass
        out["reason"] = f"mlc discovery unavailable: {type(e).__name__}: {e}"
        return out
    if not caps or not mm:
        out["reason"] = "mlc discovered no memory map for this target, so nothing to corroborate against"
        return out
    out["available"] = True
    # mlc reports its two classified groups under role keys; pair each with its row width, then match by
    # measured (bytes, depth) so the pairing survives any naming difference.
    groups = [
        {
            "bytes": caps.get("operand_bytes"),
            "depth": caps.get("operand_depth"),
            "row_bytes": mm.get("operand_row_bytes"),
            "rep": mm.get("operand_mem"),
        },
        {
            "bytes": caps.get("accumulator_bytes"),
            "depth": caps.get("accumulator_depth"),
            "row_bytes": mm.get("accum_row_bytes"),
            "rep": mm.get("accum_mem"),
        },
    ]
    verdicts: list[bool] = []
    for st in space.stores:
        hits = [g for g in groups if g["bytes"] == st.nbytes and g["depth"] == st.depth]
        row: dict[str, Any] = {
            "store": st.name,
            "derived_row_bytes": st.row_bytes,
            "rtl_row_bytes": None,
            "rtl_instance": None,
            "rtl_banks": None,
            "agree": None,
        }
        if len(hits) != 1:
            row["reason"] = (
                f"{len(hits)} mlc groups match (bytes={st.nbytes}, depth={st.depth}); "
                "unmatched, so nothing is claimed either way"
            )
            out["stores"].append(row)
            continue
        g = hits[0]
        row["rtl_row_bytes"], row["rtl_instance"] = g["row_bytes"], g["rep"]
        if g["row_bytes"] and st.nbytes and g["depth"]:
            rtl_rows = st.nbytes // int(g["row_bytes"])
            row["rtl_total_rows"] = rtl_rows
            row["rtl_banks"] = rtl_rows // int(g["depth"]) if rtl_rows % int(g["depth"]) == 0 else None
        if st.row_bytes and g["row_bytes"]:
            row["agree"] = int(st.row_bytes) == int(g["row_bytes"])
            verdicts.append(row["agree"])
        else:
            row["reason"] = "one of the two widths is unknown, so they cannot be compared"
        out["stores"].append(row)
    out["agree"] = all(verdicts) if verdicts else None
    if not verdicts:
        # mlc classified memories that the facts artifact does not carry (measured on one device: mlc
        # names a 4-byte-row shared memory and a 64-byte-row register file while the artifact's memory
        # list is empty, because the sibling-bank grouping finds no `<base>_<int>` segment to sum over).
        # Nothing was compared, and saying so is the point -- an empty comparison is not an agreement.
        named = [f"{g['rep']} ({g['row_bytes']}-byte rows)" for g in groups if g.get("rep")]
        out["reason"] = (
            f"no derived store matched an mlc group ({len(space.stores)} derived, "
            f"{sum(1 for g in groups if g['bytes'])} with a discovered capacity): nothing "
            f"was compared"
            + (
                f"; mlc DOES name {'; '.join(named)}, so the facts artifact is missing memories the RTL has"
                if named
                else ""
            )
        )
    return out
