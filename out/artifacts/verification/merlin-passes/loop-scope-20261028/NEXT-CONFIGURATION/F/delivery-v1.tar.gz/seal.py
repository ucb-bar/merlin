"""Source/text retention seal; no compiler launch or policy approval."""
import hashlib
import json
from pathlib import Path

root = Path.cwd()
f = Path(__file__).resolve().parent.parent
allowed = {".py", ".lean", ".json", ".yaml", ".mlir", ".md", ".patch", ".txt", ".log", ".stdout", ".stderr"}
members = []
for path in sorted(f.rglob("*")):
    if not path.is_file() or path.name in {"ACTIVE.md", "SEAL-v1.json"}:
        continue
    if path.suffix not in allowed and path.name not in {"stdout", "stderr"}:
        continue
    assert not path.is_symlink()
    data = path.read_bytes()
    members.append({"path": str(path.relative_to(root)), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
seal = {"schema": "merlin.configuration.F-retention-seal.v1", "status": "CURRENT_Q3_F3_ENGINEERING_QUALIFICATION_COMPLETE",
        "members": members, "count": len(members), "bytes": sum(item["bytes"] for item in members),
        "current_source_cut": "Q3/F3", "old_Q1": "unavailable", "old_Q2": "UNQUALIFIED reserved metadata admission",
        "excluded": ["mutable ACTIVE.md", "compiled/runtime binary images"], "human_effect_model_approved": False,
        "hardware_native_numeric_fidelity": False, "production_enforcement": False}
with (f / "SEAL-v1.json").open("x") as stream:
    stream.write(json.dumps(seal, indent=2) + "\n")
for row in members:
    data = (root / row["path"]).read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
print(json.dumps({key: value for key, value in seal.items() if key != "members"}))
