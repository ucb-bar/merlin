"""Retain the qualified Q3/F3 source, actual example and native checker text.

This collector checks data associations only. It launches no proof/compiler and
does not turn a historical failed profile or an unreviewed effect policy green.
"""
import hashlib
import importlib.metadata
import json
import shutil
import subprocess
import sys
from pathlib import Path

root = Path.cwd()
f = Path(__file__).resolve().parent.parent
out = f / "delivery-v1"
reference_root = Path("/home/jeremy/Projects/merlin-graph-proof-intake")
artifact_helpers = list(f.rglob("*.py"))


def read(path):
    return json.loads(path.read_text())


def ref(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def verify(old):
    path = Path(old["path"])
    path = path if path.is_absolute() else root / path
    actual = ref(path)
    assert actual["sha256"] == old["sha256"] and actual["bytes"] == old.get("bytes", old.get("size"))
    return path


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")


campaign = read(f / "qualification-v3/RESULT.json")
assert campaign["status"] == "CONFIGURATION_ENGINEERING_QUALIFICATION_PASSED"
assert (campaign["actual_checked_pairs"], campaign["actual_native_refusals"], campaign["host_refusals"]) == (13, 21, 1)
assert campaign["valid_mutant_pairs"] == 22 and campaign["failures"] == []
assert campaign["controls"] == {"forged_requests": 15, "artifact_attacks": 11, "fresh_process_replay": True}
replay = read(f / "qualification-v3/fresh-process-replay/RESULT.json")
assert replay["incoming_ledger"] == 0 and replay["newly_issued_completions"] == 1
witness = read(f / "witness-binding-v2/RESULT.json")
assert witness["roots"] == 110 and witness["audit"]["theorems_audited"] == 276
assert witness["audit"]["violations"] == []
assert witness["explicit_custom_modules"] == ["ConfigurationElisionQuery", "ConfigurationElisionWitness"]
assert not witness["source_success_premise"] and not witness["whole_run_equivalence_premise"]

sources = {}


def source(old, role):
    path = verify(old)
    context = "worker" if path.is_relative_to(root) else "reference4499" if path.is_relative_to(reference_root) else None
    assert context is not None and path.suffix in {".py", ".lean", ".json", ".yaml"}
    base = root if context == "worker" else reference_root
    relative = str(path.relative_to(base))
    key = (context, relative)
    if key not in sources:
        target = out / "source-snapshot" / context / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(path.read_bytes())
        sources[key] = {"root": context, "path": relative, "sha256": old["sha256"], "bytes": old.get("bytes", old.get("size")),
                        "snapshot": str(target.relative_to(f)), "roles": []}
    assert sources[key]["sha256"] == old["sha256"]
    sources[key]["roles"].append(role)


positives = read(f / "qualification-v3/POSITIVES.json")
reports = []
for row in positives:
    assert row["status"] == "checked" and row["consumer_called"] and row["final_bytes_identical"]
    report = read(verify(row["report"]))
    assert len(report["statements"]) == 17 and report["audit"]["violations"] == []
    assert set(report["audit"]["axioms_used"]) <= {"propext", "Classical.choice", "Quot.sound"}
    for old in report["sources"]:
        source(old, "current_gate_bound_project_host_or_selected_input")
    for old in [*report["buffers"], report["query"], *report["library"], *report["process_evidence"]]:
        verify(old)  # Private project objects only; no SDK/library image reads.
    for old in row["original_before_after"]:
        verify(old)
    reports.append({"case": row["name"], "report": row["report"], "roots": row["roots"],
                    "theorems": report["audit"]["theorems_audited"], "buffers": row["original_before_after"]})
for old in read(f / "source-cut-v3/SOURCES.json")["sources"]:
    source(old, "F_owned_current_canonical")
for case in read(f / "producer-source-reproduction-v2/RESULT.json")["cases"]:
    for old in case["source_refs"]:
        source(old, "original4499_source_actually_executed_by_byte_bound_loader")
for path in artifact_helpers:
    source(ref(path), "F_owned_current_or_historical_artifact_source")
for path in (f / "witness-binding-v2").glob("*.lean"):
    source(ref(path), "F_independently_compiled_actual_query_witness")

retained = []
native = root / "out/build/loop-scope-20261028/qualification/configuration-v3"
for path in sorted(native.rglob("*")):
    if not path.is_file() or path.suffix not in {".json", ".lean", ".mlir", ".stdout", ".stderr"}:
        continue
    assert not path.is_symlink()
    target = out / "native-output" / path.relative_to(native)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as stream:
        stream.write(path.read_bytes())
    retained.append({"original": ref(path), "copy": ref(target)})
save(out / "RETAINED-NATIVE-OUTPUT.json", {"copies": retained, "binaries_copied": False})
manifest = {"schema": "merlin.configuration.F-source-delivery.v1", "status": "EXACT_CURRENT_Q3_F3_SOURCE_CLOSURE",
            "sources": sorted(sources.values(), key=lambda item: (item["root"], item["path"])),
            "current_owned_patch": "source-cut-v3/owned.patch", "current_owned_sources": "source-cut-v3/SOURCES.json",
            "historical_owned_cuts": ["source-preparation-v1/SOURCES.json", "source-cut-v1/SOURCES.json", "source-cut-v2/SOURCES.json"],
            "native_binaries_included": False, "human_approved": False}
save(f / "SOURCE-DELIVERY.json", manifest)

baseline = next(row for row in positives if row["name"] == "multifield")
base = Path(baseline["report"]["path"]).parent
example = f / "PAPER-EXAMPLE-v1"
example.mkdir(exist_ok=False)
for name in ["source.mlir", "final.mlir", "ConfigurationElisionQuery.lean", "REPORT.json", "Projection.json",
             "SourceRequest.json", "Resolution.json", "audit.stdout", "types.stdout", "query.process.json", "query.stdout"]:
    path = base / name
    if path.exists():
        shutil.copyfile(path, example / name)
negative = native / "negatives/drop_first_write"
for name in ["source.mlir", "final.mlir", "ConfigurationElisionQuery.lean", "query.stdout", "query.stderr", "query.process.json"]:
    shutil.copyfile(negative / name, example / ("negative-" + name))
save(example / "BINDINGS.json", {"positive": baseline, "negative": "compiler-valid dropped first configuration write",
                               "negative_result": next(row for row in read(f / "qualification-v3/NEGATIVES.json") if row["case"] == "drop_first_write"),
                               "fresh_replay": ref(f / "qualification-v3/fresh-process-replay/RESULT.json"),
                               "actual_success_error_witness": ref(f / "witness-binding-v2/RESULT.json"),
                               "human_approved": False, "native_hardware_fidelity": False})
tool = read(Path(baseline["report"]["path"]))["tool"]
oracle = read(f / "corpus-v1/COMPILER.json")["oracle"]
save(f / "FINAL_STATUS.json", {"schema": "merlin.configuration.F-final.v1", "status": "SCOPED_Q3_F3_CONFIGURATION_ENGINEERING_QUALIFICATION_COMPLETE",
    "branch": subprocess.check_output(["git", "branch", "--show-current"], text=True).strip(),
    "HEAD": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "Q_cut": "v3", "F_cut": "v3", "campaign": ref(f / "qualification-v3/RESULT.json"), "positive_reports": reports,
    "witness": ref(f / "witness-binding-v2/RESULT.json"), "source_delivery": ref(f / "SOURCE-DELIVERY.json"),
    "owned_source_files": 11, "owned_patch": "source-cut-v3/owned.patch", "producer_revision": "4499eebb959c0f92cefd92cc6d80646ba66474ed",
    "producer_reproduction": ref(f / "producer-source-reproduction-v2/RESULT.json"),
    "formal_relation": "equal complete modeled entry success or error and terminal state; arbitrary initial configuration",
    "human_effect_policy_approved": False, "trusted_Python_IR_projection": True, "native_hardware_numeric_fidelity": False,
    "production_enforcement": False, "adjacent_pass_composition": "requires explicit common interpretation",
    "tools": {"Lean": tool, "selected_Lean_version": "repository-pinned4.35.0", "Python": sys.version,
              "Python_executable": sys.executable, "xdsl": importlib.metadata.version("xdsl"), "authoritative_MLIR_oracle": oracle},
    "historical_profiles": {"Q1_F1": "UNAVAILABLE projectcompilecwd; no proof accepted", "Q2_F2": "UNQUALIFIED reserved metadata admission despite selectedtests passing"}})
print(json.dumps({"status": "CURRENT_SOURCE_AND_EVIDENCE_DELIVERED", "sources": len(sources), "native_text_files": len(retained),
                  "checked_pairs": len(reports), "independent_witness_roots": 110, "human_approved": False}))
