builtin.module {func.func @f() {"opaque.effect"() {"op_name__" // between
="changed"}:()->() func.return}}