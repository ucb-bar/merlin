builtin.module {func.func @f() {"opaque.effect"() {ordinary=1:i32 // op_name__
}:()->() func.return}}