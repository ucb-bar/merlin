builtin.module {func.func @f() {"opaque.effect"() {ordinary=1:i32, // before
 "op_name__"="changed"}:()->() func.return}}