# Narrow source-root invocation fix review

The complete gate delta is ONE argument: imported project source compilation now runs with cwd=`Path(__file__).parent / "lean"`, which contains all selected `Merlin/*.lean` canonical source paths. Generated query compilation, audit, private objects, checked source bytes, theorem terms/root roster/semantics and premise flags are unchanged. The added SDK-free test checks the command cwd contract. All13 generated actual queries are identical between source cuts.

Verified the215 source/data snapshot members and current owned source hashes. This directly addresses the retained Fv1 out-of-root path rejection without editing any failed proof or SDK/toolchain. F must qualify a new context/cut; old v1 remains unavailable. No source-success, whole-run equality, numerical or hardware assumption is added.
