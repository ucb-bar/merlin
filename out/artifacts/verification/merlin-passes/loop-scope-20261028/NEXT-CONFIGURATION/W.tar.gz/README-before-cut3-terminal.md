# CURRENT: cut2 UNQUALIFIED; cut3 admission qualification pending

Raw reserved op_name__ metadata can be overwritten by xDSL. Existing selected Fv2 tests do not justify cut2 promotion. New exact guard5a07268a excludes the reserved key before parsing; source-review-v4 and independent8SDK controls review it. Fv3/newcut qualification remains pending. All old proof/source/native observations are preserved; generic theorem and13query terms unchanged.

# Configuration elision: W proof and review deliverable

The complete-entry/module theorem and exact actual multifield query compile and pass standard-three audits. A constructive actual-query interpretation produces nonzero observer21; a separate admitted first-error interpretation preserves error73 and terminalobserver21. Existing configuration known-state/checker roots are reused unchanged.

F's independent qualification at Qcut2 passes13actual pairs,21valid Lean-refused mutations,1explicit unsupported boundary,15forged requests,11live artifact controls and fresh-process replay. W independently checked retained raw query/source/mapping/process/type/audit evidence (F-TERMINAL-OBSERVATION-v1.json). The earlier Fv1 source-invocation error remains unavailable; the new cut changes only projectcompilecwd and adds a command-contract regression.

Entry proof delivery: ENTRY-SOURCE-DELIVERY.json / entry-source.patch. Root intook exact Entries05c35122 into the worker canonical source; W edits remain owned additive artifacts. Root alone publishes/merges. W actual-query/witness source remains candidate source bound to exact raw fixture; no native/hardware/human policy approval is supplied.

Read RESULT-v2.json, THEOREM-PREMISE-MAP.json and paper-evidence/README.md for precise claim and limits. Reproduction logs/source snapshots/audits are model-audit-v2, actual-query-v1+actual-query-audit-v1, actual-witness-v4+actual-witness-audit-v2. All project dependency source identities are in SOURCE-CLOSURE.json. OWNED-SOURCES-v2.json/owned-source-review-v2.patch/final-source-snapshot-v2 retain nine current owned/copied source files; Qquery is copied byte-exact, not Wauthored. Earlier source snapshots and first failures are preserved.

Scope: finite straight-line constant decoded fields, arbitrary initial configuration, exact total pure setter law and one common admitted deterministic partial operation interpretation over complete modeled state. Python/ISA/effect/cell mapping, runtime/native/numerical/hardware truth and independent human review remain separate. Internal calls/CFG/loops/barriers/motion/async/timing/wholepipeline composition/production enforcement are outside this result. The worked fixture is constructed using the actual pinned4499 producer, not a model-bundle capture.
