"""Independent SDK-free lexer-boundary controls for the reserved-key fix."""
from pathlib import Path
import hashlib,json,sys
root=Path.cwd();sys.path.insert(0,str(root/'src'))
from merlin.verify.configuration_elision_bridge import Unsupported,parse
base=root/'out/artifacts/verification/merlin-passes/loop-scope-20261028/NEXT-CONFIGURATION/W'
out=base/'reserved-admission-review-v1';out.mkdir(exist_ok=False)
rows=[]
keys=[('fully_byte_escaped','"\\6f\\70\\5f\\6e\\61\\6d\\65\\5f\\5f"'),('escaped_underscore','"op\\5fname__"'),('comment_between_key_value','"op_name__" /* between */'),('after_comma_comment','ordinary=1:i32, /* before */ "op_name__"')]
for name,key in keys:
 text='builtin.module {func.func @f() {"opaque.effect"() {'+key+'="changed"}:()->() func.return}}'
 # MLIRLexer supports // comments, not C-style comments: test actual supported
 # whitespace/comment placement with line comments rather than invalid syntax.
 text=text.replace('/* between */','// between\n').replace('/* before */','// before\n')
 (out/(name+'.mlir')).write_text(text)
 try:parse(text)
 except Unsupported as error:
  assert 'reserved raw' in str(error);rows.append(dict(case=name,refused_reserved=True))
 else:raise AssertionError('reserved attribute admitted: '+name)
benign=[('ordinary_value','ordinary="op_name__"'),('near_key','"op_name___"="kept"'),('comment_text','ordinary=1:i32 // op_name__\n')]
for name,attrs in benign:
 text='builtin.module {func.func @f() {"opaque.effect"() {'+attrs+'}:()->() func.return}}'
 (out/(name+'.mlir')).write_text(text);parse(text);rows.append(dict(case=name,admitted_benign=True))
# The guard deliberately reserves this key globally, including known operations.
text='builtin.module attributes {"op_name__"="reserved"} {}'
try:parse(text)
except Unsupported as error:
 assert 'reserved raw' in str(error);rows.append(dict(case='global_reserved_domain',refused_reserved=True))
else:raise AssertionError('known-op reserved key admitted')
bridge=root/'src/merlin/verify/configuration_elision_bridge.py';data=bridge.read_bytes()
result=dict(status='sdk_free_admission_controls_passed',bridge_sha256=hashlib.sha256(data).hexdigest(),cases=rows,
 native_or_SDK_launch=False,compiler_authoritative_validity_or_semantic_negative_claim=False,
 scope='global reserved op_name__ key denial; escaped/comma/comment positions, distinct ordinary values/near keys retained',
 human_or_hardware_approval=False)
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(cases=len(rows),bridge_sha256=result['bridge_sha256'])))
