"""Review fixed Fv2 terminal source/data/log evidence, without object/SDK reads."""
from pathlib import Path
import hashlib,json
ROOT=Path.cwd();B=ROOT/'out/artifacts/verification/merlin-passes/loop-scope-20261028/NEXT-CONFIGURATION';F=B/'F';Q=B/'Q/source-cut-v3';W=B/'W';RUN=F/'qualification-v3'
def read(p):return json.loads(p.read_text())
def exact(row):
 p=Path(row['path']);assert p.suffix in {'.lean','.py','.json','.mlir','.stdout','.stderr','.yaml','.yml'}
 data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes'];return data
def ref(p):
 data=p.read_bytes();return dict(path=str(p.relative_to(ROOT)),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data))
result=read(RUN/'RESULT.json');assert result['status']=='CONFIGURATION_ENGINEERING_QUALIFICATION_PASSED' and result['failures']==[]
compiler=read(F/'corpus-v1/COMPILER.json')['files'];assert sum(row['valid'] for row in compiler)==83 and len(compiler)==84
replacement=read(F/'corpus-metadata-fix-v2/RESULT.json')['compiler']['files'];assert len(replacement)==1 and replacement[0]['valid']
valid=[row['parsed_bytes'] for row in [*compiler,*replacement] if row['valid']]
for row in valid:exact(row)
reserved=read(F/'reserved-metadata-v1/RESULT.json')['compiler']['files']
assert len(reserved)==3 and all(row['valid'] for row in reserved)
for row in reserved:exact(row['parsed_bytes'])
validhashes={row['sha256'] for row in valid} | {row['parsed_bytes']['sha256'] for row in reserved}
negative=read(RUN/'NEGATIVES.json');selected={r['name']:r for r in read(F/'corpus-bound-v3/NEGATIVES.json')}
assert len(negative)==22 and set(selected)=={row['case'] for row in negative}
review=[]
for row in negative:
 if row['case']=='reserved_metadata_changed':
  assert row['status']=='HOST_DOMAIN_REFUSAL' and 'reserved raw op_name__' in row['reason']
  for refrow in selected[row['case']]['files']:assert hashlib.sha256(exact(refrow)).hexdigest() in validhashes
  continue
 assert row['status']=='ACTUAL_EXPECTED_LEAN_OBLIGATION_REFUSAL' and row['gate_status']=='not_established'
 case=row['case'];folder=ROOT/'out/build/loop-scope-20261028/qualification/configuration-v3/negatives'/case
 for i,source in enumerate(selected[case]['files']):
  assert exact(source)==(folder/('source.mlir' if i==0 else 'final.mlir')).read_bytes()
  assert source['sha256'] in validhashes
 process=read(folder/'query.process.json');assert process['returncode']==1
 path=folder/'ConfigurationElisionQuery.lean';source=path.read_bytes();assert process['command'][-1]==str(path)
 assert hashlib.sha256(source).hexdigest()==row['classification']['source_sha256']
 assert source.decode().splitlines()[14]=='theorem accepted : Entries.check fields before after = true := by decide'
 stdout=(folder/'query.stdout').read_text();stderr=(folder/'query.stderr').read_text()
 expected=str(path)+':15:66: error: Tactic `decide` proved that the proposition\n  Entries.check fields before after = true\nis false\n'
 assert stdout==expected and stderr==''
 for i in range(7):assert read(folder/f'import-{i}.process.json')['returncode']==0
 review.append(dict(case=case,source=ref(path),query_process=ref(folder/'query.process.json'),raw_pair_compiler_valid=True,exact_false_obligation=True))
protocol=read(RUN/'protocol/PROTOCOL.json');assert len(protocol['cases'])==15 and all(row['status']=='unavailable' and row['no_native_output'] for row in protocol['cases'])
artifacts=read(RUN/'artifact-controls/ARTIFACTS.json');assert len(artifacts['cases'])==11 and all(row['refused'] for row in artifacts['cases'])
assert artifacts['constructed_copied_saved_tokens_refused']==5 and artifacts['copied_candidate_refused'] and artifacts['no_mock_positive_proof']
replay=read(RUN/'fresh-process-replay/RESULT.json');assert replay['status']=='checked' and replay['incoming_ledger']==0 and replay['newly_issued_completions']==1
assert read(RUN/'fresh-process-driver/PROCESS.json')['returncode']==0
r=json.loads(exact(replay['report']));folder=Path(replay['report']['path']).parent
assert r['audit']['violations']==[] and set(r['audit']['axioms_used']) <= {'propext','Classical.choice','Quot.sound'}
assert exact(r['query'])==(W/'sources/ConfigurationElisionQuery.lean').read_bytes()
assert set(r['statements'])==set(read(Q/'cases/multifield/ROOTS.json'))
for row in r['sources']:exact(row)
for row in r['mapping_records']:exact(row)
for row in r['buffers']:assert hashlib.sha256(exact(row)).hexdigest() in validhashes
processes=0
for row in r['process_evidence']:
 data=exact(row)
 if row['path'].endswith('.process.json'):
  assert json.loads(data)['returncode']==0;processes+=1
assert processes==10 and read(folder/'audit.stdout')==r['audit'] and read(folder/'types.stdout')['statements']==r['statements']
unsupported=read(RUN/'UNSUPPORTED.json');assert len(unsupported)==1 and unsupported[0]['status']=='EXPECTED_EXPLICIT_UNSUPPORTED'
output=dict(status='read_only_full_terminal_source_log_review_passed',result=ref(RUN/'RESULT.json'),
 checked_actual_pairs=13,valid_mutant_pairs=22,actual_false_obligation_refusals=21,host_mutation_refusals=1,
 negative_cases=review,selected_compiler_valid_buffers=87,old_invalid_metadata_buffer_preserved=True,
 forged_pre_native_requests=15,live_artifact_controls=11,fresh_empty_ledger_replay=True,replay_processes=10,
 replay_roots=17,replay_theorems=r['audit']['theorems_audited'],std3=True,replay_report=replay['report'],
 object_or_SDK_contents_read=False,new_native_launch=False,human_or_hardware_approval=False,
 limits=['F owns process-local ledger/object/runtime binding and finalseal','Explicit declared instruction/ISA/state interpretation is conditional',
 'No adjacent loop/buffer-to-configuration semantics bridge','Fv1 rootdirectory failure unavailable; cut2 UNQUALIFIED rawmetadata admission loss preserved and never promoted'])
with (W/'F3-TERMINAL-OBSERVATION-v1.json').open('x') as f:json.dump(output,f,indent=2);f.write('\n')
print(json.dumps(dict(checked=13,false_obligations=21,host_refusals=1,compiler_valid_buffers=87,replay=True,std3=True)))
