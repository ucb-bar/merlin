"""Read-only review of F's retained configuration proof reports.

Never reads SDK/native/proof-object contents or controls another worker's jobs.
"""
from pathlib import Path
import hashlib,json,sys
ROOT=Path.cwd();B=ROOT/'out/artifacts/verification/merlin-passes/loop-scope-20261028/NEXT-CONFIGURATION';W=B/'W';F=B/'F/qualification-v3';Q=B/'Q/source-cut-v3'
def exact(row):
 p=Path(row['path']);assert p.suffix in {'.lean','.py','.json','.mlir','.stdout','.stderr','.yaml','.yml'}
 data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes'];return data
def read(p):return json.loads(p.read_text())
review=[]
for case in read(F/'POSITIVES.json'):
 assert case['status']=='checked'
 r=json.loads(exact(case['report']));folder=Path(case['report']['path']).parent;expected=Q/'cases'/case['name']
 assert r['status']=='checked' and r['audit']['violations']==[]
 assert set(r['audit']['axioms_used']) <= {'propext','Classical.choice','Quot.sound'}
 assert set(r['statements'])==set(read(expected/'ROOTS.json'))
 assert exact(r['query'])==(expected/'ConfigurationElisionQuery.lean').read_bytes()
 for i,row in enumerate(r['buffers']):assert exact(row)==exact(case['original_before_after'][i])
 mappings={Path(row['path']).stem:json.loads(exact(row)) for row in r['mapping_records']}
 assert set(mappings)=={'Projection','Resolution','SourceRequest'}
 assert mappings['Projection']==read(expected/'PROJECTION.json') and mappings['SourceRequest']==r['source_request']
 for row in r['sources']:exact(row)
 processes=[]
 for row in r['process_evidence']:
  data=exact(row)
  if row['path'].endswith('.process.json'):
   process=json.loads(data);assert process['returncode']==0;processes.append(process)
 assert len(processes)==10
 assert read(folder/'audit.stdout')==r['audit'] and read(folder/'types.stdout')['statements']==r['statements']
 project=[row for row in r['audit']['imports'] if row['module'].startswith('Merlin.') or row['module']=='ConfigurationElisionQuery']
 assert len(project)==8
 for row in project:assert Path(row['olean']).resolve()==(folder/'lib'/(row['module'].replace('.','/')+'.olean')).resolve()
 assert r['interpretation_is_conditional'] and not any(r[k] for k in ['independently_qualified','hardware_model_approved','production_enforcement'])
 assert case['consumer_called'] and case['final_bytes_identical']
 review.append(dict(case=case['name'],report=case['report'],raw_pair_exact=True,Qcut3_query_projection_roots_exact=True,
  sources_exact=len(r['sources']),processes=10,project_import_paths=8,printed_roots=len(r['statements']),
  audited_theorems=r['audit']['theorems_audited'],std3=True,consumer_called=True,final_bytes_identical=True))
result=dict(status='completed_positive_report_review_passed',cases=review,required_positive_count=13,
 full_campaign_qualification=False,SDK_or_object_contents_read=False,native_launch=False,
 limitations=['Retained case evidence review only; F owns live ledger/object/runtime binding and full campaign/replay',
 'Original Fv1 invocation failures unavailable; cut2 UNQUALIFIED for reserved raw metadata loss','ISA/model/primitive/native/human/adjacent-composition correspondence remains explicit'])
p=W/sys.argv[1]
with p.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(reviewed=len(review),required=13)))
