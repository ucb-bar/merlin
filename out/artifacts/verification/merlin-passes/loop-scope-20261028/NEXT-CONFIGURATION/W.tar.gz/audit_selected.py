"""Audit exact compiled W declaration roots in their private object tree."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
root=Path.cwd();base=root/'out/artifacts/verification/merlin-passes/loop-scope-20261028/NEXT-CONFIGURATION/W'
record=base/sys.argv[1];record.mkdir(exist_ok=False)
profile=base/sys.argv[2];result=json.loads((profile/'RESULT.json').read_text());objects=Path(result['objects'])
source_refs=json.loads((profile/'SOURCES.json').read_text())
roots=[]
for row in source_refs:
 p=Path(row['path']);data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
 s=data.decode();namespace=re.search(r'^namespace (\S+)',s,re.M).group(1)
 roots.extend(namespace+'.'+name for name in re.findall(r'^(?:theorem|def|abbrev) (\w+)',s,re.M))
assert len(set(roots))==len(roots)
(record/'ROOTS.json').write_text(json.dumps(roots,indent=2)+'\n')
(record/'SOURCES.json').write_text(json.dumps(source_refs,indent=2)+'\n')
lean='/home/jeremy/.elan/toolchains/leanprover--lean4---v4.35.0/bin/lean';audit=root/'src/merlin/verify/lean/Merlin/GraphStateAudit.lean'
env=dict(os.environ,LEAN_PATH=str(objects),PATH=str(Path(lean).parent)+os.pathsep+os.environ.get('PATH',''));env.pop('LEAN_SRC_PATH',None)
modules=sys.argv[3:]
assert modules
for label,args in [('audit',modules),('types',['--statements',','.join(roots),*modules])]:
 command=[lean,'--run',str(audit),*args];start=time.monotonic()
 p=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,timeout=120)
 for stream in ['stdout','stderr']:(record/(label+'.'+stream)).write_text(getattr(p,stream))
 (record/(label+'.process.json')).write_text(json.dumps(dict(command=command,returncode=p.returncode,seconds=time.monotonic()-start),indent=2)+'\n')
 if p.returncode:print(p.stdout+p.stderr);raise SystemExit(p.returncode)
observed=json.loads((record/'audit.stdout').read_text());types=json.loads((record/'types.stdout').read_text())
assert observed['violations']==[] and set(observed['axioms_used']) <= {'propext','Classical.choice','Quot.sound'}
assert set(types['statements'])==set(roots)
(record/'RESULT.json').write_text(json.dumps(dict(status='audited',roots=len(roots),theorems=observed['theorems_audited'],axioms=observed['axioms_used'],violations=[],actual_compiler_IR_bound=('ConfigurationElisionQuery' in modules)),indent=2)+'\n')
print(json.dumps(dict(status='audited',roots=len(roots),theorems=observed['theorems_audited'],axioms=observed['axioms_used'])))
