# Structured proof API v1

Namespace `Merlin.GraphState.Configuration.Elimination`.

`Effects`: `reads writes : List (Nat × Int)`, `clobbers : List Nat`, `ordered pureWrite : Bool`.
`Command`: `identity : String`, `effect : Option Effects`.
Fields use an explicit injective finite map from actual field strings to Nat. Identity binds complete actual operation/SSA/attributes, not an effect or hardware admission. Retained commands match exactly, including their decoded effect. Constant fields only; no control/loops/barriers deleted.

`check before after : Bool` starts from unknown state per invocation, greedily retains identical complete commands and permits skipping only a well-formed ordered nonempty pure write with every field already equal. Declared reads, clobbers, ordering and writes bind actual decoder results. Retained unknown/unordered effects clear knowledge; ordered clobbers invalidate affected keys, writes establish exact values. No target insertion/reordering/metadata change admitted.

`World Other`: `configuration : Nat → Int`, `other : Other`. `Meaning Other := Command → World Other → Option (World Other)` (deterministic partial semantics). A retained command may observe the full state or record user observations; its declared ordered frame/exact writes must hold on successful transitions. Pure write admission requires EXACT `some` configuration put and unchanged `other`; no enqueue/pulse/token/SSA/status/memory effects. A command's modeled semantics is shared across source/target. No source/target run equality as premise. The checker theorem derives equality of complete `Option World` executions from arbitrary initial state. The interpretation can model caller memory, SSA, observable traces and failure in `other`; no numerical/native/hardware correspondence is inferred.

Q generates actual before/after command lists and checked theorem; W supplies finite checker, model agreement definitions and generic soundness. F independently interprets raw fixtures/effects and negatives. Projected effect/model agreement, independent ISA/codec decoding and target implementation review remain explicit trust boundaries.
