# Agreed configuration proof API

Reuse unchanged `Merlin.GraphState.Elision.{Effect,Atom,check,check_sound,Admitted,execute}` from GraphStateElisionContract/GraphStateElision. The prior OptionWorld proposal is superseded. An Atom has original dense source occurrence `id : Nat`, complete `token : String`, `effect : Option Effect`, `eraseAllowed : Bool`. Effect has reads/writes : List(Nat×Int), clobbers : ListNat, ordered/pureWrite Bool. The field map is explicit/injective; literal values remain Int.

W additive `Merlin.GraphState.Configuration.Entries` from `GraphStateConfigurationEntries`:

- `Entry {name:String,header:String,code:List Elision.Atom}`.
- `Program {frame:String,entries:List Entry}`.
- `check fields before after : Bool`; exact frame, distinct source names, same ordered entry/header roster, existing whole-list check per entry.
- `invoke run program name initial : Option (Except (Error×StateValue) StateValue)`; missing name gives none; a selected body executes under `run entry.name`.
- `Admitted fields literal run before : Prop` supplies only existing pointwise Elision.Admitted for every source atom of every defined entry.
- `check_sound accepted literal run models name initial` proves complete invoke equality; checkEntries_sound/checked_headers/checked_selected/checked_frame/checked_observation expose roster, lookup, metadata and arbitrary outcome observer consequences.

`run : String → Nat → State Value → Except (Error×State Value) (State Value)` is ONE common actual operation interpretation. State is complete modeled state (configuration, caller memory, SSA, observations as explicit cells), not a projection asserted to determine an unmodeled machine. Pointwise pure admission is exact total assign over declared writes with every other cell unchanged. Retained operations may fail with terminal error/state. Unknown/unordered effects clear knowledge; clobbers invalidate; successful ordered writes/read requirements obey declared model. No source-success or source/target whole-run equality premise. No native/ISA correspondence is implied by names or annotation strings.

Q owns complete actual typed IR/header/module frame/operation SSA rendering and source/target occurrence matching; F independently checks raw producer fixtures/decoding and mutations. Declarations and function interfaces are in the checked frame/header; runtime call/ABI/SSA-to-state interpretation remains an explicit trust boundary. No interprocedural recursion/control/loop-motion/new numerical theorem.
