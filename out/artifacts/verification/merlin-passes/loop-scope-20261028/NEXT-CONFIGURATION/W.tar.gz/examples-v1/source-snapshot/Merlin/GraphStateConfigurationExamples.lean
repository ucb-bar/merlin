/- Constructive abstract-model witnesses and refusal counterexamples.
These are not compiler-generated fixtures; actual producer binding is separate. -/
import Merlin.GraphStateConfigurationEntries

namespace Merlin.GraphState.Configuration.Examples
open StateEffects Elision
set_option autoImplicit false

def setter (value : Int) : Effect := ⟨[],[(0,value)],[],true,true⟩
def write (id : Nat) (value : Int) : Atom := ⟨id,"setter",some (setter value),true⟩
def observer : Atom := ⟨1,"observe-field0-into-cell8",some ⟨[(0,7)],[],[],true,false⟩,false⟩
def finish : Atom := ⟨3,"finish-or-fail",none,false⟩
def source : List Atom := [write 0 7,observer,write 2 7,finish]
def target : List Atom := [write 0 7,observer,finish]
def sourceModule : Entries.Program := ⟨"unchanged declarations and module attributes",[⟨"kernel","() -> ()",source⟩]⟩
def targetModule : Entries.Program := ⟨sourceModule.frame,[⟨"kernel","() -> ()",target⟩]⟩

theorem accepted : Entries.check [0] sourceModule targetModule = true := by decide

def setCell (key : Nat) (value : Int) (state : State Int) : State Int :=
  fun index => if index = key then value else state index

def run (fail : Bool) (_entry : String) (id : Nat) (state : State Int) :
    Except (Nat × State Int) (State Int) :=
  if id = 0 ∨ id = 2 then .ok (assign (fun x => x) [(0,7)] state)
  else if id = 1 then
    if state 0 = 7 then .ok (setCell 8 (state 8 + state 0) state)
    else .error (11,state)
  else if fail then .error (42,setCell 9 1 state) else .ok state

theorem pure_model (fail : Bool) (id : Nat) (isWrite : id = 0 ∨ id = 2) :
    Elision.Admitted [0] (fun x => x) (run fail "kernel") (write id 7) := by
  simp only [Elision.Admitted,write,setter,Option.some.injEq]
  constructor
  · intro _ initial final success
    have equal : final = assign (fun x => x) [(0,7)] initial := by
      simpa only [run,isWrite,ite_true,Except.ok.injEq] using success.symm
    subst final
    constructor
    · intro key value found
      simp only [List.lookup_cons] at found
      split at found
      · next same =>
        have keyEqual : key = 0 := by simpa using same
        subst key
        have valueEqual : value = 7 := by simpa using found.symm
        subst value
        simp [assign]
      · cases found
    · constructor
      · intro key member absent _
        have keyEqual : key = 0 := by simpa using member
        subst key
        simp at absent
      · intro pair member; cases member
  · intro _ state
    simp [run,isWrite]

theorem observer_model (fail : Bool) :
    Elision.Admitted [0] (fun x => x) (run fail "kernel") observer := by
  constructor
  · intro _ initial final success
    have installed : initial 0 = 7 := by
      by_cases h : initial 0 = 7
      · exact h
      · simp [run,h] at success
    have equal : final = setCell 8 (initial 8 + initial 0) initial := by
      simpa [run,installed] using success.symm
    subst final
    refine ⟨?_,?_,?_⟩
    · intro key value found; cases found
    · intro key member _ _
      have keyEqual : key = 0 := by simpa using member
      subst key
      simp [setCell]
    · intro pair member
      have equal : pair = (0,7) := by simpa [observer] using member
      subst pair
      exact installed
  · intro impossible
    cases impossible

theorem model (fail : Bool) : Entries.Admitted [0] (fun x => x) (run fail) sourceModule := by
  intro entry member atom included
  have entryEqual : entry = ⟨"kernel","() -> ()",source⟩ := by simpa [sourceModule] using member
  subst entry
  simp only [source,List.mem_cons,List.mem_singleton] at included
  rcases included with rfl | rfl | rfl | rfl
  · exact pure_model fail 0 (Or.inl rfl)
  · exact observer_model fail
  · exact pure_model fail 2 (Or.inr rfl)
  · trivial

def initial : State Int := fun key => if key = 0 then 5 else if key = 8 then 3 else 0

theorem all_outcomes (fail : Bool) (state : State Int) :
    Entries.invoke (run fail) sourceModule "kernel" state =
      Entries.invoke (run fail) targetModule "kernel" state :=
  Entries.check_sound accepted (fun x => x) (run fail) (model fail) "kernel" state

/-- The source run is constructed without a source-success hypothesis. -/
theorem source_success : Entries.invoke (run false) sourceModule "kernel" initial =
    some (.ok (setCell 8 10 (assign (fun x => x) [(0,7)] initial))) := by
  simp [Entries.invoke,Entries.findEntry,sourceModule,source,Elision.execute,run,
    write,observer,finish,assign,setCell,initial,Except.bind]

theorem final_success : Entries.invoke (run false) targetModule "kernel" initial =
    some (.ok (setCell 8 10 (assign (fun x => x) [(0,7)] initial))) := by
  rw [←all_outcomes false initial]
  exact source_success

theorem observed_nonzero : setCell 8 10 (assign (fun x => x) [(0,7)] initial) 8 = 10 := rfl

theorem source_failure : Entries.invoke (run true) sourceModule "kernel" initial =
    some (.error (42,setCell 9 1 (setCell 8 10 (assign (fun x => x) [(0,7)] initial)))) := by
  simp [Entries.invoke,Entries.findEntry,sourceModule,source,Elision.execute,run,
    write,observer,finish,assign,setCell,initial,Except.bind]

theorem final_failure : Entries.invoke (run true) targetModule "kernel" initial =
    some (.error (42,setCell 9 1 (setCell 8 10 (assign (fun x => x) [(0,7)] initial)))) := by
  rw [←all_outcomes true initial]
  exact source_failure

theorem missing_entry : Entries.invoke (run false) targetModule "missing" initial = none := by decide

/- Independent finite controls: the whole first/different/multi-field write,
clobber/unknown/pulse instruction, or an entry/frame cannot be silently erased. -/
theorem refuses_first : Elision.check [0] [write 0 7] [] = false := by decide
theorem refuses_different : Elision.check [0] [write 0 7,write 1 8] [write 0 7] = false := by decide

def clobber : Atom := ⟨1,"clobber",some ⟨[],[],[0],true,false⟩,false⟩
def unknown : Atom := ⟨1,"unknown",none,false⟩
def pulse : Atom := ⟨1,"same-write-with-pulse",some (setter 7),false⟩
def multi : Atom := ⟨1,"write-two-fields",some ⟨[],[(0,7),(1,9)],[],true,true⟩,true⟩

theorem refuses_after_clobber :
    Elision.check [0] [write 0 7,clobber,write 2 7] [write 0 7,clobber] = false := by decide
theorem refuses_after_unknown :
    Elision.check [0] [write 0 7,unknown,write 2 7] [write 0 7,unknown] = false := by decide
theorem refuses_pulse : Elision.check [0] [write 0 7,pulse] [write 0 7] = false := by decide
theorem refuses_partial_multi : Elision.check [0,1] [write 0 7,multi] [write 0 7] = false := by decide
theorem refuses_missing_entry : Entries.check [0] sourceModule ⟨sourceModule.frame,[]⟩ = false := by decide
theorem refuses_changed_frame : Entries.check [0] sourceModule ⟨"wrong module interface",targetModule.entries⟩ = false := by decide

/-- Explicit countermodel to pretending a redundant-looking write has no pulse. -/
def pulseRun (state : State Int) : State Int := setCell 8 (state 8 + 1) (assign (fun x => x) [(0,7)] state)
theorem hidden_pulse_changes_observation : pulseRun (fun _ => 7) 8 ≠ (fun _ : Nat => (7 : Int)) 8 := by decide

def installed7 : State Int := fun _ => 7
theorem different_write_changes_state : assign (fun x => x) [(0,8)] installed7 0 ≠ installed7 0 := by decide
theorem first_write_changes_state : assign (fun x => x) [(0,7)] initial 0 ≠ initial 0 := by decide

end Merlin.GraphState.Configuration.Examples
